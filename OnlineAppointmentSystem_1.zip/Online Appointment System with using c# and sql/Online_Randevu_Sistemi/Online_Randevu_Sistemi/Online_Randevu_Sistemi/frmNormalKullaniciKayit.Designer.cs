﻿
namespace Online_Randevu_Sistemi
{
    partial class frmNormalKullaniciKayit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNormalKullaniciKayit));
            this.grbNormalKullaniciKayit = new System.Windows.Forms.GroupBox();
            this.mtbTelNo = new System.Windows.Forms.MaskedTextBox();
            this.lblTelNo = new System.Windows.Forms.Label();
            this.lblAdres = new System.Windows.Forms.Label();
            this.txtAdres = new System.Windows.Forms.TextBox();
            this.lblSoyisim = new System.Windows.Forms.Label();
            this.lblIsim = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblSifre = new System.Windows.Forms.Label();
            this.txtSoyisim = new System.Windows.Forms.TextBox();
            this.txtIsim = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtSifre = new System.Windows.Forms.TextBox();
            this.txtKullaniciAdi = new System.Windows.Forms.TextBox();
            this.lblKullaniciAdi = new System.Windows.Forms.Label();
            this.btnBilgilerimiKaydet = new System.Windows.Forms.Button();
            this.ilKullaniciKaydet = new System.Windows.Forms.ImageList(this.components);
            this.grbNormalKullaniciKayit.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbNormalKullaniciKayit
            // 
            this.grbNormalKullaniciKayit.Controls.Add(this.mtbTelNo);
            this.grbNormalKullaniciKayit.Controls.Add(this.lblTelNo);
            this.grbNormalKullaniciKayit.Controls.Add(this.lblAdres);
            this.grbNormalKullaniciKayit.Controls.Add(this.txtAdres);
            this.grbNormalKullaniciKayit.Controls.Add(this.lblSoyisim);
            this.grbNormalKullaniciKayit.Controls.Add(this.lblIsim);
            this.grbNormalKullaniciKayit.Controls.Add(this.lblEmail);
            this.grbNormalKullaniciKayit.Controls.Add(this.lblSifre);
            this.grbNormalKullaniciKayit.Controls.Add(this.txtSoyisim);
            this.grbNormalKullaniciKayit.Controls.Add(this.txtIsim);
            this.grbNormalKullaniciKayit.Controls.Add(this.txtEmail);
            this.grbNormalKullaniciKayit.Controls.Add(this.txtSifre);
            this.grbNormalKullaniciKayit.Controls.Add(this.txtKullaniciAdi);
            this.grbNormalKullaniciKayit.Controls.Add(this.lblKullaniciAdi);
            this.grbNormalKullaniciKayit.Controls.Add(this.btnBilgilerimiKaydet);
            this.grbNormalKullaniciKayit.Location = new System.Drawing.Point(1, 0);
            this.grbNormalKullaniciKayit.Name = "grbNormalKullaniciKayit";
            this.grbNormalKullaniciKayit.Size = new System.Drawing.Size(889, 698);
            this.grbNormalKullaniciKayit.TabIndex = 2;
            this.grbNormalKullaniciKayit.TabStop = false;
            this.grbNormalKullaniciKayit.Text = "Normal Kullanıcı Kayıt Formu";
            // 
            // mtbTelNo
            // 
            this.mtbTelNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtbTelNo.Location = new System.Drawing.Point(613, 141);
            this.mtbTelNo.Mask = "(999) 000-0000";
            this.mtbTelNo.Name = "mtbTelNo";
            this.mtbTelNo.Size = new System.Drawing.Size(197, 30);
            this.mtbTelNo.TabIndex = 6;
            // 
            // lblTelNo
            // 
            this.lblTelNo.AutoSize = true;
            this.lblTelNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelNo.Location = new System.Drawing.Point(486, 146);
            this.lblTelNo.Name = "lblTelNo";
            this.lblTelNo.Size = new System.Drawing.Size(82, 22);
            this.lblTelNo.TabIndex = 13;
            this.lblTelNo.Text = "Tel. No:";
            // 
            // lblAdres
            // 
            this.lblAdres.AutoSize = true;
            this.lblAdres.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdres.Location = new System.Drawing.Point(37, 402);
            this.lblAdres.Name = "lblAdres";
            this.lblAdres.Size = new System.Drawing.Size(68, 22);
            this.lblAdres.TabIndex = 12;
            this.lblAdres.Text = "Adres:";
            // 
            // txtAdres
            // 
            this.txtAdres.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAdres.Location = new System.Drawing.Point(182, 401);
            this.txtAdres.Multiline = true;
            this.txtAdres.Name = "txtAdres";
            this.txtAdres.Size = new System.Drawing.Size(197, 240);
            this.txtAdres.TabIndex = 4;
            // 
            // lblSoyisim
            // 
            this.lblSoyisim.AutoSize = true;
            this.lblSoyisim.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoyisim.Location = new System.Drawing.Point(37, 318);
            this.lblSoyisim.Name = "lblSoyisim";
            this.lblSoyisim.Size = new System.Drawing.Size(85, 22);
            this.lblSoyisim.TabIndex = 10;
            this.lblSoyisim.Text = "Soyisim:";
            // 
            // lblIsim
            // 
            this.lblIsim.AutoSize = true;
            this.lblIsim.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIsim.Location = new System.Drawing.Point(37, 233);
            this.lblIsim.Name = "lblIsim";
            this.lblIsim.Size = new System.Drawing.Size(51, 22);
            this.lblIsim.TabIndex = 9;
            this.lblIsim.Text = "İsim:";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(486, 60);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(65, 22);
            this.lblEmail.TabIndex = 8;
            this.lblEmail.Text = "Email:";
            // 
            // lblSifre
            // 
            this.lblSifre.AutoSize = true;
            this.lblSifre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSifre.Location = new System.Drawing.Point(37, 146);
            this.lblSifre.Name = "lblSifre";
            this.lblSifre.Size = new System.Drawing.Size(58, 22);
            this.lblSifre.TabIndex = 7;
            this.lblSifre.Text = "Şifre:";
            // 
            // txtSoyisim
            // 
            this.txtSoyisim.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoyisim.Location = new System.Drawing.Point(182, 317);
            this.txtSoyisim.Multiline = true;
            this.txtSoyisim.Name = "txtSoyisim";
            this.txtSoyisim.Size = new System.Drawing.Size(197, 47);
            this.txtSoyisim.TabIndex = 3;
            // 
            // txtIsim
            // 
            this.txtIsim.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIsim.Location = new System.Drawing.Point(182, 230);
            this.txtIsim.Multiline = true;
            this.txtIsim.Name = "txtIsim";
            this.txtIsim.Size = new System.Drawing.Size(197, 47);
            this.txtIsim.TabIndex = 2;
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(613, 59);
            this.txtEmail.Multiline = true;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(260, 47);
            this.txtEmail.TabIndex = 5;
            // 
            // txtSifre
            // 
            this.txtSifre.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSifre.Location = new System.Drawing.Point(182, 145);
            this.txtSifre.Multiline = true;
            this.txtSifre.Name = "txtSifre";
            this.txtSifre.PasswordChar = '*';
            this.txtSifre.Size = new System.Drawing.Size(197, 47);
            this.txtSifre.TabIndex = 1;
            // 
            // txtKullaniciAdi
            // 
            this.txtKullaniciAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKullaniciAdi.Location = new System.Drawing.Point(182, 59);
            this.txtKullaniciAdi.Multiline = true;
            this.txtKullaniciAdi.Name = "txtKullaniciAdi";
            this.txtKullaniciAdi.Size = new System.Drawing.Size(197, 47);
            this.txtKullaniciAdi.TabIndex = 0;
            // 
            // lblKullaniciAdi
            // 
            this.lblKullaniciAdi.AutoSize = true;
            this.lblKullaniciAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKullaniciAdi.Location = new System.Drawing.Point(37, 60);
            this.lblKullaniciAdi.Name = "lblKullaniciAdi";
            this.lblKullaniciAdi.Size = new System.Drawing.Size(127, 22);
            this.lblKullaniciAdi.TabIndex = 1;
            this.lblKullaniciAdi.Text = "Kullanıcı Adı:";
            // 
            // btnBilgilerimiKaydet
            // 
            this.btnBilgilerimiKaydet.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBilgilerimiKaydet.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBilgilerimiKaydet.ImageIndex = 0;
            this.btnBilgilerimiKaydet.ImageList = this.ilKullaniciKaydet;
            this.btnBilgilerimiKaydet.Location = new System.Drawing.Point(581, 604);
            this.btnBilgilerimiKaydet.Name = "btnBilgilerimiKaydet";
            this.btnBilgilerimiKaydet.Size = new System.Drawing.Size(292, 74);
            this.btnBilgilerimiKaydet.TabIndex = 7;
            this.btnBilgilerimiKaydet.Text = "Bilgilerimi Kaydet";
            this.btnBilgilerimiKaydet.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBilgilerimiKaydet.UseVisualStyleBackColor = true;
            this.btnBilgilerimiKaydet.Click += new System.EventHandler(this.btnKullaniciKaydet_Click);
            // 
            // ilKullaniciKaydet
            // 
            this.ilKullaniciKaydet.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ilKullaniciKaydet.ImageStream")));
            this.ilKullaniciKaydet.TransparentColor = System.Drawing.Color.Transparent;
            this.ilKullaniciKaydet.Images.SetKeyName(0, "save11.jpg");
            // 
            // frmNormalKullaniciKayit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(897, 704);
            this.Controls.Add(this.grbNormalKullaniciKayit);
            this.Name = "frmNormalKullaniciKayit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Normal Kullanici Kayit Formu";
            this.grbNormalKullaniciKayit.ResumeLayout(false);
            this.grbNormalKullaniciKayit.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbNormalKullaniciKayit;
        private System.Windows.Forms.MaskedTextBox mtbTelNo;
        private System.Windows.Forms.Label lblTelNo;
        private System.Windows.Forms.Label lblAdres;
        private System.Windows.Forms.TextBox txtAdres;
        private System.Windows.Forms.Label lblSoyisim;
        private System.Windows.Forms.Label lblIsim;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblSifre;
        private System.Windows.Forms.TextBox txtSoyisim;
        private System.Windows.Forms.TextBox txtIsim;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtSifre;
        private System.Windows.Forms.TextBox txtKullaniciAdi;
        private System.Windows.Forms.Label lblKullaniciAdi;
        private System.Windows.Forms.Button btnBilgilerimiKaydet;
        private System.Windows.Forms.ImageList ilKullaniciKaydet;
    }
}