﻿
namespace Online_Randevu_Sistemi
{
    partial class frmIsyeriAra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvIsyeriAra = new System.Windows.Forms.DataGridView();
            this.btnIsyeriAra = new System.Windows.Forms.Button();
            this.txtAranacakIsyeriAdi = new System.Windows.Forms.TextBox();
            this.lblAranacakIsyeriAdi = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvIsyeriAra)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvIsyeriAra
            // 
            this.dgvIsyeriAra.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvIsyeriAra.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvIsyeriAra.Location = new System.Drawing.Point(12, 12);
            this.dgvIsyeriAra.Name = "dgvIsyeriAra";
            this.dgvIsyeriAra.RowHeadersWidth = 62;
            this.dgvIsyeriAra.RowTemplate.Height = 28;
            this.dgvIsyeriAra.Size = new System.Drawing.Size(1114, 401);
            this.dgvIsyeriAra.TabIndex = 0;
            // 
            // btnIsyeriAra
            // 
            this.btnIsyeriAra.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIsyeriAra.Location = new System.Drawing.Point(890, 454);
            this.btnIsyeriAra.Name = "btnIsyeriAra";
            this.btnIsyeriAra.Size = new System.Drawing.Size(236, 55);
            this.btnIsyeriAra.TabIndex = 1;
            this.btnIsyeriAra.Text = "İşyeri Ara";
            this.btnIsyeriAra.UseVisualStyleBackColor = true;
            this.btnIsyeriAra.Click += new System.EventHandler(this.btnIsyeriAra_Click);
            // 
            // txtAranacakIsyeriAdi
            // 
            this.txtAranacakIsyeriAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAranacakIsyeriAdi.Location = new System.Drawing.Point(301, 460);
            this.txtAranacakIsyeriAdi.Multiline = true;
            this.txtAranacakIsyeriAdi.Name = "txtAranacakIsyeriAdi";
            this.txtAranacakIsyeriAdi.Size = new System.Drawing.Size(270, 47);
            this.txtAranacakIsyeriAdi.TabIndex = 0;
            // 
            // lblAranacakIsyeriAdi
            // 
            this.lblAranacakIsyeriAdi.AutoSize = true;
            this.lblAranacakIsyeriAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAranacakIsyeriAdi.Location = new System.Drawing.Point(30, 469);
            this.lblAranacakIsyeriAdi.Name = "lblAranacakIsyeriAdi";
            this.lblAranacakIsyeriAdi.Size = new System.Drawing.Size(214, 25);
            this.lblAranacakIsyeriAdi.TabIndex = 3;
            this.lblAranacakIsyeriAdi.Text = "Aranacak İşyeri İsmi:";
            // 
            // frmIsyeriAra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1138, 564);
            this.Controls.Add(this.lblAranacakIsyeriAdi);
            this.Controls.Add(this.txtAranacakIsyeriAdi);
            this.Controls.Add(this.btnIsyeriAra);
            this.Controls.Add(this.dgvIsyeriAra);
            this.Name = "frmIsyeriAra";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "İşyeri Arama Formu";
            ((System.ComponentModel.ISupportInitialize)(this.dgvIsyeriAra)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvIsyeriAra;
        private System.Windows.Forms.Button btnIsyeriAra;
        private System.Windows.Forms.TextBox txtAranacakIsyeriAdi;
        private System.Windows.Forms.Label lblAranacakIsyeriAdi;
    }
}