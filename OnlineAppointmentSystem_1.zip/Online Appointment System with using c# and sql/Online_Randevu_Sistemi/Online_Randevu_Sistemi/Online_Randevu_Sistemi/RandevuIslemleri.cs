﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace Online_Randevu_Sistemi
{
    class RandevuIslemleri:sqlIslemleri
    {
        public void IsyeriTakvimGoster(DataGridView dgvGunler,RandevuElemanlar elemanlar)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select takvim_isyeri_adi,takvim_gün,[8_9],[9_10],[10_11],[11_12],[13_14],[14_15],[15_16],[16_17] From randevuTakvim Where takvim_isyeri_adi like '%" + elemanlar.Isyeri_Adi + "%'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgvGunler.DataSource = ds.Tables[0];
            con.Close();
        }
        int RandevuNo;
        public int RandevuNoAtama()
        {
            Random rnd = new Random();
            RandevuNo = rnd.Next(10000, 99999);
            return RandevuNo;
        }
        public void ButunTakvimGoster(DataGridView dgvGunler)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("Select takvim_isyeri_adi,takvim_gün,[8_9],[9_10],[10_11],[11_12],[13_14],[14_15],[15_16],[16_17] From randevuTakvim", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgvGunler.DataSource = ds.Tables[0];
            con.Close();
        }
        public void GunDuzenle(DataGridView dgvGun,RandevuElemanlar elemanlar)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Update randevuTakvim Set [8_9]='" + elemanlar.sekizDokuz + "', [9_10]='" + elemanlar.dokuzOn + "', [10_11]='" + elemanlar.onOnbir + "', [11_12]='" + elemanlar.onbirOniki + "', [13_14]='" + elemanlar.onucOndort + "', [14_15]='" + elemanlar.ondortOnbes + "', [15_16]='" + elemanlar.onbesOnalti + "', [16_17]='" + elemanlar.onaltiOnyedi + "' Where takvim_gün='" + elemanlar.Randevu_Gun + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            SqlDataAdapter da = new SqlDataAdapter("Select takvim_isyeri_adi,takvim_gün,[8_9],[9_10],[10_11],[11_12],[13_14],[14_15],[15_16],[16_17] From randevuTakvim", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgvGun.DataSource = ds.Tables[0];
        }

        public void GunEkle(DataGridView dgvGunler, RandevuElemanlar elemanlar)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Insert Into randevuTakvim(takvim_isyeri_adi,takvim_gün,[8_9],[9_10],[10_11],[11_12],[13_14],[14_15],[15_16],[16_17]) values ('" + (elemanlar.Isyeri_Adi) + "','" + (elemanlar.Randevu_Gun) + "','" + (elemanlar.sekizDokuz) + "','" + (elemanlar.dokuzOn) + "','" + (elemanlar.onOnbir) + "','" + (elemanlar.onbirOniki) + "','" + (elemanlar.onucOndort) + "','" + (elemanlar.ondortOnbes) + "','" + (elemanlar.onbesOnalti) + "','" + (elemanlar.onaltiOnyedi) + "')", con);
            cmd.ExecuteNonQuery();
            con.Close();
            SqlDataAdapter da = new SqlDataAdapter("Select takvim_gün,takvim_isyeri_adi,[8_9],[9_10],[10_11],[11_12],[13_14],[14_15],[15_16],[16_17] From randevuTakvim", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgvGunler.DataSource = ds.Tables[0];
        }
        public void TalepGonder(RandevuElemanlar elemanlar, bool SekizDokuz, bool DokuzOn, bool OnOnbir, bool OnbirOniki, bool OnucOndort, bool OndortOnbes, bool OnbesOnalti, bool OnaltiOnyedi)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            if (SekizDokuz)
            {
                elemanlar.sekizDokuz = "Onay";
                SqlCommand command = new SqlCommand("Insert Into randevu(randevu_no,randevu_nkullanici_kullanici_adi,randevu_isyeri_adi,randevu_gunu,randevu_saati,randevu_onay_durumu) values ('" + (elemanlar.Randevu_No) + "','" + (elemanlar.Kullanici_Adi) + "','" + (elemanlar.Isyeri_Adi) + "','" + (elemanlar.Randevu_Gun) + "','" + ("8 ile 9 arası") + "','" + (elemanlar.sekizDokuz) + "')", con);
                command.ExecuteNonQuery();
            }

            if (DokuzOn)
            {
                elemanlar.dokuzOn = "Onay";
                SqlCommand command = new SqlCommand("Insert Into randevu(randevu_no,randevu_nkullanici_kullanici_adi,randevu_isyeri_adi,randevu_gunu,randevu_saati,randevu_onay_durumu) values ('" + (elemanlar.Randevu_No) + "','" + (elemanlar.Kullanici_Adi) + "','" + (elemanlar.Isyeri_Adi) + "','" + (elemanlar.Randevu_Gun) + "','" + ("9 ile 10 arası") + "','" + (elemanlar.dokuzOn) + "')", con);
                command.ExecuteNonQuery();
            }

            if (OnOnbir)
            {
                elemanlar.onOnbir = "Onay";
                SqlCommand command = new SqlCommand("Insert Into randevu(randevu_no,randevu_nkullanici_kullanici_adi,randevu_isyeri_adi,randevu_gunu,randevu_saati,randevu_onay_durumu) values ('" + (elemanlar.Randevu_No) + "','" + (elemanlar.Kullanici_Adi) + "','" + (elemanlar.Isyeri_Adi) + "','" + (elemanlar.Randevu_Gun) + "','" + ("10 ile 11 arası") + "','" + (elemanlar.onOnbir) + "')", con);
                command.ExecuteNonQuery();
            }

            if (OnbirOniki)
            {
                elemanlar.onbirOniki = "Onay";
                SqlCommand command = new SqlCommand("Insert Into randevu(randevu_no,randevu_nkullanici_kullanici_adi,randevu_isyeri_adi,randevu_gunu,randevu_saati,randevu_onay_durumu) values ('" + (elemanlar.Randevu_No) + "','" + (elemanlar.Kullanici_Adi) + "','" + (elemanlar.Isyeri_Adi) + "','" + (elemanlar.Randevu_Gun) + "','" + ("11 ile 12 arası") + "','" + (elemanlar.onbirOniki) + "')", con);
                command.ExecuteNonQuery();
            }

            if (OnucOndort)
            {
                elemanlar.onucOndort = "Onay";
                SqlCommand command = new SqlCommand("Insert Into randevu(randevu_no,randevu_nkullanici_kullanici_adi,randevu_isyeri_adi,randevu_gunu,randevu_saati,randevu_onay_durumu) values ('" + (elemanlar.Randevu_No) + "','" + (elemanlar.Kullanici_Adi) + "','" + (elemanlar.Isyeri_Adi) + "','" + (elemanlar.Randevu_Gun) + "','" + ("13 ile 14 arası") + "','" + (elemanlar.onucOndort) + "')", con);
                command.ExecuteNonQuery();
            }

            if (OndortOnbes)
            {
                elemanlar.ondortOnbes = "Onay";
                SqlCommand command = new SqlCommand("Insert Into randevu(randevu_no,randevu_nkullanici_kullanici_adi,randevu_isyeri_adi,randevu_gunu,randevu_saati,randevu_onay_durumu) values ('" + (elemanlar.Randevu_No) + "','" + (elemanlar.Kullanici_Adi) + "','" + (elemanlar.Isyeri_Adi) + "','" + (elemanlar.Randevu_Gun) + "','" + ("14 ile 15 arası") + "','" + (elemanlar.ondortOnbes) + "')", con);
                command.ExecuteNonQuery();
            }

            if (OnbesOnalti)
            {
                elemanlar.onbesOnalti = "Onay";
                SqlCommand command = new SqlCommand("Insert Into randevu(randevu_no,randevu_nkullanici_kullanici_adi,randevu_isyeri_adi,randevu_gunu,randevu_saati,randevu_onay_durumu) values ('" + (elemanlar.Randevu_No) + "','" + (elemanlar.Kullanici_Adi) + "','" + (elemanlar.Isyeri_Adi) + "','" + (elemanlar.Randevu_Gun) + "','" + ("15 ile 16 arası") + "','" + (elemanlar.onbesOnalti) + "')", con);
                command.ExecuteNonQuery();
            }

            if (OnaltiOnyedi)
            {
                elemanlar.onaltiOnyedi = "Onay";
                SqlCommand command = new SqlCommand("Insert Into randevu(randevu_no,randevu_nkullanici_kullanici_adi,randevu_isyeri_adi,randevu_gunu,randevu_saati,randevu_onay_durumu) values ('" + (elemanlar.Randevu_No) + "','" + (elemanlar.Kullanici_Adi) + "','" + (elemanlar.Isyeri_Adi) + "','" + (elemanlar.Randevu_Gun) + "','" + ("16 ile 17 arası") + "','" + (elemanlar.onaltiOnyedi) + "')", con);
                command.ExecuteNonQuery();
            }

            SqlCommand cmd = new SqlCommand("Update randevuTakvim Set [8_9]='" + elemanlar.sekizDokuz + "', [9_10]='" + elemanlar.dokuzOn + "', [10_11]='" + elemanlar.onOnbir + "', [11_12]='" + elemanlar.onbirOniki + "', [13_14]='" + elemanlar.onucOndort + "', [14_15]='" + elemanlar.ondortOnbes + "', [15_16]='" + elemanlar.onbesOnalti + "', [16_17]='" + elemanlar.onaltiOnyedi + "' Where takvim_gün='" + elemanlar.Randevu_Gun + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void RandevuTakvimGoster(DataGridView dgvGunler,RandevuElemanlar elemanlar)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select randevu_no,randevu_isyeri_adi,randevu_nkullanici_kullanici_adi,randevu_gunu,randevu_saati,randevu_onay_durumu From randevu Where randevu_isyeri_adi Like '%" + elemanlar.Isyeri_Adi + "%'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgvGunler.DataSource = ds.Tables[0];
            con.Close();
        }
        public void TalepOnayla(RandevuElemanlar elemanlar)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Update randevu Set randevu_yetkili_kullanici_adi='" + elemanlar.Yetkili_Adi+ "',randevu_onay_durumu='" + elemanlar.Randevu_Onay_Durumu + "' Where randevu_no='" + elemanlar.Randevu_No + "'", con);
            cmd.ExecuteNonQuery();

            if (elemanlar.Randevu_Saat == "8 ile 9 arası" && elemanlar.Randevu_Onay_Durumu == "Onaylandı")
            {
                SqlCommand cmd2 = new SqlCommand("Update randevuTakvim Set [8_9]='" + "Dolu" + "' Where takvim_gün='" + elemanlar.Randevu_Gun + "'", con);
                cmd2.ExecuteNonQuery();
            }
            if (elemanlar.Randevu_Saat == "9 ile 10 arası" && elemanlar.Randevu_Onay_Durumu == "Onaylandı")
            {
                SqlCommand cmd2 = new SqlCommand("Update randevuTakvim Set [9_10]='" + "Dolu" + "' Where takvim_gün='" + elemanlar.Randevu_Gun + "'", con);
                cmd2.ExecuteNonQuery();
            }
            if (elemanlar.Randevu_Saat == "10 ile 11 arası" && elemanlar.Randevu_Onay_Durumu == "Onaylandı")
            {
                SqlCommand cmd2 = new SqlCommand("Update randevuTakvim Set [10_11]='" + "Dolu" + "' Where takvim_gün='" + elemanlar.Randevu_Gun + "'", con);
                cmd2.ExecuteNonQuery();
            }
            if (elemanlar.Randevu_Saat == "11 ile 12 arası" && elemanlar.Randevu_Onay_Durumu == "Onaylandı")
            {
                SqlCommand cmd2 = new SqlCommand("Update randevuTakvim Set [11_12]='" + "Dolu" + "' Where takvim_gün='" + elemanlar.Randevu_Gun + "'", con);
                cmd2.ExecuteNonQuery();
            }
            if (elemanlar.Randevu_Saat == "13 ile 14 arası" && elemanlar.Randevu_Onay_Durumu == "Onaylandı")
            {
                SqlCommand cmd2 = new SqlCommand("Update randevuTakvim Set [13_14]='" + "Dolu" + "' Where takvim_gün='" + elemanlar.Randevu_Gun + "'", con);
                cmd2.ExecuteNonQuery();
            }
            if (elemanlar.Randevu_Saat == "14 ile 15 arası" && elemanlar.Randevu_Onay_Durumu == "Onaylandı")
            {
                SqlCommand cmd2 = new SqlCommand("Update randevuTakvim Set [14_15]='" + "Dolu" + "' Where takvim_gün='" + elemanlar.Randevu_Gun + "'", con);
                cmd2.ExecuteNonQuery();
            }
            if (elemanlar.Randevu_Saat == "15 ile 16 arası" && elemanlar.Randevu_Onay_Durumu == "Onaylandı")
            {
                SqlCommand cmd2 = new SqlCommand("Update randevuTakvim Set [15_16]='" + "Dolu" + "' Where takvim_gün='" + elemanlar.Randevu_Gun + "'", con);
                cmd2.ExecuteNonQuery();
            }
            if (elemanlar.Randevu_Saat == "16 ile 17 arası" && elemanlar.Randevu_Onay_Durumu == "Onaylandı")
            {
                SqlCommand cmd2 = new SqlCommand("Update randevuTakvim Set [16_17]='" + "Dolu" + "' Where takvim_gün='" + elemanlar.Randevu_Gun + "'", con);
                cmd2.ExecuteNonQuery();
            }
            if (elemanlar.Randevu_Saat == "8 ile 9 arası" && elemanlar.Randevu_Onay_Durumu == "Reddedildi")
            {
                SqlCommand cmd2 = new SqlCommand("Update randevuTakvim Set [8_9]='" + "Boş" + "' Where takvim_gün='" + elemanlar.Randevu_Gun + "'", con);
                cmd2.ExecuteNonQuery();
            }
            if (elemanlar.Randevu_Saat == "9 ile 10 arası" && elemanlar.Randevu_Onay_Durumu == "Reddedildi")
            {
                SqlCommand cmd2 = new SqlCommand("Update randevuTakvim Set [9_10]='" + "Boş" + "' Where takvim_gün='" + elemanlar.Randevu_Gun + "'", con);
                cmd2.ExecuteNonQuery();
            }
            if (elemanlar.Randevu_Saat == "10 ile 11 arası" && elemanlar.Randevu_Onay_Durumu == "Reddedildi")
            {
                SqlCommand cmd2 = new SqlCommand("Update randevuTakvim Set [10_11]='" + "Boş" + "' Where takvim_gün='" + elemanlar.Randevu_Gun + "'", con);
                cmd2.ExecuteNonQuery();
            }
            if (elemanlar.Randevu_Saat == "11 ile 12 arası" && elemanlar.Randevu_Onay_Durumu == "Reddedildi")
            {
                SqlCommand cmd2 = new SqlCommand("Update randevuTakvim Set [11_12]='" + "Boş" + "' Where takvim_gün='" + elemanlar.Randevu_Gun + "'", con);
                cmd2.ExecuteNonQuery();
            }
            if (elemanlar.Randevu_Saat == "13 ile 14 arası" && elemanlar.Randevu_Onay_Durumu == "Reddedildi")
            {
                SqlCommand cmd2 = new SqlCommand("Update randevuTakvim Set [13_14]='" + "Boş" + "' Where takvim_gün='" + elemanlar.Randevu_Gun + "'", con);
                cmd2.ExecuteNonQuery();
            }
            if (elemanlar.Randevu_Saat == "14 ile 15 arası" && elemanlar.Randevu_Onay_Durumu == "Reddedildi")
            {
                SqlCommand cmd2 = new SqlCommand("Update randevuTakvim Set [14_15]='" + "Boş" + "' Where takvim_gün='" + elemanlar.Randevu_Gun + "'", con);
                cmd2.ExecuteNonQuery();
            }
            if (elemanlar.Randevu_Saat == "15 ile 16 arası" && elemanlar.Randevu_Onay_Durumu == "Reddedildi")
            {
                SqlCommand cmd2 = new SqlCommand("Update randevuTakvim Set [15_16]='" + "Boş" + "' Where takvim_gün='" + elemanlar.Randevu_Gun + "'", con);
                cmd2.ExecuteNonQuery();
            }
            if (elemanlar.Randevu_Saat == "16 ile 17 arası" && elemanlar.Randevu_Onay_Durumu == "Reddedildi")
            {
                SqlCommand cmd2 = new SqlCommand("Update randevuTakvim Set [16_17]='" + "Boş" + "' Where takvim_gün='" + elemanlar.Randevu_Gun + "'", con);
                cmd2.ExecuteNonQuery();
            }

            con.Close();
        }
        public void NoRandevuAra(DataGridView dgvRandevular,RandevuElemanlar elemanlar)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select randevu_no,randevu_nkullanici_kullanici_adi,randevu_yetkili_kullanici_adi,randevu_gunu,randevu_saati,randevu_onay_durumu From randevu Where randevu_no='"+ elemanlar.Randevu_No+"'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgvRandevular.DataSource = ds.Tables[0];
            con.Close();           
        }
        public void AdRandevuAra(DataGridView dgvRandevular,RandevuElemanlar elemanlar)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select randevu_no,randevu_nkullanici_kullanici_adi,randevu_yetkili_kullanici_adi,randevu_gunu,randevu_saati,randevu_onay_durumu From randevu Where randevu_nkullanici_kullanici_adi Like '%" + elemanlar.Kullanici_Adi + "%'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgvRandevular.DataSource = ds.Tables[0];
            con.Close();
        }

    }
}
