﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Online_Randevu_Sistemi
{
    public class sqlIslemleri
    {
        public string connStr { get; private set; }

        public sqlIslemleri()
        {
            connStr = @"Data Source=DESKTOP-496UL71\MSSQLSERVER01;Initial Catalog=OnlineRandevuSistemi;Integrated Security=True";
        }
    }
}
