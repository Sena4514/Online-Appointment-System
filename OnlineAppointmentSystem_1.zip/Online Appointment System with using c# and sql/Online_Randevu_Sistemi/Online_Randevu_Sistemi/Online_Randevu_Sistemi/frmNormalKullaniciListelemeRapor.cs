﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Online_Randevu_Sistemi
{
    public partial class frmNormalKullaniciListelemeRapor : Form
    {
        

        public frmNormalKullaniciListelemeRapor()
        {
            InitializeComponent();
        }

        NormalKullaniciIslemleri Islemler = new NormalKullaniciIslemleri();
        private void frmNormalKullaniciListelemeRapor_Load(object sender, EventArgs e)
        {
            Islemler.Raporla(dgvNormalKullaniciListelemeRapor);
        }
    }
}
