﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Randevu_Sistemi
{
    public partial class frmGirisEkrani : Form
    {
        public frmGirisEkrani()
        {
            InitializeComponent();
        }

        private void btnGirisYap_Click(object sender, EventArgs e)
        {
            adminGirisBilgileri admin = new adminGirisBilgileri();
            GirisIslemleri Islemler = new GirisIslemleri();
            bool kontrol =true;

            if (admin.adminKullaniciAd == txtKullaniciAdi.Text && admin.adminSifre == txtSifre.Text)
            {

                frmAdminPaneli frmadminPaneli = new frmAdminPaneli();
                this.Hide();
                frmadminPaneli.Show();
            }
            else
            {
                YetkiliElemanlar YElemanlar = new YetkiliElemanlar()
                {
                    yetkili_kullanici_adi=txtKullaniciAdi.Text,
                    yetkili_sifre=txtSifre.Text
                };
                NormalKullaniciElemanlari NElemanlar = new NormalKullaniciElemanlari()
                {
                    nkullanici_kullanici_adi = txtKullaniciAdi.Text,
                    nkullanici_sifre = txtSifre.Text
                };


                if (Islemler.YetkiliGiris(YElemanlar).Read())
                {
                    kontrol = false;
                    frmYetkiliKullaniciPaneli frmyetkiliKullaniciPaneli = new frmYetkiliKullaniciPaneli();
                    this.Hide();
                    frmyetkiliKullaniciPaneli.Show();

                }
                if(Islemler.NormalGiris(NElemanlar).Read())
                {
                    kontrol = false;
                    frmNormalKullaniciPaneli frmnormalKullaniciPaneli = new frmNormalKullaniciPaneli();
                    this.Hide();
                    frmnormalKullaniciPaneli.Show();
                    
                }
                if(kontrol)
                {
                    MessageBox.Show("Kullanici Adinizi veya Sifrenizi Kontrol Ediniz!!!\nEger Sisteme Kayitli Degilseniz Lutfen Oncelikle Kayit Olunuz!!!!");
                }
            }

        }

        private void btnKayitOl_Click(object sender, EventArgs e)
        {
            frmKayitSecenegi frmkayitSecenegi = new frmKayitSecenegi();
            this.Hide();
            frmkayitSecenegi.Show();
        }

        private void btnGirisYap_MouseHover(object sender, EventArgs e)
        {
            btnGirisYap.BackColor = Color.Lavender;
        }

        private void btnGirisYap_MouseLeave(object sender, EventArgs e)
        {
            btnGirisYap.BackColor = Color.MediumTurquoise;
        }

        private void btnKayitOl_MouseHover(object sender, EventArgs e)
        {
            btnKayitOl.BackColor = Color.Lavender;
        }

        private void btnKayitOl_MouseLeave(object sender, EventArgs e)
        {
            btnKayitOl.BackColor = Color.MediumTurquoise;
        }
    }
}
