﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Randevu_Sistemi
{
    public partial class frmSoruGoruntule : Form
    {
        public frmSoruGoruntule()
        {
            InitializeComponent();
        }

        SoruCevap SoruCevap = new SoruCevap();
        SoruCevapElemanlar elemanlar = new SoruCevapElemanlar();

        private void btnSoruGoruntule_Click(object sender, EventArgs e)
        {
            SoruCevap.SorulariListele(dgvSorulistesi);
        }

        private void dgvSorulistesi_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
             elemanlar.Secili_Alan = dgvSorulistesi.SelectedCells[0].RowIndex;
             elemanlar.Soru_No = Convert.ToInt32(dgvSorulistesi.Rows[elemanlar.Secili_Alan].Cells[0].Value);
             elemanlar.Soru_Baslik = dgvSorulistesi.Rows[elemanlar.Secili_Alan].Cells[1].Value.ToString(); 
             elemanlar.Soru = dgvSorulistesi.Rows[elemanlar.Secili_Alan].Cells[4].Value.ToString();

            txtSoru.Text = elemanlar.Soru;
            txtSorubasligi.Text = elemanlar.Soru_Baslik;
            txtSoruNo.Text = elemanlar.Soru_No.ToString();

        }

        private void btnCevapGonder_Click(object sender, EventArgs e)
        {
            elemanlar.Yetkili_adi = txtYetkiliAd.Text;
            elemanlar.Cevap = txtCevap.Text;
            SoruCevap.YanitGonder(elemanlar);
            SoruCevap.SorulariListele(dgvSorulistesi);
            MessageBox.Show("Cevabınız Gönderilmiştir!!");
            txtCevap.Text = txtSoru.Text = txtSorubasligi.Text = txtSoruNo.Text = txtYetkiliAd.Text = "";
        }
    }
}
