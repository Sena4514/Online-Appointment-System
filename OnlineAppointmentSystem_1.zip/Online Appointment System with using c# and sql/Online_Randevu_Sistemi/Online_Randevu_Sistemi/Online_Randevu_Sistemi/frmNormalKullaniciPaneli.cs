﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Randevu_Sistemi
{
    public partial class frmNormalKullaniciPaneli : Form
    {
        public frmNormalKullaniciPaneli()
        {
            InitializeComponent();
        }

        private void işyeriAramaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            frmIsyeriAra frmIsyeriAra = new frmIsyeriAra();
            frmIsyeriAra.MdiParent = this;
            frmIsyeriAra.Show();
        }

        private void işyeriTürüAramaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmNormalKullaniciIsyeriTuruArama frmnormalkullaniciisyerituruarama = new frmNormalKullaniciIsyeriTuruArama();
            frmnormalkullaniciisyerituruarama.MdiParent = this;
            frmnormalkullaniciisyerituruarama.Show();
        }

        private void randevuAlToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmRandevuSaatleriGoster frmrandevuSaatleriGoster = new frmRandevuSaatleriGoster();
            frmrandevuSaatleriGoster.MdiParent = this;
            frmrandevuSaatleriGoster.Show();
        }

        private void yetkiliyeSoruSorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSoruSorma frmSorusorma = new frmSoruSorma();
            frmSorusorma.MdiParent = this;
            frmSorusorma.Show();
        }

        private void cevaplarıGörüntüleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCevapGoruntule frmCevapgoruntule = new frmCevapGoruntule();
            frmCevapgoruntule.MdiParent = this;
            frmCevapgoruntule.Show();
        }

        private void randevularımToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmRandevularım frmrandevularım = new frmRandevularım();
            frmrandevularım.MdiParent = this;
            frmrandevularım.Show();
        }
    }
}
