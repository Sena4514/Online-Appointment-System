﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;


namespace Online_Randevu_Sistemi
{
    class GirisIslemleri:sqlIslemleri
    {
        public SqlDataReader YetkiliGiris(YetkiliElemanlar elemanlar)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from yetkili where yetkili_kullanici_adi = '" + elemanlar.yetkili_kullanici_adi + "' and yetkili_sifre='" + elemanlar.yetkili_sifre + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            return dr;
            con.Close();           
        }


        public SqlDataReader NormalGiris(NormalKullaniciElemanlari elemanlar)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from normalkullanici where nkullanici_kullanici_adi = '" + elemanlar.nkullanici_kullanici_adi + "' and nkullanici_sifre='" + elemanlar.nkullanici_sifre + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            return dr;
            con.Close();
        }
    }
}
