﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Randevu_Sistemi
{
    public partial class frmRandevuSaatleriGoster : Form
    {
        public frmRandevuSaatleriGoster()
        {
            InitializeComponent();
        }

        RandevuElemanlar elemanlar = new RandevuElemanlar();
        RandevuIslemleri Islemler = new RandevuIslemleri();
        private void btnTakvimGoster_Click(object sender, EventArgs e)
        {
            try
            {
                elemanlar.Isyeri_Adi = txtIsyeriAdi.Text;
                Islemler.IsyeriTakvimGoster(dgvGunlerListesi, elemanlar);
                txtRandevuNo.Text = Islemler.RandevuNoAtama().ToString();
                elemanlar.Randevu_No = txtRandevuNo.Text;
            }
            catch(Exception ex){ throw ex; }
            
        }

        bool SekizDokuz = false;
        bool DokuzOn = false;
        bool OnOnbir = false;
        bool OnbirOniki = false;
        bool OnucOndort = false;
        bool OndortOnbes = false;
        bool OnbesOnalti = false;
        bool OnaltiOnyedi = false;

        private void dgvGunlerListesi_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cbx8_9arasi.Visible = false;
            cbx9_10arasi.Visible = false;
            cbx10_11arasi.Visible = false;
            cbx11_12arasi.Visible = false;
            cbx13_14arasi.Visible = false;
            cbx14_15arasi.Visible = false;
            cbx15_16arasi.Visible = false;
            cbx16_17arasi.Visible = false;

            elemanlar.Secili_Alan = dgvGunlerListesi.SelectedCells[0].RowIndex;
            elemanlar.Isyeri_Adi= dgvGunlerListesi.Rows[elemanlar.Secili_Alan].Cells[0].Value.ToString();
            elemanlar.Randevu_Gun = dgvGunlerListesi.Rows[elemanlar.Secili_Alan].Cells[1].Value.ToString();
            elemanlar.sekizDokuz = dgvGunlerListesi.Rows[elemanlar.Secili_Alan].Cells[2].Value.ToString();
            elemanlar.dokuzOn = dgvGunlerListesi.Rows[elemanlar.Secili_Alan].Cells[3].Value.ToString();
            elemanlar.onOnbir = dgvGunlerListesi.Rows[elemanlar.Secili_Alan].Cells[4].Value.ToString();
            elemanlar.onbirOniki = dgvGunlerListesi.Rows[elemanlar.Secili_Alan].Cells[5].Value.ToString();
            elemanlar.onucOndort = dgvGunlerListesi.Rows[elemanlar.Secili_Alan].Cells[6].Value.ToString();
            elemanlar.ondortOnbes = dgvGunlerListesi.Rows[elemanlar.Secili_Alan].Cells[7].Value.ToString();
            elemanlar.onbesOnalti = dgvGunlerListesi.Rows[elemanlar.Secili_Alan].Cells[8].Value.ToString();
            elemanlar.onaltiOnyedi = dgvGunlerListesi.Rows[elemanlar.Secili_Alan].Cells[9].Value.ToString();

            txtSecilenGun.Text = elemanlar.Randevu_Gun;
            txtSecilenIsyeri.Text = elemanlar.Isyeri_Adi;
            if (elemanlar.sekizDokuz == "Boş")
                cbx8_9arasi.Visible = true;
            if (elemanlar.dokuzOn == "Boş")
                cbx9_10arasi.Visible = true;
            if (elemanlar.onOnbir == "Boş")
                cbx10_11arasi.Visible = true;
            if (elemanlar.onbirOniki == "Boş")
                cbx11_12arasi.Visible = true;
            if (elemanlar.onucOndort == "Boş")
                cbx13_14arasi.Visible = true;
            if (elemanlar.ondortOnbes == "Boş")
                cbx14_15arasi.Visible = true;
            if (elemanlar.onbesOnalti == "Boş")
                cbx15_16arasi.Visible = true;
            if (elemanlar.onaltiOnyedi == "Boş")
                cbx16_17arasi.Visible = true;

        }
        private void btnRandevuTalebiGonder_Click(object sender, EventArgs e)
        {
            try
            {
                elemanlar.Kullanici_Adi = txtKullaniciAdi.Text;
                Islemler.TalepGonder(elemanlar, SekizDokuz, DokuzOn, OnOnbir, OnbirOniki, OnucOndort, OndortOnbes, OnbesOnalti, OnaltiOnyedi);
                Islemler.IsyeriTakvimGoster(dgvGunlerListesi, elemanlar);

                txtIsyeriAdi.Clear();
                txtKullaniciAdi.Clear();
                txtRandevuNo.Clear();
                txtSecilenGun.Clear();
                txtSecilenIsyeri.Clear();
                cbx8_9arasi.Checked = false;
                cbx9_10arasi.Checked = false;
                cbx10_11arasi.Checked = false;
                cbx11_12arasi.Checked = false;
                cbx13_14arasi.Checked = false;
                cbx14_15arasi.Checked = false;
                cbx15_16arasi.Checked = false;
                cbx16_17arasi.Checked = false;
                MessageBox.Show("Randevu talebiniz alınmıştır!!!");
            }
            catch(Exception)
            {
                MessageBox.Show("Randevu talebiniz gönderilmemiştir!!");
            }
        }

        private void cbx8_9arasi_CheckedChanged(object sender, EventArgs e)
        {
            if (SekizDokuz)
                SekizDokuz = false;
            else
                SekizDokuz = true;
        }

        private void cbx9_10arasi_CheckedChanged(object sender, EventArgs e)
        {
            if (DokuzOn)
                DokuzOn = false;
            else
                DokuzOn = true;
        }

        private void cbx10_11arasi_CheckedChanged(object sender, EventArgs e)
        {
            if (OnOnbir)
                OnOnbir = false;
            else
                OnOnbir = true;
        }

        private void cbx11_12arasi_CheckedChanged(object sender, EventArgs e)
        {
            if (OnbirOniki)
                OnbirOniki = false;
            else
                OnbirOniki = true;

        }

        private void cbx13_14arasi_CheckedChanged(object sender, EventArgs e)
        {
            if (OnucOndort)
                OnucOndort = false;
            else
                OnucOndort = true;
        }

        private void cbx14_15arasi_CheckedChanged(object sender, EventArgs e)
        {
            if (OndortOnbes)
                OndortOnbes = false;
            else
                OndortOnbes = true;
        }

        private void cbx15_16arasi_CheckedChanged(object sender, EventArgs e)
        {
            if (OnbesOnalti)
                OnbesOnalti = false;
            else
                OnbesOnalti = true;
        }

        private void cbx16_17arasi_CheckedChanged(object sender, EventArgs e)
        {
            if (OnaltiOnyedi)
                OnaltiOnyedi = false;
            else
                OnaltiOnyedi = true;
        }
    }
}
