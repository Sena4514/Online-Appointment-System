﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Online_Randevu_Sistemi
{
    public class YetkiliSql : sqlIslemleri
    {
        public void YetkiliKayit(Yetkili isyeriyetkili)
        {
            try
            {
                SqlConnection con = new SqlConnection(connStr);
                SqlCommand cmd = new SqlCommand("Insert Into yetkili(yetkili_kullanici_adi,yetkili_sifre,yetkili_isim,yetkili_soyisim,yetkili_adres,yetkili_email,yetkili_telNo,yetkili_dogumTarihi,yetkili_TcNo,yetkili_isyeri_adi) values (@yetkili_kullanici_adi,@yetkili_sifre,@yetkili_isim,@yetkili_soyisim,@yetkili_adres,@yetkili_email,@yetkili_telNo,@yetkili_dogumTarihi,@yetkili_TcNo,@yetkili_isyeri_adi)", con);
                cmd.Parameters.AddWithValue("yetkili_kullanici_adi", isyeriyetkili.yetkili_kullanici_adi);
                cmd.Parameters.AddWithValue("yetkili_sifre", isyeriyetkili.yetkili_sifre);
                cmd.Parameters.AddWithValue("yetkili_isim", isyeriyetkili.yetkili_isim);
                cmd.Parameters.AddWithValue("yetkili_soyisim", isyeriyetkili.yetkili_soyisim);
                cmd.Parameters.AddWithValue("yetkili_adres", isyeriyetkili.yetkili_adres);
                cmd.Parameters.AddWithValue("yetkili_email", isyeriyetkili.yetkili_email);
                cmd.Parameters.AddWithValue("yetkili_telNo", isyeriyetkili.yetkili_telNo);
                cmd.Parameters.AddWithValue("yetkili_dogumTarihi", isyeriyetkili.yetkili_dogumTarihi);
                cmd.Parameters.AddWithValue("yetkili_TcNo", isyeriyetkili.yetkili_TcNo);
                cmd.Parameters.AddWithValue("yetkili_isyeri_adi", isyeriyetkili.yetkili_isyeri_adi);
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<Yetkili> Listele()
        {
            List<Yetkili> yetkililer = new List<Yetkili>();
            try
            {
                SqlConnection con = new SqlConnection(connStr);
                SqlCommand cmd = new SqlCommand("Select * From yetkili", con);
                con.Open();

                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            var isyeriyetkili = new Yetkili
                            {
                                yetkili_kullanici_adi = reader.GetString(0),
                                yetkili_sifre = reader.GetString(1),
                                yetkili_isim = reader.GetString(2),
                                yetkili_soyisim = reader.GetString(3),
                                yetkili_adres = reader.GetString(4),
                                yetkili_email = reader.GetString(5),
                                yetkili_telNo = reader.GetString(6),
                                yetkili_dogumTarihi = reader.GetString(7),
                                yetkili_TcNo = reader.GetString(8),
                                yetkili_isyeri_adi = reader.GetString(9)
                            };
                            yetkililer.Add(isyeriyetkili);
                        }
                    }
                }
                return yetkililer;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

