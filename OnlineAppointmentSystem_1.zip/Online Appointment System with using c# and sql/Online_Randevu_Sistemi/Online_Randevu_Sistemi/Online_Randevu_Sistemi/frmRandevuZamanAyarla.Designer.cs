﻿
namespace Online_Randevu_Sistemi
{
    partial class frmRandevuZamanAyarla
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvGunlerListesi = new System.Windows.Forms.DataGridView();
            this.btnGünEkleGuncele = new System.Windows.Forms.Button();
            this.cbx8_9arasi = new System.Windows.Forms.CheckBox();
            this.cbx10_11arasi = new System.Windows.Forms.CheckBox();
            this.cbx9_10arasi = new System.Windows.Forms.CheckBox();
            this.cbx11_12arasi = new System.Windows.Forms.CheckBox();
            this.cbx13_14arasi = new System.Windows.Forms.CheckBox();
            this.cbx14_15arasi = new System.Windows.Forms.CheckBox();
            this.cbx15_16arasi = new System.Windows.Forms.CheckBox();
            this.cbx16_17arasi = new System.Windows.Forms.CheckBox();
            this.lblGun = new System.Windows.Forms.Label();
            this.txtIsyeriAdi = new System.Windows.Forms.TextBox();
            this.lblIsyeriAdi = new System.Windows.Forms.Label();
            this.brnIsyeriGir = new System.Windows.Forms.Button();
            this.comboGunler = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGunlerListesi)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvGunlerListesi
            // 
            this.dgvGunlerListesi.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvGunlerListesi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGunlerListesi.Location = new System.Drawing.Point(375, 12);
            this.dgvGunlerListesi.Name = "dgvGunlerListesi";
            this.dgvGunlerListesi.Size = new System.Drawing.Size(484, 455);
            this.dgvGunlerListesi.TabIndex = 0;
            this.dgvGunlerListesi.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGunlerListesi_CellClick);
            // 
            // btnGünEkleGuncele
            // 
            this.btnGünEkleGuncele.Location = new System.Drawing.Point(170, 426);
            this.btnGünEkleGuncele.Name = "btnGünEkleGuncele";
            this.btnGünEkleGuncele.Size = new System.Drawing.Size(100, 36);
            this.btnGünEkleGuncele.TabIndex = 10;
            this.btnGünEkleGuncele.Text = "Gün Ekle ve ya Güncelle";
            this.btnGünEkleGuncele.UseVisualStyleBackColor = true;
            this.btnGünEkleGuncele.Click += new System.EventHandler(this.btnGünEkleGuncele_Click);
            // 
            // cbx8_9arasi
            // 
            this.cbx8_9arasi.AutoSize = true;
            this.cbx8_9arasi.Location = new System.Drawing.Point(179, 242);
            this.cbx8_9arasi.Name = "cbx8_9arasi";
            this.cbx8_9arasi.Size = new System.Drawing.Size(79, 17);
            this.cbx8_9arasi.TabIndex = 11;
            this.cbx8_9arasi.Text = "8 ile 9 arası";
            this.cbx8_9arasi.UseVisualStyleBackColor = true;
            this.cbx8_9arasi.CheckedChanged += new System.EventHandler(this.cbx8_9arasi_CheckedChanged);
            // 
            // cbx10_11arasi
            // 
            this.cbx10_11arasi.AutoSize = true;
            this.cbx10_11arasi.Location = new System.Drawing.Point(179, 288);
            this.cbx10_11arasi.Name = "cbx10_11arasi";
            this.cbx10_11arasi.Size = new System.Drawing.Size(91, 17);
            this.cbx10_11arasi.TabIndex = 12;
            this.cbx10_11arasi.Text = "10 ile 11 arası";
            this.cbx10_11arasi.UseVisualStyleBackColor = true;
            this.cbx10_11arasi.CheckedChanged += new System.EventHandler(this.cbx10_11arasi_CheckedChanged);
            // 
            // cbx9_10arasi
            // 
            this.cbx9_10arasi.AutoSize = true;
            this.cbx9_10arasi.Location = new System.Drawing.Point(179, 265);
            this.cbx9_10arasi.Name = "cbx9_10arasi";
            this.cbx9_10arasi.Size = new System.Drawing.Size(85, 17);
            this.cbx9_10arasi.TabIndex = 12;
            this.cbx9_10arasi.Text = "9 ile 10 arası";
            this.cbx9_10arasi.UseVisualStyleBackColor = true;
            this.cbx9_10arasi.CheckedChanged += new System.EventHandler(this.cbx9_10arasi_CheckedChanged);
            // 
            // cbx11_12arasi
            // 
            this.cbx11_12arasi.AutoSize = true;
            this.cbx11_12arasi.Location = new System.Drawing.Point(179, 311);
            this.cbx11_12arasi.Name = "cbx11_12arasi";
            this.cbx11_12arasi.Size = new System.Drawing.Size(91, 17);
            this.cbx11_12arasi.TabIndex = 13;
            this.cbx11_12arasi.Text = "11 ile 12 arası";
            this.cbx11_12arasi.UseVisualStyleBackColor = true;
            this.cbx11_12arasi.CheckedChanged += new System.EventHandler(this.cbx11_12arasi_CheckedChanged);
            // 
            // cbx13_14arasi
            // 
            this.cbx13_14arasi.AutoSize = true;
            this.cbx13_14arasi.Location = new System.Drawing.Point(179, 334);
            this.cbx13_14arasi.Name = "cbx13_14arasi";
            this.cbx13_14arasi.Size = new System.Drawing.Size(91, 17);
            this.cbx13_14arasi.TabIndex = 14;
            this.cbx13_14arasi.Text = "13 ile 14 arası";
            this.cbx13_14arasi.UseVisualStyleBackColor = true;
            this.cbx13_14arasi.CheckedChanged += new System.EventHandler(this.cbx13_14arasi_CheckedChanged);
            // 
            // cbx14_15arasi
            // 
            this.cbx14_15arasi.AutoSize = true;
            this.cbx14_15arasi.Location = new System.Drawing.Point(179, 357);
            this.cbx14_15arasi.Name = "cbx14_15arasi";
            this.cbx14_15arasi.Size = new System.Drawing.Size(91, 17);
            this.cbx14_15arasi.TabIndex = 15;
            this.cbx14_15arasi.Text = "14 ile 15 arası";
            this.cbx14_15arasi.UseVisualStyleBackColor = true;
            this.cbx14_15arasi.CheckedChanged += new System.EventHandler(this.cbx14_15arasi_CheckedChanged);
            // 
            // cbx15_16arasi
            // 
            this.cbx15_16arasi.AutoSize = true;
            this.cbx15_16arasi.Location = new System.Drawing.Point(179, 380);
            this.cbx15_16arasi.Name = "cbx15_16arasi";
            this.cbx15_16arasi.Size = new System.Drawing.Size(91, 17);
            this.cbx15_16arasi.TabIndex = 16;
            this.cbx15_16arasi.Text = "15 ile 16 arası";
            this.cbx15_16arasi.UseVisualStyleBackColor = true;
            this.cbx15_16arasi.CheckedChanged += new System.EventHandler(this.cbx15_16arasi_CheckedChanged);
            // 
            // cbx16_17arasi
            // 
            this.cbx16_17arasi.AutoSize = true;
            this.cbx16_17arasi.Location = new System.Drawing.Point(179, 403);
            this.cbx16_17arasi.Name = "cbx16_17arasi";
            this.cbx16_17arasi.Size = new System.Drawing.Size(91, 17);
            this.cbx16_17arasi.TabIndex = 17;
            this.cbx16_17arasi.Text = "16 ile 17 arası";
            this.cbx16_17arasi.UseVisualStyleBackColor = true;
            this.cbx16_17arasi.CheckedChanged += new System.EventHandler(this.cbx16_17arasi_CheckedChanged);
            // 
            // lblGun
            // 
            this.lblGun.AutoSize = true;
            this.lblGun.Location = new System.Drawing.Point(106, 219);
            this.lblGun.Name = "lblGun";
            this.lblGun.Size = new System.Drawing.Size(67, 13);
            this.lblGun.TabIndex = 18;
            this.lblGun.Text = "Günü Giriniz:";
            // 
            // txtIsyeriAdi
            // 
            this.txtIsyeriAdi.Location = new System.Drawing.Point(179, 43);
            this.txtIsyeriAdi.Name = "txtIsyeriAdi";
            this.txtIsyeriAdi.Size = new System.Drawing.Size(100, 20);
            this.txtIsyeriAdi.TabIndex = 19;
            // 
            // lblIsyeriAdi
            // 
            this.lblIsyeriAdi.AutoSize = true;
            this.lblIsyeriAdi.Location = new System.Drawing.Point(93, 46);
            this.lblIsyeriAdi.Name = "lblIsyeriAdi";
            this.lblIsyeriAdi.Size = new System.Drawing.Size(80, 13);
            this.lblIsyeriAdi.TabIndex = 20;
            this.lblIsyeriAdi.Text = "İsyerinizi Giriniz:";
            // 
            // brnIsyeriGir
            // 
            this.brnIsyeriGir.Location = new System.Drawing.Point(179, 87);
            this.brnIsyeriGir.Name = "brnIsyeriGir";
            this.brnIsyeriGir.Size = new System.Drawing.Size(100, 36);
            this.brnIsyeriGir.TabIndex = 21;
            this.brnIsyeriGir.Text = "İşyeri Gir";
            this.brnIsyeriGir.UseVisualStyleBackColor = true;
            this.brnIsyeriGir.Click += new System.EventHandler(this.brnIsyeriGir_Click);
            // 
            // comboGunler
            // 
            this.comboGunler.FormattingEnabled = true;
            this.comboGunler.Items.AddRange(new object[] {
            "Pazartesi",
            "Salı",
            "Çarşamba",
            "Perşembe",
            "Cuma",
            "Cumartesi",
            "Pazar"});
            this.comboGunler.Location = new System.Drawing.Point(170, 216);
            this.comboGunler.Name = "comboGunler";
            this.comboGunler.Size = new System.Drawing.Size(121, 21);
            this.comboGunler.TabIndex = 22;
            // 
            // frmRandevuZamanAyarla
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(863, 474);
            this.Controls.Add(this.comboGunler);
            this.Controls.Add(this.brnIsyeriGir);
            this.Controls.Add(this.lblIsyeriAdi);
            this.Controls.Add(this.txtIsyeriAdi);
            this.Controls.Add(this.lblGun);
            this.Controls.Add(this.cbx16_17arasi);
            this.Controls.Add(this.cbx15_16arasi);
            this.Controls.Add(this.cbx14_15arasi);
            this.Controls.Add(this.cbx13_14arasi);
            this.Controls.Add(this.cbx11_12arasi);
            this.Controls.Add(this.cbx9_10arasi);
            this.Controls.Add(this.cbx10_11arasi);
            this.Controls.Add(this.cbx8_9arasi);
            this.Controls.Add(this.btnGünEkleGuncele);
            this.Controls.Add(this.dgvGunlerListesi);
            this.Name = "frmRandevuZamanAyarla";
            this.Text = "Randevu Zaman Ayarla";
            this.Load += new System.EventHandler(this.frmRandevuZamanAyarla_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGunlerListesi)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvGunlerListesi;
        private System.Windows.Forms.Button btnGünEkleGuncele;
        private System.Windows.Forms.CheckBox cbx8_9arasi;
        private System.Windows.Forms.CheckBox cbx10_11arasi;
        private System.Windows.Forms.CheckBox cbx9_10arasi;
        private System.Windows.Forms.CheckBox cbx11_12arasi;
        private System.Windows.Forms.CheckBox cbx13_14arasi;
        private System.Windows.Forms.CheckBox cbx14_15arasi;
        private System.Windows.Forms.CheckBox cbx15_16arasi;
        private System.Windows.Forms.CheckBox cbx16_17arasi;
        private System.Windows.Forms.Label lblGun;
        private System.Windows.Forms.TextBox txtIsyeriAdi;
        private System.Windows.Forms.Label lblIsyeriAdi;
        private System.Windows.Forms.Button brnIsyeriGir;
        private System.Windows.Forms.ComboBox comboGunler;
    }
}