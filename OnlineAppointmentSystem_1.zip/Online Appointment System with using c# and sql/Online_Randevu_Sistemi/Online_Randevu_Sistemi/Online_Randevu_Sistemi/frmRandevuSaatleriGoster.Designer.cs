﻿
namespace Online_Randevu_Sistemi
{
    partial class frmRandevuSaatleriGoster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvGunlerListesi = new System.Windows.Forms.DataGridView();
            this.cbx8_9arasi = new System.Windows.Forms.CheckBox();
            this.cbx9_10arasi = new System.Windows.Forms.CheckBox();
            this.cbx10_11arasi = new System.Windows.Forms.CheckBox();
            this.cbx11_12arasi = new System.Windows.Forms.CheckBox();
            this.cbx13_14arasi = new System.Windows.Forms.CheckBox();
            this.cbx14_15arasi = new System.Windows.Forms.CheckBox();
            this.cbx15_16arasi = new System.Windows.Forms.CheckBox();
            this.cbx16_17arasi = new System.Windows.Forms.CheckBox();
            this.txtSecilenGun = new System.Windows.Forms.TextBox();
            this.lblGun = new System.Windows.Forms.Label();
            this.btnRandevuTalebiGonder = new System.Windows.Forms.Button();
            this.txtKullaniciAdi = new System.Windows.Forms.TextBox();
            this.lblKullaniciAdi = new System.Windows.Forms.Label();
            this.txtRandevuNo = new System.Windows.Forms.TextBox();
            this.btnTakvimGoster = new System.Windows.Forms.Button();
            this.txtIsyeriAdi = new System.Windows.Forms.TextBox();
            this.lnlRandevuNo = new System.Windows.Forms.Label();
            this.lblIsyeriAdi = new System.Windows.Forms.Label();
            this.txtSecilenIsyeri = new System.Windows.Forms.TextBox();
            this.lblSecilenIsyeri = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGunlerListesi)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvGunlerListesi
            // 
            this.dgvGunlerListesi.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvGunlerListesi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGunlerListesi.Location = new System.Drawing.Point(12, 12);
            this.dgvGunlerListesi.Name = "dgvGunlerListesi";
            this.dgvGunlerListesi.Size = new System.Drawing.Size(386, 426);
            this.dgvGunlerListesi.TabIndex = 0;
            this.dgvGunlerListesi.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGunlerListesi_CellClick);
            // 
            // cbx8_9arasi
            // 
            this.cbx8_9arasi.AutoSize = true;
            this.cbx8_9arasi.Location = new System.Drawing.Point(424, 282);
            this.cbx8_9arasi.Name = "cbx8_9arasi";
            this.cbx8_9arasi.Size = new System.Drawing.Size(79, 17);
            this.cbx8_9arasi.TabIndex = 12;
            this.cbx8_9arasi.Text = "8 ile 9 arası";
            this.cbx8_9arasi.UseVisualStyleBackColor = true;
            this.cbx8_9arasi.Visible = false;
            this.cbx8_9arasi.CheckedChanged += new System.EventHandler(this.cbx8_9arasi_CheckedChanged);
            // 
            // cbx9_10arasi
            // 
            this.cbx9_10arasi.AutoSize = true;
            this.cbx9_10arasi.Location = new System.Drawing.Point(509, 282);
            this.cbx9_10arasi.Name = "cbx9_10arasi";
            this.cbx9_10arasi.Size = new System.Drawing.Size(85, 17);
            this.cbx9_10arasi.TabIndex = 19;
            this.cbx9_10arasi.Text = "9 ile 10 arası";
            this.cbx9_10arasi.UseVisualStyleBackColor = true;
            this.cbx9_10arasi.Visible = false;
            this.cbx9_10arasi.CheckedChanged += new System.EventHandler(this.cbx9_10arasi_CheckedChanged);
            // 
            // cbx10_11arasi
            // 
            this.cbx10_11arasi.AutoSize = true;
            this.cbx10_11arasi.Location = new System.Drawing.Point(600, 282);
            this.cbx10_11arasi.Name = "cbx10_11arasi";
            this.cbx10_11arasi.Size = new System.Drawing.Size(91, 17);
            this.cbx10_11arasi.TabIndex = 20;
            this.cbx10_11arasi.Text = "10 ile 11 arası";
            this.cbx10_11arasi.UseVisualStyleBackColor = true;
            this.cbx10_11arasi.Visible = false;
            this.cbx10_11arasi.CheckedChanged += new System.EventHandler(this.cbx10_11arasi_CheckedChanged);
            // 
            // cbx11_12arasi
            // 
            this.cbx11_12arasi.AutoSize = true;
            this.cbx11_12arasi.Location = new System.Drawing.Point(697, 282);
            this.cbx11_12arasi.Name = "cbx11_12arasi";
            this.cbx11_12arasi.Size = new System.Drawing.Size(91, 17);
            this.cbx11_12arasi.TabIndex = 21;
            this.cbx11_12arasi.Text = "11 ile 12 arası";
            this.cbx11_12arasi.UseVisualStyleBackColor = true;
            this.cbx11_12arasi.Visible = false;
            this.cbx11_12arasi.CheckedChanged += new System.EventHandler(this.cbx11_12arasi_CheckedChanged);
            // 
            // cbx13_14arasi
            // 
            this.cbx13_14arasi.AutoSize = true;
            this.cbx13_14arasi.Location = new System.Drawing.Point(412, 333);
            this.cbx13_14arasi.Name = "cbx13_14arasi";
            this.cbx13_14arasi.Size = new System.Drawing.Size(91, 17);
            this.cbx13_14arasi.TabIndex = 22;
            this.cbx13_14arasi.Text = "13 ile 14 arası";
            this.cbx13_14arasi.UseVisualStyleBackColor = true;
            this.cbx13_14arasi.Visible = false;
            this.cbx13_14arasi.CheckedChanged += new System.EventHandler(this.cbx13_14arasi_CheckedChanged);
            // 
            // cbx14_15arasi
            // 
            this.cbx14_15arasi.AutoSize = true;
            this.cbx14_15arasi.Location = new System.Drawing.Point(509, 333);
            this.cbx14_15arasi.Name = "cbx14_15arasi";
            this.cbx14_15arasi.Size = new System.Drawing.Size(91, 17);
            this.cbx14_15arasi.TabIndex = 23;
            this.cbx14_15arasi.Text = "14 ile 15 arası";
            this.cbx14_15arasi.UseVisualStyleBackColor = true;
            this.cbx14_15arasi.Visible = false;
            this.cbx14_15arasi.CheckedChanged += new System.EventHandler(this.cbx14_15arasi_CheckedChanged);
            // 
            // cbx15_16arasi
            // 
            this.cbx15_16arasi.AutoSize = true;
            this.cbx15_16arasi.Location = new System.Drawing.Point(600, 333);
            this.cbx15_16arasi.Name = "cbx15_16arasi";
            this.cbx15_16arasi.Size = new System.Drawing.Size(91, 17);
            this.cbx15_16arasi.TabIndex = 24;
            this.cbx15_16arasi.Text = "15 ile 16 arası";
            this.cbx15_16arasi.UseVisualStyleBackColor = true;
            this.cbx15_16arasi.Visible = false;
            this.cbx15_16arasi.CheckedChanged += new System.EventHandler(this.cbx15_16arasi_CheckedChanged);
            // 
            // cbx16_17arasi
            // 
            this.cbx16_17arasi.AutoSize = true;
            this.cbx16_17arasi.Location = new System.Drawing.Point(697, 333);
            this.cbx16_17arasi.Name = "cbx16_17arasi";
            this.cbx16_17arasi.Size = new System.Drawing.Size(91, 17);
            this.cbx16_17arasi.TabIndex = 25;
            this.cbx16_17arasi.Text = "16 ile 17 arası";
            this.cbx16_17arasi.UseVisualStyleBackColor = true;
            this.cbx16_17arasi.Visible = false;
            this.cbx16_17arasi.CheckedChanged += new System.EventHandler(this.cbx16_17arasi_CheckedChanged);
            // 
            // txtSecilenGun
            // 
            this.txtSecilenGun.Enabled = false;
            this.txtSecilenGun.Location = new System.Drawing.Point(539, 221);
            this.txtSecilenGun.Name = "txtSecilenGun";
            this.txtSecilenGun.Size = new System.Drawing.Size(100, 20);
            this.txtSecilenGun.TabIndex = 26;
            // 
            // lblGun
            // 
            this.lblGun.AutoSize = true;
            this.lblGun.Location = new System.Drawing.Point(455, 224);
            this.lblGun.Name = "lblGun";
            this.lblGun.Size = new System.Drawing.Size(78, 13);
            this.lblGun.TabIndex = 27;
            this.lblGun.Text = "Seçtiğiniz Gün:";
            // 
            // btnRandevuTalebiGonder
            // 
            this.btnRandevuTalebiGonder.Location = new System.Drawing.Point(540, 396);
            this.btnRandevuTalebiGonder.Name = "btnRandevuTalebiGonder";
            this.btnRandevuTalebiGonder.Size = new System.Drawing.Size(100, 42);
            this.btnRandevuTalebiGonder.TabIndex = 28;
            this.btnRandevuTalebiGonder.Text = "Randevu Talebini Gönder";
            this.btnRandevuTalebiGonder.UseVisualStyleBackColor = true;
            this.btnRandevuTalebiGonder.Click += new System.EventHandler(this.btnRandevuTalebiGonder_Click);
            // 
            // txtKullaniciAdi
            // 
            this.txtKullaniciAdi.Location = new System.Drawing.Point(540, 195);
            this.txtKullaniciAdi.Name = "txtKullaniciAdi";
            this.txtKullaniciAdi.Size = new System.Drawing.Size(100, 20);
            this.txtKullaniciAdi.TabIndex = 30;
            // 
            // lblKullaniciAdi
            // 
            this.lblKullaniciAdi.AutoSize = true;
            this.lblKullaniciAdi.Location = new System.Drawing.Point(420, 198);
            this.lblKullaniciAdi.Name = "lblKullaniciAdi";
            this.lblKullaniciAdi.Size = new System.Drawing.Size(113, 13);
            this.lblKullaniciAdi.TabIndex = 31;
            this.lblKullaniciAdi.Text = "Kullanıcı Adınızı Giriniz:";
            // 
            // txtRandevuNo
            // 
            this.txtRandevuNo.Enabled = false;
            this.txtRandevuNo.Location = new System.Drawing.Point(539, 169);
            this.txtRandevuNo.Name = "txtRandevuNo";
            this.txtRandevuNo.Size = new System.Drawing.Size(100, 20);
            this.txtRandevuNo.TabIndex = 32;
            // 
            // btnTakvimGoster
            // 
            this.btnTakvimGoster.Location = new System.Drawing.Point(540, 81);
            this.btnTakvimGoster.Name = "btnTakvimGoster";
            this.btnTakvimGoster.Size = new System.Drawing.Size(100, 42);
            this.btnTakvimGoster.TabIndex = 34;
            this.btnTakvimGoster.Text = "İşyeri Takvimini Göster";
            this.btnTakvimGoster.UseVisualStyleBackColor = true;
            this.btnTakvimGoster.Click += new System.EventHandler(this.btnTakvimGoster_Click);
            // 
            // txtIsyeriAdi
            // 
            this.txtIsyeriAdi.Location = new System.Drawing.Point(540, 41);
            this.txtIsyeriAdi.Name = "txtIsyeriAdi";
            this.txtIsyeriAdi.Size = new System.Drawing.Size(100, 20);
            this.txtIsyeriAdi.TabIndex = 35;
            // 
            // lnlRandevuNo
            // 
            this.lnlRandevuNo.AutoSize = true;
            this.lnlRandevuNo.Location = new System.Drawing.Point(426, 172);
            this.lnlRandevuNo.Name = "lnlRandevuNo";
            this.lnlRandevuNo.Size = new System.Drawing.Size(107, 13);
            this.lnlRandevuNo.TabIndex = 36;
            this.lnlRandevuNo.Text = "Randevu Numaranız:";
            // 
            // lblIsyeriAdi
            // 
            this.lblIsyeriAdi.AutoSize = true;
            this.lblIsyeriAdi.Location = new System.Drawing.Point(426, 44);
            this.lblIsyeriAdi.Name = "lblIsyeriAdi";
            this.lblIsyeriAdi.Size = new System.Drawing.Size(52, 13);
            this.lblIsyeriAdi.TabIndex = 37;
            this.lblIsyeriAdi.Text = "İşyeri Adı:";
            // 
            // txtSecilenIsyeri
            // 
            this.txtSecilenIsyeri.Enabled = false;
            this.txtSecilenIsyeri.Location = new System.Drawing.Point(539, 247);
            this.txtSecilenIsyeri.Name = "txtSecilenIsyeri";
            this.txtSecilenIsyeri.Size = new System.Drawing.Size(100, 20);
            this.txtSecilenIsyeri.TabIndex = 38;
            // 
            // lblSecilenIsyeri
            // 
            this.lblSecilenIsyeri.AutoSize = true;
            this.lblSecilenIsyeri.Location = new System.Drawing.Point(451, 250);
            this.lblSecilenIsyeri.Name = "lblSecilenIsyeri";
            this.lblSecilenIsyeri.Size = new System.Drawing.Size(82, 13);
            this.lblSecilenIsyeri.TabIndex = 39;
            this.lblSecilenIsyeri.Text = "Seçtiğiniz İşyeri:";
            // 
            // frmRandevuSaatleriGoster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblSecilenIsyeri);
            this.Controls.Add(this.txtSecilenIsyeri);
            this.Controls.Add(this.lblIsyeriAdi);
            this.Controls.Add(this.lnlRandevuNo);
            this.Controls.Add(this.txtIsyeriAdi);
            this.Controls.Add(this.btnTakvimGoster);
            this.Controls.Add(this.txtRandevuNo);
            this.Controls.Add(this.lblKullaniciAdi);
            this.Controls.Add(this.txtKullaniciAdi);
            this.Controls.Add(this.btnRandevuTalebiGonder);
            this.Controls.Add(this.lblGun);
            this.Controls.Add(this.txtSecilenGun);
            this.Controls.Add(this.cbx16_17arasi);
            this.Controls.Add(this.cbx15_16arasi);
            this.Controls.Add(this.cbx14_15arasi);
            this.Controls.Add(this.cbx13_14arasi);
            this.Controls.Add(this.cbx11_12arasi);
            this.Controls.Add(this.cbx10_11arasi);
            this.Controls.Add(this.cbx9_10arasi);
            this.Controls.Add(this.cbx8_9arasi);
            this.Controls.Add(this.dgvGunlerListesi);
            this.Name = "frmRandevuSaatleriGoster";
            this.Text = "Randevu Saatleri Goster";
            ((System.ComponentModel.ISupportInitialize)(this.dgvGunlerListesi)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvGunlerListesi;
        private System.Windows.Forms.CheckBox cbx8_9arasi;
        private System.Windows.Forms.CheckBox cbx9_10arasi;
        private System.Windows.Forms.CheckBox cbx10_11arasi;
        private System.Windows.Forms.CheckBox cbx11_12arasi;
        private System.Windows.Forms.CheckBox cbx13_14arasi;
        private System.Windows.Forms.CheckBox cbx14_15arasi;
        private System.Windows.Forms.CheckBox cbx15_16arasi;
        private System.Windows.Forms.CheckBox cbx16_17arasi;
        private System.Windows.Forms.TextBox txtSecilenGun;
        private System.Windows.Forms.Label lblGun;
        private System.Windows.Forms.Button btnRandevuTalebiGonder;
        private System.Windows.Forms.TextBox txtKullaniciAdi;
        private System.Windows.Forms.Label lblKullaniciAdi;
        private System.Windows.Forms.TextBox txtRandevuNo;
        private System.Windows.Forms.Button btnTakvimGoster;
        private System.Windows.Forms.TextBox txtIsyeriAdi;
        private System.Windows.Forms.Label lnlRandevuNo;
        private System.Windows.Forms.Label lblIsyeriAdi;
        private System.Windows.Forms.TextBox txtSecilenIsyeri;
        private System.Windows.Forms.Label lblSecilenIsyeri;
    }
}