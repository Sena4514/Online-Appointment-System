﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Online_Randevu_Sistemi
{
    public class IsyeriElemanları
    {
        public string isyeri_adi { get; set; }
        public string isyeri_yetkili_isim { get; set; }
        public string isyeri_yetkili_soyisim { get; set; }
        public string isyeri_turu { get; set; }
        public string isyeri_adres { get; set; }
        public string isyeri_telNo { get; set; }
        public int Secili_Alan { get; set; }
    }
}
