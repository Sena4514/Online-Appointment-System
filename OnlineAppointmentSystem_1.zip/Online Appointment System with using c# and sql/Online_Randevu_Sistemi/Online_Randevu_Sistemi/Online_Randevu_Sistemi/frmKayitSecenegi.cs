﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Randevu_Sistemi
{
    public partial class frmKayitSecenegi : Form
    {
        public frmKayitSecenegi()
        {
            InitializeComponent();
        }

        private void btnNormalKullaniciKayit_Click(object sender, EventArgs e)
        {
            frmNormalKullaniciKayit frmnormalKullaniciKayit = new frmNormalKullaniciKayit();
            this.Hide();
            frmnormalKullaniciKayit.Show();
        }

        private void btnIsyeriYetkiliKayit_Click(object sender, EventArgs e)
        {
            frmYetkiliKayit frmyetkiliKayit = new frmYetkiliKayit();
            this.Hide();
            frmyetkiliKayit.Show();
        }
    }
}
