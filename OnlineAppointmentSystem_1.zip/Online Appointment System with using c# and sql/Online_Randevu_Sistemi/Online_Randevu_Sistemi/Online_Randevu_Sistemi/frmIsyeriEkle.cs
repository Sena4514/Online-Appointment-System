﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Randevu_Sistemi
{
    public partial class frmIsyeriEkle : Form
    { 
        public frmIsyeriEkle()
        {
            InitializeComponent();
        }

        IsyeriIslemleri Islemler = new IsyeriIslemleri();
        private void isyeriekle(string isyeriAdi, string isyeriYetkiliIsim, string isyeriYetkiliSoyisim, string isyerTuru, string isyeriAdres,string isyeritelNo)
        {
            IsyeriElemanları elemanlar = new IsyeriElemanları
            {
                isyeri_adi = isyeriAdi,
                isyeri_yetkili_isim = isyeriYetkiliIsim,
                isyeri_yetkili_soyisim= isyeriYetkiliSoyisim,
                isyeri_turu = isyerTuru,
                isyeri_adres = isyeriAdres,
                isyeri_telNo = isyeritelNo
            };
            Islemler.IsyeriEkleme(elemanlar);
        }
        private void IsyeriEklemeListele()
        {
            dgvIsyeriEkle.DataSource = Islemler.Listele();
            dgvIsyeriEkle.Refresh();
        }
        private void btnIsyeriEkle_Click(object sender, EventArgs e)
        {
            try
            {
                isyeriekle(txtIsyeriIsmi.Text, txtIsyeriYetkiliIsmi.Text, txtIsyeriYetkiliSoyismi.Text, txtIsyeriTuru.Text, txtIsyeriAdres.Text, mtbIsyeriTelNo.Text);
                IsyeriEklemeListele();
                MessageBox.Show("Isyeri Basariyla Eklendi!");
                txtIsyeriIsmi.Clear();
                txtIsyeriYetkiliIsmi.Clear();
                txtIsyeriYetkiliSoyismi.Clear();
                txtIsyeriTuru.Clear();
                txtIsyeriAdres.Clear();
                mtbIsyeriTelNo.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Islem Basarisiz!\nHata:" + ex.Message);
            }
        }

    }
}
