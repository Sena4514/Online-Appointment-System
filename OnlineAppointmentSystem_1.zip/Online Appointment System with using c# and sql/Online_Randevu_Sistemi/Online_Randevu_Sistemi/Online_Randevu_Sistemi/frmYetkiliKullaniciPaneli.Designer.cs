﻿
namespace Online_Randevu_Sistemi
{
    partial class frmYetkiliKullaniciPaneli
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.YetkiliKullaniciMenu = new System.Windows.Forms.MenuStrip();
            this.randevuİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.randevuGünleriAyarlaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.randevuOnaylamaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.soruCevapİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sorularıGörüntüleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.YetkiliKullaniciMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // YetkiliKullaniciMenu
            // 
            this.YetkiliKullaniciMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.randevuİşlemleriToolStripMenuItem,
            this.soruCevapİşlemleriToolStripMenuItem});
            this.YetkiliKullaniciMenu.Location = new System.Drawing.Point(0, 0);
            this.YetkiliKullaniciMenu.Name = "YetkiliKullaniciMenu";
            this.YetkiliKullaniciMenu.Size = new System.Drawing.Size(1177, 24);
            this.YetkiliKullaniciMenu.TabIndex = 1;
            this.YetkiliKullaniciMenu.Text = "YetkiliBar";
            // 
            // randevuİşlemleriToolStripMenuItem
            // 
            this.randevuİşlemleriToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.randevuGünleriAyarlaToolStripMenuItem,
            this.randevuOnaylamaToolStripMenuItem});
            this.randevuİşlemleriToolStripMenuItem.Name = "randevuİşlemleriToolStripMenuItem";
            this.randevuİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(112, 20);
            this.randevuİşlemleriToolStripMenuItem.Text = "Randevu İşlemleri";
            // 
            // randevuGünleriAyarlaToolStripMenuItem
            // 
            this.randevuGünleriAyarlaToolStripMenuItem.Name = "randevuGünleriAyarlaToolStripMenuItem";
            this.randevuGünleriAyarlaToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.randevuGünleriAyarlaToolStripMenuItem.Text = "Randevu Günleri Ayarla";
            this.randevuGünleriAyarlaToolStripMenuItem.Click += new System.EventHandler(this.randevuGünleriAyarlaToolStripMenuItem_Click);
            // 
            // randevuOnaylamaToolStripMenuItem
            // 
            this.randevuOnaylamaToolStripMenuItem.Name = "randevuOnaylamaToolStripMenuItem";
            this.randevuOnaylamaToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.randevuOnaylamaToolStripMenuItem.Text = "Randevu Onaylama";
            this.randevuOnaylamaToolStripMenuItem.Click += new System.EventHandler(this.randevuOnaylamaToolStripMenuItem_Click);
            // 
            // soruCevapİşlemleriToolStripMenuItem
            // 
            this.soruCevapİşlemleriToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sorularıGörüntüleToolStripMenuItem});
            this.soruCevapİşlemleriToolStripMenuItem.Name = "soruCevapİşlemleriToolStripMenuItem";
            this.soruCevapİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(126, 20);
            this.soruCevapİşlemleriToolStripMenuItem.Text = "Soru Cevap İşlemleri";
            this.soruCevapİşlemleriToolStripMenuItem.Click += new System.EventHandler(this.soruCevapİşlemleriToolStripMenuItem_Click);
            // 
            // sorularıGörüntüleToolStripMenuItem
            // 
            this.sorularıGörüntüleToolStripMenuItem.Name = "sorularıGörüntüleToolStripMenuItem";
            this.sorularıGörüntüleToolStripMenuItem.Size = new System.Drawing.Size(67, 22);
            // 
            // frmYetkiliKullaniciPaneli
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1177, 703);
            this.Controls.Add(this.YetkiliKullaniciMenu);
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmYetkiliKullaniciPaneli";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Yetkili Kullanici Paneli";
            this.YetkiliKullaniciMenu.ResumeLayout(false);
            this.YetkiliKullaniciMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip YetkiliKullaniciMenu;
        private System.Windows.Forms.ToolStripMenuItem randevuİşlemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem soruCevapİşlemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sorularıGörüntüleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem randevuGünleriAyarlaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem randevuOnaylamaToolStripMenuItem;
    }
}