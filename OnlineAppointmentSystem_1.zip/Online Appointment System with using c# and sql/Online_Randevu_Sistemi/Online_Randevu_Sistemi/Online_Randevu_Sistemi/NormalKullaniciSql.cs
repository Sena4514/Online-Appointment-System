﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Online_Randevu_Sistemi
{
    public class NormalKullaniciSql : sqlIslemleri
    {
        public void NormalKullaniciKayit(NormalKullanici normalKullanici)
        {
            try
            {
                SqlConnection con = new SqlConnection(connStr);
                SqlCommand cmd = new SqlCommand("Insert Into normalkullanici(nkullanici_kullanici_adi,nkullanici_sifre,nkullanici_isim,nkullanici_soyisim,nkullanici_adres,nkullanici_email,nkullanici_telNo) values (@nkullanici_kullanici_adi,@nkullanici_sifre,@nkullanici_isim,@nkullanici_soyisim,@nkullanici_adres,@nkullanici_email,@nkullanici_telNo)", con);
                cmd.Parameters.AddWithValue("nkullanici_kullanici_adi", normalKullanici.nkullanici_kullanici_adi);
                cmd.Parameters.AddWithValue("nkullanici_sifre",normalKullanici.nkullanici_sifre);
                cmd.Parameters.AddWithValue("nkullanici_isim",normalKullanici.nkullanici_isim);
                cmd.Parameters.AddWithValue("nkullanici_soyisim",normalKullanici.nkullanici_soyisim);
                cmd.Parameters.AddWithValue("nkullanici_adres",normalKullanici.nkullanici_adres);
                cmd.Parameters.AddWithValue("nkullanici_email",normalKullanici.nkullanici_email);
                cmd.Parameters.AddWithValue("nkullanici_telNo", normalKullanici.nkullanici_telNo);
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<NormalKullanici> Listele()
        {
            List<NormalKullanici> normalkullanicilar = new List<NormalKullanici>();
            try
            {
                SqlConnection con = new SqlConnection(connStr);
                SqlCommand cmd = new SqlCommand("Select * From normalkullanici", con);
                con.Open();

                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            var normalKullanici = new NormalKullanici
                            {
                                nkullanici_kullanici_adi = reader.GetString(0),
                                nkullanici_sifre = reader.GetString(1),
                                nkullanici_isim = reader.GetString(2),
                                nkullanici_soyisim = reader.GetString(3),
                                nkullanici_adres = reader.GetString(4),
                                nkullanici_email = reader.GetString(5),
                                nkullanici_telNo = reader.GetString(6)
                            };
                            normalkullanicilar.Add(normalKullanici);
                        }
                    }
                }
                return normalkullanicilar;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
