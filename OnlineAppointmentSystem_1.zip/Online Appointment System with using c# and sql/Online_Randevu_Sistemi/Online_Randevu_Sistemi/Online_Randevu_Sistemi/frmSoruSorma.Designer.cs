﻿
namespace Online_Randevu_Sistemi
{
    partial class frmSoruSorma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblKullaniciAd = new System.Windows.Forms.Label();
            this.lblSoruBaslik = new System.Windows.Forms.Label();
            this.lblSoruNo = new System.Windows.Forms.Label();
            this.txtAd = new System.Windows.Forms.TextBox();
            this.txtSoruNo = new System.Windows.Forms.TextBox();
            this.txtSoruBaslik = new System.Windows.Forms.TextBox();
            this.txtSoyad = new System.Windows.Forms.TextBox();
            this.lblbSoru = new System.Windows.Forms.Label();
            this.txtSoru = new System.Windows.Forms.TextBox();
            this.btnSoruGonder = new System.Windows.Forms.Button();
            this.lblSoyad = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblKullaniciAd
            // 
            this.lblKullaniciAd.AutoSize = true;
            this.lblKullaniciAd.Location = new System.Drawing.Point(248, 55);
            this.lblKullaniciAd.Name = "lblKullaniciAd";
            this.lblKullaniciAd.Size = new System.Drawing.Size(80, 13);
            this.lblKullaniciAd.TabIndex = 0;
            this.lblKullaniciAd.Text = "Kullanıcı Adınız:";
            // 
            // lblSoruBaslik
            // 
            this.lblSoruBaslik.AutoSize = true;
            this.lblSoruBaslik.Location = new System.Drawing.Point(246, 132);
            this.lblSoruBaslik.Name = "lblSoruBaslik";
            this.lblSoruBaslik.Size = new System.Drawing.Size(77, 13);
            this.lblSoruBaslik.TabIndex = 2;
            this.lblSoruBaslik.Text = "Soru başlığınız:";
            // 
            // lblSoruNo
            // 
            this.lblSoruNo.AutoSize = true;
            this.lblSoruNo.Location = new System.Drawing.Point(238, 169);
            this.lblSoruNo.Name = "lblSoruNo";
            this.lblSoruNo.Size = new System.Drawing.Size(85, 13);
            this.lblSoruNo.TabIndex = 3;
            this.lblSoruNo.Text = "Soru Numaranız:";
            // 
            // txtAd
            // 
            this.txtAd.Location = new System.Drawing.Point(334, 52);
            this.txtAd.Name = "txtAd";
            this.txtAd.Size = new System.Drawing.Size(100, 20);
            this.txtAd.TabIndex = 4;
            // 
            // txtSoruNo
            // 
            this.txtSoruNo.Enabled = false;
            this.txtSoruNo.Location = new System.Drawing.Point(334, 166);
            this.txtSoruNo.Name = "txtSoruNo";
            this.txtSoruNo.Size = new System.Drawing.Size(100, 20);
            this.txtSoruNo.TabIndex = 5;
            // 
            // txtSoruBaslik
            // 
            this.txtSoruBaslik.Location = new System.Drawing.Point(334, 129);
            this.txtSoruBaslik.Name = "txtSoruBaslik";
            this.txtSoruBaslik.Size = new System.Drawing.Size(100, 20);
            this.txtSoruBaslik.TabIndex = 6;
            // 
            // txtSoyad
            // 
            this.txtSoyad.Location = new System.Drawing.Point(334, 90);
            this.txtSoyad.Name = "txtSoyad";
            this.txtSoyad.Size = new System.Drawing.Size(100, 20);
            this.txtSoyad.TabIndex = 7;
            // 
            // lblbSoru
            // 
            this.lblbSoru.AutoSize = true;
            this.lblbSoru.Location = new System.Drawing.Point(357, 189);
            this.lblbSoru.Name = "lblbSoru";
            this.lblbSoru.Size = new System.Drawing.Size(49, 13);
            this.lblbSoru.TabIndex = 9;
            this.lblbSoru.Text = "Sorunuz:";
            // 
            // txtSoru
            // 
            this.txtSoru.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoru.Location = new System.Drawing.Point(11, 204);
            this.txtSoru.Margin = new System.Windows.Forms.Padding(2);
            this.txtSoru.Multiline = true;
            this.txtSoru.Name = "txtSoru";
            this.txtSoru.Size = new System.Drawing.Size(778, 220);
            this.txtSoru.TabIndex = 10;
            // 
            // btnSoruGonder
            // 
            this.btnSoruGonder.Location = new System.Drawing.Point(334, 429);
            this.btnSoruGonder.Name = "btnSoruGonder";
            this.btnSoruGonder.Size = new System.Drawing.Size(98, 43);
            this.btnSoruGonder.TabIndex = 11;
            this.btnSoruGonder.Text = "Gönder";
            this.btnSoruGonder.UseVisualStyleBackColor = true;
            this.btnSoruGonder.Click += new System.EventHandler(this.btnSoruGonder_Click);
            // 
            // lblSoyad
            // 
            this.lblSoyad.AutoSize = true;
            this.lblSoyad.Location = new System.Drawing.Point(268, 93);
            this.lblSoyad.Name = "lblSoyad";
            this.lblSoyad.Size = new System.Drawing.Size(55, 13);
            this.lblSoyad.TabIndex = 1;
            this.lblSoyad.Text = "Soyadınız:";
            // 
            // frmSoruSorma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 484);
            this.Controls.Add(this.btnSoruGonder);
            this.Controls.Add(this.txtSoru);
            this.Controls.Add(this.lblbSoru);
            this.Controls.Add(this.txtSoyad);
            this.Controls.Add(this.txtSoruBaslik);
            this.Controls.Add(this.txtSoruNo);
            this.Controls.Add(this.txtAd);
            this.Controls.Add(this.lblSoruNo);
            this.Controls.Add(this.lblSoruBaslik);
            this.Controls.Add(this.lblSoyad);
            this.Controls.Add(this.lblKullaniciAd);
            this.Name = "frmSoruSorma";
            this.Text = "Soru Sorma";
            this.Shown += new System.EventHandler(this.frmSoruSorma_Shown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblKullaniciAd;
        private System.Windows.Forms.Label lblSoruBaslik;
        private System.Windows.Forms.Label lblSoruNo;
        private System.Windows.Forms.TextBox txtAd;
        private System.Windows.Forms.TextBox txtSoruNo;
        private System.Windows.Forms.TextBox txtSoruBaslik;
        private System.Windows.Forms.TextBox txtSoyad;
        private System.Windows.Forms.Label lblbSoru;
        private System.Windows.Forms.TextBox txtSoru;
        private System.Windows.Forms.Button btnSoruGonder;
        private System.Windows.Forms.Label lblSoyad;
    }
}