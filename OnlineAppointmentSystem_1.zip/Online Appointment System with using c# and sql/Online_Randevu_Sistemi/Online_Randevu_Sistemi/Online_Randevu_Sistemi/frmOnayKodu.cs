﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;

namespace Online_Randevu_Sistemi
{
    public partial class frmOnayKodu : Form
    {
        public frmOnayKodu()
        {
            InitializeComponent();
        }

        KayitIslemleri Islemler = new KayitIslemleri();
        NormalKullaniciElemanlari elemanlar = new NormalKullaniciElemanlari();
        private void btnGonder_Click(object sender, EventArgs e)
        {
            elemanlar.nkullanici_email = txtEmailTekrar.Text;
                Islemler.EmailGonder(elemanlar);
                MessageBox.Show("Mail Gonderildi!");
        }

        private void btnDogrula_Click(object sender, EventArgs e)
        {
            if(txtKodDogrulama.Text==elemanlar.Onay_Kodu.ToString())
            {
                MessageBox.Show("Guvenlik Kodu Dogru Girildi!\nGiris Ekranina yonlendirileceksiniz!");
                frmGirisEkrani frmgirisekrani = new frmGirisEkrani();
                this.Hide();
                frmgirisekrani.Show();
            }
            else
            {
                MessageBox.Show("Hatali Guvenlik Kodu Girdiniz!");
            }        
        }
    }
}
