﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Online_Randevu_Sistemi
{
    public class adminGirisBilgileri
    {
        public string adminKullaniciAd = "admin";
        public string adminSifre = "123";
    }
}
