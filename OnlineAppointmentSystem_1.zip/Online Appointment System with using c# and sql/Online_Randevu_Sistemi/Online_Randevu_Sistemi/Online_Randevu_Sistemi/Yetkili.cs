﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Online_Randevu_Sistemi
{
    public class Yetkili
    {
        public string yetkili_kullanici_adi { get; set; }
        public string yetkili_sifre { get; set; }
        public string yetkili_isim { get; set; }
        public string yetkili_soyisim { get; set; }
        public string yetkili_adres { get; set; }
        public string yetkili_email { get; set; }
        public string yetkili_telNo { get; set; }
        public string yetkili_dogumTarihi { get; set; }
        public string yetkili_TcNo { get; set; }
        public string yetkili_isyeri_adi { get; set; }
    }
}
