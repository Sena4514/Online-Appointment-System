﻿
namespace Online_Randevu_Sistemi
{
    partial class frmYetkiliKayit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmYetkiliKayit));
            this.grbYetkiliKullaniciKayit = new System.Windows.Forms.GroupBox();
            this.lblTcKimlikNo = new System.Windows.Forms.Label();
            this.mtbTcKimlikNo = new System.Windows.Forms.MaskedTextBox();
            this.lblDogumTarihi = new System.Windows.Forms.Label();
            this.mtbDogumTarihi = new System.Windows.Forms.MaskedTextBox();
            this.mtbtelNo = new System.Windows.Forms.MaskedTextBox();
            this.lblTelNo = new System.Windows.Forms.Label();
            this.lblAdres = new System.Windows.Forms.Label();
            this.txtadres = new System.Windows.Forms.TextBox();
            this.lblSoyisim = new System.Windows.Forms.Label();
            this.lblIsim = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblSifre = new System.Windows.Forms.Label();
            this.txtsoyisim = new System.Windows.Forms.TextBox();
            this.txtisim = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtsifre = new System.Windows.Forms.TextBox();
            this.txtkullaniciAdi = new System.Windows.Forms.TextBox();
            this.lblKullaniciAdi = new System.Windows.Forms.Label();
            this.btnYetkiliKaydet = new System.Windows.Forms.Button();
            this.ilYetkiliKaydet = new System.Windows.Forms.ImageList(this.components);
            this.txtIsyeriAdi = new System.Windows.Forms.TextBox();
            this.lblIsyeriAdi = new System.Windows.Forms.Label();
            this.grbYetkiliKullaniciKayit.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbYetkiliKullaniciKayit
            // 
            this.grbYetkiliKullaniciKayit.Controls.Add(this.lblIsyeriAdi);
            this.grbYetkiliKullaniciKayit.Controls.Add(this.txtIsyeriAdi);
            this.grbYetkiliKullaniciKayit.Controls.Add(this.lblTcKimlikNo);
            this.grbYetkiliKullaniciKayit.Controls.Add(this.mtbTcKimlikNo);
            this.grbYetkiliKullaniciKayit.Controls.Add(this.lblDogumTarihi);
            this.grbYetkiliKullaniciKayit.Controls.Add(this.mtbDogumTarihi);
            this.grbYetkiliKullaniciKayit.Controls.Add(this.mtbtelNo);
            this.grbYetkiliKullaniciKayit.Controls.Add(this.lblTelNo);
            this.grbYetkiliKullaniciKayit.Controls.Add(this.lblAdres);
            this.grbYetkiliKullaniciKayit.Controls.Add(this.txtadres);
            this.grbYetkiliKullaniciKayit.Controls.Add(this.lblSoyisim);
            this.grbYetkiliKullaniciKayit.Controls.Add(this.lblIsim);
            this.grbYetkiliKullaniciKayit.Controls.Add(this.lblEmail);
            this.grbYetkiliKullaniciKayit.Controls.Add(this.lblSifre);
            this.grbYetkiliKullaniciKayit.Controls.Add(this.txtsoyisim);
            this.grbYetkiliKullaniciKayit.Controls.Add(this.txtisim);
            this.grbYetkiliKullaniciKayit.Controls.Add(this.txtemail);
            this.grbYetkiliKullaniciKayit.Controls.Add(this.txtsifre);
            this.grbYetkiliKullaniciKayit.Controls.Add(this.txtkullaniciAdi);
            this.grbYetkiliKullaniciKayit.Controls.Add(this.lblKullaniciAdi);
            this.grbYetkiliKullaniciKayit.Controls.Add(this.btnYetkiliKaydet);
            this.grbYetkiliKullaniciKayit.Location = new System.Drawing.Point(1, 1);
            this.grbYetkiliKullaniciKayit.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grbYetkiliKullaniciKayit.Name = "grbYetkiliKullaniciKayit";
            this.grbYetkiliKullaniciKayit.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.grbYetkiliKullaniciKayit.Size = new System.Drawing.Size(591, 476);
            this.grbYetkiliKullaniciKayit.TabIndex = 3;
            this.grbYetkiliKullaniciKayit.TabStop = false;
            this.grbYetkiliKullaniciKayit.Text = "Yetkili Kullanıcı Kayıt Formu";
            // 
            // lblTcKimlikNo
            // 
            this.lblTcKimlikNo.AutoSize = true;
            this.lblTcKimlikNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTcKimlikNo.Location = new System.Drawing.Point(288, 209);
            this.lblTcKimlikNo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTcKimlikNo.Name = "lblTcKimlikNo";
            this.lblTcKimlikNo.Size = new System.Drawing.Size(92, 15);
            this.lblTcKimlikNo.TabIndex = 19;
            this.lblTcKimlikNo.Text = "Tc Kimlik No:";
            // 
            // mtbTcKimlikNo
            // 
            this.mtbTcKimlikNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtbTcKimlikNo.Location = new System.Drawing.Point(409, 203);
            this.mtbTcKimlikNo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.mtbTcKimlikNo.Mask = "00000000000";
            this.mtbTcKimlikNo.Name = "mtbTcKimlikNo";
            this.mtbTcKimlikNo.Size = new System.Drawing.Size(133, 23);
            this.mtbTcKimlikNo.TabIndex = 8;
            this.mtbTcKimlikNo.ValidatingType = typeof(int);
            // 
            // lblDogumTarihi
            // 
            this.lblDogumTarihi.AutoSize = true;
            this.lblDogumTarihi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDogumTarihi.Location = new System.Drawing.Point(288, 151);
            this.lblDogumTarihi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDogumTarihi.Name = "lblDogumTarihi";
            this.lblDogumTarihi.Size = new System.Drawing.Size(98, 15);
            this.lblDogumTarihi.TabIndex = 17;
            this.lblDogumTarihi.Text = "Doğum Tarihi:";
            // 
            // mtbDogumTarihi
            // 
            this.mtbDogumTarihi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtbDogumTarihi.Location = new System.Drawing.Point(409, 149);
            this.mtbDogumTarihi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.mtbDogumTarihi.Mask = "00/00/0000";
            this.mtbDogumTarihi.Name = "mtbDogumTarihi";
            this.mtbDogumTarihi.Size = new System.Drawing.Size(133, 23);
            this.mtbDogumTarihi.TabIndex = 7;
            this.mtbDogumTarihi.ValidatingType = typeof(System.DateTime);
            // 
            // mtbtelNo
            // 
            this.mtbtelNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtbtelNo.Location = new System.Drawing.Point(409, 92);
            this.mtbtelNo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.mtbtelNo.Mask = "(999) 000-0000";
            this.mtbtelNo.Name = "mtbtelNo";
            this.mtbtelNo.Size = new System.Drawing.Size(133, 23);
            this.mtbtelNo.TabIndex = 6;
            // 
            // lblTelNo
            // 
            this.lblTelNo.AutoSize = true;
            this.lblTelNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelNo.Location = new System.Drawing.Point(324, 95);
            this.lblTelNo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTelNo.Name = "lblTelNo";
            this.lblTelNo.Size = new System.Drawing.Size(57, 15);
            this.lblTelNo.TabIndex = 13;
            this.lblTelNo.Text = "Tel. No:";
            // 
            // lblAdres
            // 
            this.lblAdres.AutoSize = true;
            this.lblAdres.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdres.Location = new System.Drawing.Point(25, 261);
            this.lblAdres.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAdres.Name = "lblAdres";
            this.lblAdres.Size = new System.Drawing.Size(47, 15);
            this.lblAdres.TabIndex = 12;
            this.lblAdres.Text = "Adres:";
            // 
            // txtadres
            // 
            this.txtadres.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtadres.Location = new System.Drawing.Point(121, 261);
            this.txtadres.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtadres.Multiline = true;
            this.txtadres.Name = "txtadres";
            this.txtadres.Size = new System.Drawing.Size(133, 157);
            this.txtadres.TabIndex = 4;
            // 
            // lblSoyisim
            // 
            this.lblSoyisim.AutoSize = true;
            this.lblSoyisim.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoyisim.Location = new System.Drawing.Point(25, 207);
            this.lblSoyisim.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSoyisim.Name = "lblSoyisim";
            this.lblSoyisim.Size = new System.Drawing.Size(61, 15);
            this.lblSoyisim.TabIndex = 10;
            this.lblSoyisim.Text = "Soyisim:";
            // 
            // lblIsim
            // 
            this.lblIsim.AutoSize = true;
            this.lblIsim.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIsim.Location = new System.Drawing.Point(25, 151);
            this.lblIsim.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblIsim.Name = "lblIsim";
            this.lblIsim.Size = new System.Drawing.Size(38, 15);
            this.lblIsim.TabIndex = 9;
            this.lblIsim.Text = "İsim:";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(335, 38);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(48, 15);
            this.lblEmail.TabIndex = 8;
            this.lblEmail.Text = "Email:";
            // 
            // lblSifre
            // 
            this.lblSifre.AutoSize = true;
            this.lblSifre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSifre.Location = new System.Drawing.Point(25, 95);
            this.lblSifre.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSifre.Name = "lblSifre";
            this.lblSifre.Size = new System.Drawing.Size(41, 15);
            this.lblSifre.TabIndex = 7;
            this.lblSifre.Text = "Şifre:";
            // 
            // txtsoyisim
            // 
            this.txtsoyisim.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsoyisim.Location = new System.Drawing.Point(121, 206);
            this.txtsoyisim.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtsoyisim.Multiline = true;
            this.txtsoyisim.Name = "txtsoyisim";
            this.txtsoyisim.Size = new System.Drawing.Size(133, 32);
            this.txtsoyisim.TabIndex = 3;
            // 
            // txtisim
            // 
            this.txtisim.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtisim.Location = new System.Drawing.Point(121, 149);
            this.txtisim.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtisim.Multiline = true;
            this.txtisim.Name = "txtisim";
            this.txtisim.Size = new System.Drawing.Size(133, 32);
            this.txtisim.TabIndex = 2;
            // 
            // txtemail
            // 
            this.txtemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemail.Location = new System.Drawing.Point(409, 38);
            this.txtemail.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtemail.Multiline = true;
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(175, 32);
            this.txtemail.TabIndex = 5;
            // 
            // txtsifre
            // 
            this.txtsifre.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsifre.Location = new System.Drawing.Point(121, 94);
            this.txtsifre.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtsifre.Multiline = true;
            this.txtsifre.Name = "txtsifre";
            this.txtsifre.PasswordChar = '*';
            this.txtsifre.Size = new System.Drawing.Size(133, 32);
            this.txtsifre.TabIndex = 1;
            // 
            // txtkullaniciAdi
            // 
            this.txtkullaniciAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtkullaniciAdi.Location = new System.Drawing.Point(121, 38);
            this.txtkullaniciAdi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtkullaniciAdi.Multiline = true;
            this.txtkullaniciAdi.Name = "txtkullaniciAdi";
            this.txtkullaniciAdi.Size = new System.Drawing.Size(133, 32);
            this.txtkullaniciAdi.TabIndex = 0;
            // 
            // lblKullaniciAdi
            // 
            this.lblKullaniciAdi.AutoSize = true;
            this.lblKullaniciAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKullaniciAdi.Location = new System.Drawing.Point(25, 39);
            this.lblKullaniciAdi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblKullaniciAdi.Name = "lblKullaniciAdi";
            this.lblKullaniciAdi.Size = new System.Drawing.Size(91, 15);
            this.lblKullaniciAdi.TabIndex = 1;
            this.lblKullaniciAdi.Text = "Kullanıcı Adı:";
            // 
            // btnYetkiliKaydet
            // 
            this.btnYetkiliKaydet.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnYetkiliKaydet.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnYetkiliKaydet.ImageIndex = 0;
            this.btnYetkiliKaydet.ImageList = this.ilYetkiliKaydet;
            this.btnYetkiliKaydet.Location = new System.Drawing.Point(393, 393);
            this.btnYetkiliKaydet.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnYetkiliKaydet.Name = "btnYetkiliKaydet";
            this.btnYetkiliKaydet.Size = new System.Drawing.Size(189, 48);
            this.btnYetkiliKaydet.TabIndex = 9;
            this.btnYetkiliKaydet.Text = "Bilgilerimi Kaydet";
            this.btnYetkiliKaydet.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnYetkiliKaydet.UseVisualStyleBackColor = true;
            this.btnYetkiliKaydet.Click += new System.EventHandler(this.btnYetkiliKaydet_Click);
            // 
            // ilYetkiliKaydet
            // 
            this.ilYetkiliKaydet.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ilYetkiliKaydet.ImageStream")));
            this.ilYetkiliKaydet.TransparentColor = System.Drawing.Color.Transparent;
            this.ilYetkiliKaydet.Images.SetKeyName(0, "save11.jpg");
            // 
            // txtIsyeriAdi
            // 
            this.txtIsyeriAdi.Location = new System.Drawing.Point(409, 261);
            this.txtIsyeriAdi.Name = "txtIsyeriAdi";
            this.txtIsyeriAdi.Size = new System.Drawing.Size(133, 20);
            this.txtIsyeriAdi.TabIndex = 20;
            // 
            // lblIsyeriAdi
            // 
            this.lblIsyeriAdi.AutoSize = true;
            this.lblIsyeriAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIsyeriAdi.Location = new System.Drawing.Point(311, 264);
            this.lblIsyeriAdi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblIsyeriAdi.Name = "lblIsyeriAdi";
            this.lblIsyeriAdi.Size = new System.Drawing.Size(69, 15);
            this.lblIsyeriAdi.TabIndex = 21;
            this.lblIsyeriAdi.Text = "İşyeri adı:";
            // 
            // frmYetkiliKayit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(597, 484);
            this.Controls.Add(this.grbYetkiliKullaniciKayit);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmYetkiliKayit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Yetkili Kullanici Kayit Formu";
            this.grbYetkiliKullaniciKayit.ResumeLayout(false);
            this.grbYetkiliKullaniciKayit.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbYetkiliKullaniciKayit;
        private System.Windows.Forms.Label lblTcKimlikNo;
        private System.Windows.Forms.MaskedTextBox mtbTcKimlikNo;
        private System.Windows.Forms.Label lblDogumTarihi;
        private System.Windows.Forms.MaskedTextBox mtbDogumTarihi;
        private System.Windows.Forms.MaskedTextBox mtbtelNo;
        private System.Windows.Forms.Label lblTelNo;
        private System.Windows.Forms.Label lblAdres;
        private System.Windows.Forms.TextBox txtadres;
        private System.Windows.Forms.Label lblSoyisim;
        private System.Windows.Forms.Label lblIsim;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblSifre;
        private System.Windows.Forms.TextBox txtsoyisim;
        private System.Windows.Forms.TextBox txtisim;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txtsifre;
        private System.Windows.Forms.TextBox txtkullaniciAdi;
        private System.Windows.Forms.Label lblKullaniciAdi;
        private System.Windows.Forms.Button btnYetkiliKaydet;
        private System.Windows.Forms.ImageList ilYetkiliKaydet;
        private System.Windows.Forms.TextBox txtIsyeriAdi;
        private System.Windows.Forms.Label lblIsyeriAdi;
    }
}