﻿
namespace Online_Randevu_Sistemi
{
    partial class frmSoruGoruntule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvSorulistesi = new System.Windows.Forms.DataGridView();
            this.onlineRandevuSistemiDataSet2 = new Online_Randevu_Sistemi.OnlineRandevuSistemiDataSet2();
            this.soruCevapBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.soruCevapTableAdapter = new Online_Randevu_Sistemi.OnlineRandevuSistemiDataSet2TableAdapters.soruCevapTableAdapter();
            this.btnSoruGoruntule = new System.Windows.Forms.Button();
            this.txtSoruNo = new System.Windows.Forms.TextBox();
            this.txtSorubasligi = new System.Windows.Forms.TextBox();
            this.txtSoru = new System.Windows.Forms.TextBox();
            this.txtCevap = new System.Windows.Forms.TextBox();
            this.txtYetkiliAd = new System.Windows.Forms.TextBox();
            this.btnCevapGonder = new System.Windows.Forms.Button();
            this.lblSoruNo = new System.Windows.Forms.Label();
            this.lblSoruBaslik = new System.Windows.Forms.Label();
            this.lblYetkiliKullaniciAdi = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSorulistesi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.onlineRandevuSistemiDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.soruCevapBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvSorulistesi
            // 
            this.dgvSorulistesi.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSorulistesi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSorulistesi.Location = new System.Drawing.Point(475, 12);
            this.dgvSorulistesi.Name = "dgvSorulistesi";
            this.dgvSorulistesi.Size = new System.Drawing.Size(379, 448);
            this.dgvSorulistesi.TabIndex = 0;
            this.dgvSorulistesi.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSorulistesi_CellClick);
            // 
            // onlineRandevuSistemiDataSet2
            // 
            this.onlineRandevuSistemiDataSet2.DataSetName = "OnlineRandevuSistemiDataSet2";
            this.onlineRandevuSistemiDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // soruCevapBindingSource
            // 
            this.soruCevapBindingSource.DataMember = "soruCevap";
            this.soruCevapBindingSource.DataSource = this.onlineRandevuSistemiDataSet2;
            // 
            // soruCevapTableAdapter
            // 
            this.soruCevapTableAdapter.ClearBeforeFill = true;
            // 
            // btnSoruGoruntule
            // 
            this.btnSoruGoruntule.Location = new System.Drawing.Point(574, 466);
            this.btnSoruGoruntule.Name = "btnSoruGoruntule";
            this.btnSoruGoruntule.Size = new System.Drawing.Size(182, 30);
            this.btnSoruGoruntule.TabIndex = 1;
            this.btnSoruGoruntule.Text = "Soruları Görütüle";
            this.btnSoruGoruntule.UseVisualStyleBackColor = true;
            this.btnSoruGoruntule.Click += new System.EventHandler(this.btnSoruGoruntule_Click);
            // 
            // txtSoruNo
            // 
            this.txtSoruNo.Location = new System.Drawing.Point(68, 22);
            this.txtSoruNo.Name = "txtSoruNo";
            this.txtSoruNo.Size = new System.Drawing.Size(100, 20);
            this.txtSoruNo.TabIndex = 2;
            // 
            // txtSorubasligi
            // 
            this.txtSorubasligi.Location = new System.Drawing.Point(317, 22);
            this.txtSorubasligi.Name = "txtSorubasligi";
            this.txtSorubasligi.Size = new System.Drawing.Size(100, 20);
            this.txtSorubasligi.TabIndex = 3;
            // 
            // txtSoru
            // 
            this.txtSoru.Location = new System.Drawing.Point(12, 70);
            this.txtSoru.Multiline = true;
            this.txtSoru.Name = "txtSoru";
            this.txtSoru.Size = new System.Drawing.Size(457, 189);
            this.txtSoru.TabIndex = 4;
            // 
            // txtCevap
            // 
            this.txtCevap.Location = new System.Drawing.Point(12, 291);
            this.txtCevap.Multiline = true;
            this.txtCevap.Name = "txtCevap";
            this.txtCevap.Size = new System.Drawing.Size(457, 169);
            this.txtCevap.TabIndex = 5;
            // 
            // txtYetkiliAd
            // 
            this.txtYetkiliAd.Location = new System.Drawing.Point(190, 265);
            this.txtYetkiliAd.Name = "txtYetkiliAd";
            this.txtYetkiliAd.Size = new System.Drawing.Size(100, 20);
            this.txtYetkiliAd.TabIndex = 6;
            // 
            // btnCevapGonder
            // 
            this.btnCevapGonder.Location = new System.Drawing.Point(155, 466);
            this.btnCevapGonder.Name = "btnCevapGonder";
            this.btnCevapGonder.Size = new System.Drawing.Size(182, 30);
            this.btnCevapGonder.TabIndex = 8;
            this.btnCevapGonder.Text = "Cevabı Gönder";
            this.btnCevapGonder.UseVisualStyleBackColor = true;
            this.btnCevapGonder.Click += new System.EventHandler(this.btnCevapGonder_Click);
            // 
            // lblSoruNo
            // 
            this.lblSoruNo.AutoSize = true;
            this.lblSoruNo.Location = new System.Drawing.Point(3, 25);
            this.lblSoruNo.Name = "lblSoruNo";
            this.lblSoruNo.Size = new System.Drawing.Size(62, 13);
            this.lblSoruNo.TabIndex = 9;
            this.lblSoruNo.Text = "Soru No\'su:";
            // 
            // lblSoruBaslik
            // 
            this.lblSoruBaslik.AutoSize = true;
            this.lblSoruBaslik.Location = new System.Drawing.Point(249, 25);
            this.lblSoruBaslik.Name = "lblSoruBaslik";
            this.lblSoruBaslik.Size = new System.Drawing.Size(65, 13);
            this.lblSoruBaslik.TabIndex = 10;
            this.lblSoruBaslik.Text = "Soru Başlığı:";
            // 
            // lblYetkiliKullaniciAdi
            // 
            this.lblYetkiliKullaniciAdi.AutoSize = true;
            this.lblYetkiliKullaniciAdi.Location = new System.Drawing.Point(104, 268);
            this.lblYetkiliKullaniciAdi.Name = "lblYetkiliKullaniciAdi";
            this.lblYetkiliKullaniciAdi.Size = new System.Drawing.Size(80, 13);
            this.lblYetkiliKullaniciAdi.TabIndex = 11;
            this.lblYetkiliKullaniciAdi.Text = "Kullanıcı Adınız:";
            // 
            // frmSoruGoruntule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(866, 508);
            this.Controls.Add(this.lblYetkiliKullaniciAdi);
            this.Controls.Add(this.lblSoruBaslik);
            this.Controls.Add(this.lblSoruNo);
            this.Controls.Add(this.btnCevapGonder);
            this.Controls.Add(this.txtYetkiliAd);
            this.Controls.Add(this.txtCevap);
            this.Controls.Add(this.txtSoru);
            this.Controls.Add(this.txtSorubasligi);
            this.Controls.Add(this.txtSoruNo);
            this.Controls.Add(this.btnSoruGoruntule);
            this.Controls.Add(this.dgvSorulistesi);
            this.Name = "frmSoruGoruntule";
            this.Text = "Soru Goruntule";
            ((System.ComponentModel.ISupportInitialize)(this.dgvSorulistesi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.onlineRandevuSistemiDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.soruCevapBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvSorulistesi;
        private OnlineRandevuSistemiDataSet2 onlineRandevuSistemiDataSet2;
        private System.Windows.Forms.BindingSource soruCevapBindingSource;
        private OnlineRandevuSistemiDataSet2TableAdapters.soruCevapTableAdapter soruCevapTableAdapter;
        private System.Windows.Forms.Button btnSoruGoruntule;
        private System.Windows.Forms.TextBox txtSoruNo;
        private System.Windows.Forms.TextBox txtSorubasligi;
        private System.Windows.Forms.TextBox txtSoru;
        private System.Windows.Forms.TextBox txtCevap;
        private System.Windows.Forms.TextBox txtYetkiliAd;
        private System.Windows.Forms.Button btnCevapGonder;
        private System.Windows.Forms.Label lblSoruNo;
        private System.Windows.Forms.Label lblSoruBaslik;
        private System.Windows.Forms.Label lblYetkiliKullaniciAdi;
    }
}