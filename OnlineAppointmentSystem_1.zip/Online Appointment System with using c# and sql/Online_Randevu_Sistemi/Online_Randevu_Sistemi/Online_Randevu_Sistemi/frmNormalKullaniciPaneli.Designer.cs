﻿
namespace Online_Randevu_Sistemi
{
    partial class frmNormalKullaniciPaneli
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.msNormalKullaniciPaneli = new System.Windows.Forms.MenuStrip();
            this.işyeriİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.işyeriAramaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.işyeriTürüAramaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.randevuİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.randevuAlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.diğerİşlemlerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yetkiliyeSoruSorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cevaplarıGörüntüleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.randevularımToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.msNormalKullaniciPaneli.SuspendLayout();
            this.SuspendLayout();
            // 
            // msNormalKullaniciPaneli
            // 
            this.msNormalKullaniciPaneli.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.msNormalKullaniciPaneli.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.işyeriİşlemleriToolStripMenuItem,
            this.randevuİşlemleriToolStripMenuItem,
            this.diğerİşlemlerToolStripMenuItem});
            this.msNormalKullaniciPaneli.Location = new System.Drawing.Point(0, 0);
            this.msNormalKullaniciPaneli.Name = "msNormalKullaniciPaneli";
            this.msNormalKullaniciPaneli.Padding = new System.Windows.Forms.Padding(4, 1, 0, 1);
            this.msNormalKullaniciPaneli.Size = new System.Drawing.Size(1062, 24);
            this.msNormalKullaniciPaneli.TabIndex = 0;
            this.msNormalKullaniciPaneli.Text = "menuStrip1";
            // 
            // işyeriİşlemleriToolStripMenuItem
            // 
            this.işyeriİşlemleriToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.işyeriAramaToolStripMenuItem,
            this.işyeriTürüAramaToolStripMenuItem});
            this.işyeriİşlemleriToolStripMenuItem.Name = "işyeriİşlemleriToolStripMenuItem";
            this.işyeriİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(93, 22);
            this.işyeriİşlemleriToolStripMenuItem.Text = "İşyeri İşlemleri";
            // 
            // işyeriAramaToolStripMenuItem
            // 
            this.işyeriAramaToolStripMenuItem.Name = "işyeriAramaToolStripMenuItem";
            this.işyeriAramaToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.işyeriAramaToolStripMenuItem.Text = "İşyeri Arama";
            this.işyeriAramaToolStripMenuItem.Click += new System.EventHandler(this.işyeriAramaToolStripMenuItem_Click_1);
            // 
            // işyeriTürüAramaToolStripMenuItem
            // 
            this.işyeriTürüAramaToolStripMenuItem.Name = "işyeriTürüAramaToolStripMenuItem";
            this.işyeriTürüAramaToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.işyeriTürüAramaToolStripMenuItem.Text = "İşyeri Türü Arama";
            this.işyeriTürüAramaToolStripMenuItem.Click += new System.EventHandler(this.işyeriTürüAramaToolStripMenuItem_Click);
            // 
            // randevuİşlemleriToolStripMenuItem
            // 
            this.randevuİşlemleriToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.randevuAlToolStripMenuItem,
            this.randevularımToolStripMenuItem});
            this.randevuİşlemleriToolStripMenuItem.Name = "randevuİşlemleriToolStripMenuItem";
            this.randevuİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.randevuİşlemleriToolStripMenuItem.Text = "Randevu İşlemleri ";
            // 
            // randevuAlToolStripMenuItem
            // 
            this.randevuAlToolStripMenuItem.Name = "randevuAlToolStripMenuItem";
            this.randevuAlToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.randevuAlToolStripMenuItem.Text = "Randevu Al ";
            this.randevuAlToolStripMenuItem.Click += new System.EventHandler(this.randevuAlToolStripMenuItem_Click);
            // 
            // diğerİşlemlerToolStripMenuItem
            // 
            this.diğerİşlemlerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yetkiliyeSoruSorToolStripMenuItem,
            this.cevaplarıGörüntüleToolStripMenuItem});
            this.diğerİşlemlerToolStripMenuItem.Name = "diğerİşlemlerToolStripMenuItem";
            this.diğerİşlemlerToolStripMenuItem.Size = new System.Drawing.Size(91, 22);
            this.diğerİşlemlerToolStripMenuItem.Text = "Diğer İşlemler";
            // 
            // yetkiliyeSoruSorToolStripMenuItem
            // 
            this.yetkiliyeSoruSorToolStripMenuItem.Name = "yetkiliyeSoruSorToolStripMenuItem";
            this.yetkiliyeSoruSorToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.yetkiliyeSoruSorToolStripMenuItem.Text = "İşyeri Yetkilisine Soru Sor";
            this.yetkiliyeSoruSorToolStripMenuItem.Click += new System.EventHandler(this.yetkiliyeSoruSorToolStripMenuItem_Click);
            // 
            // cevaplarıGörüntüleToolStripMenuItem
            // 
            this.cevaplarıGörüntüleToolStripMenuItem.Name = "cevaplarıGörüntüleToolStripMenuItem";
            this.cevaplarıGörüntüleToolStripMenuItem.Size = new System.Drawing.Size(203, 22);
            this.cevaplarıGörüntüleToolStripMenuItem.Text = "Cevapları Görüntüle";
            this.cevaplarıGörüntüleToolStripMenuItem.Click += new System.EventHandler(this.cevaplarıGörüntüleToolStripMenuItem_Click);
            // 
            // randevularımToolStripMenuItem
            // 
            this.randevularımToolStripMenuItem.Name = "randevularımToolStripMenuItem";
            this.randevularımToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.randevularımToolStripMenuItem.Text = "Randevularım";
            this.randevularımToolStripMenuItem.Click += new System.EventHandler(this.randevularımToolStripMenuItem_Click);
            // 
            // frmNormalKullaniciPaneli
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(1062, 646);
            this.Controls.Add(this.msNormalKullaniciPaneli);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.msNormalKullaniciPaneli;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmNormalKullaniciPaneli";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Normal Kullanici Paneli";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.msNormalKullaniciPaneli.ResumeLayout(false);
            this.msNormalKullaniciPaneli.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip msNormalKullaniciPaneli;
        private System.Windows.Forms.ToolStripMenuItem işyeriİşlemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem işyeriAramaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem işyeriTürüAramaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem randevuİşlemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem randevuAlToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem diğerİşlemlerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yetkiliyeSoruSorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cevaplarıGörüntüleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem randevularımToolStripMenuItem;
    }
}