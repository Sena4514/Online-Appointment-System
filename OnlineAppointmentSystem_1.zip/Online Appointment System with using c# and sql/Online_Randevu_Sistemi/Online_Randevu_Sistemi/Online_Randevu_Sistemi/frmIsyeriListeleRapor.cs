﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Online_Randevu_Sistemi
{
    public partial class frmIsyeriListeleRapor : Form
    {


        public frmIsyeriListeleRapor()
        {
            InitializeComponent();
        }
        IsyeriIslemleri Islemler = new IsyeriIslemleri();

        private void frmIsyeriListeleRapor_Load(object sender, EventArgs e)
        {
            Islemler.IsyerleriGoster(dgvMevcutIsyeriListeleRapor);
        }
    }
}
