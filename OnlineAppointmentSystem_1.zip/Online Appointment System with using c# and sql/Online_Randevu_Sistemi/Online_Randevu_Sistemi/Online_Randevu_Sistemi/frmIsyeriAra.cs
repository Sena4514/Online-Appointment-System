﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Randevu_Sistemi
{
    public partial class frmIsyeriAra : Form
    {
        public frmIsyeriAra()
        {
            InitializeComponent();
        }

        IsyeriIslemleri Islemler = new IsyeriIslemleri();
        IsyeriElemanları elemanlar = new IsyeriElemanları();

        private void btnIsyeriAra_Click(object sender, EventArgs e)
        {
            elemanlar.isyeri_adi = txtAranacakIsyeriAdi.Text;
            Islemler.IsyeriAra(dgvIsyeriAra, elemanlar);
        }

    }
}
