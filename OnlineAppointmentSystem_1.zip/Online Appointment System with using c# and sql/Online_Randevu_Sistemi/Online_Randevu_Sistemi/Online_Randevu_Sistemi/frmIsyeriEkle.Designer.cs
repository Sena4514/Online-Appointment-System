﻿
namespace Online_Randevu_Sistemi
{
    partial class frmIsyeriEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmIsyeriEkle));
            this.btnIsyeriEkle = new System.Windows.Forms.Button();
            this.ilIsyeriEkle = new System.Windows.Forms.ImageList(this.components);
            this.dgvIsyeriEkle = new System.Windows.Forms.DataGridView();
            this.txtIsyeriYetkiliIsmi = new System.Windows.Forms.TextBox();
            this.txtIsyeriYetkiliSoyismi = new System.Windows.Forms.TextBox();
            this.lblIsyeriYetkiliİsmi = new System.Windows.Forms.Label();
            this.lblIsyeriYetkiliSoyismi = new System.Windows.Forms.Label();
            this.txtIsyeriIsmi = new System.Windows.Forms.TextBox();
            this.lblIsyeriIsmi = new System.Windows.Forms.Label();
            this.txtIsyeriTuru = new System.Windows.Forms.TextBox();
            this.lblIsyeriTuru = new System.Windows.Forms.Label();
            this.mtbIsyeriTelNo = new System.Windows.Forms.MaskedTextBox();
            this.lblIsyeriAdres = new System.Windows.Forms.Label();
            this.lblIsyeriTelNo = new System.Windows.Forms.Label();
            this.txtIsyeriAdres = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvIsyeriEkle)).BeginInit();
            this.SuspendLayout();
            // 
            // btnIsyeriEkle
            // 
            this.btnIsyeriEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIsyeriEkle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnIsyeriEkle.ImageIndex = 0;
            this.btnIsyeriEkle.ImageList = this.ilIsyeriEkle;
            this.btnIsyeriEkle.Location = new System.Drawing.Point(261, 702);
            this.btnIsyeriEkle.Name = "btnIsyeriEkle";
            this.btnIsyeriEkle.Size = new System.Drawing.Size(223, 67);
            this.btnIsyeriEkle.TabIndex = 6;
            this.btnIsyeriEkle.Text = "İşyeri Ekle";
            this.btnIsyeriEkle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnIsyeriEkle.UseVisualStyleBackColor = true;
            this.btnIsyeriEkle.Click += new System.EventHandler(this.btnIsyeriEkle_Click);
            // 
            // ilIsyeriEkle
            // 
            this.ilIsyeriEkle.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ilIsyeriEkle.ImageStream")));
            this.ilIsyeriEkle.TransparentColor = System.Drawing.Color.Transparent;
            this.ilIsyeriEkle.Images.SetKeyName(0, "save11.jpg");
            // 
            // dgvIsyeriEkle
            // 
            this.dgvIsyeriEkle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvIsyeriEkle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvIsyeriEkle.Location = new System.Drawing.Point(503, 45);
            this.dgvIsyeriEkle.Name = "dgvIsyeriEkle";
            this.dgvIsyeriEkle.RowHeadersWidth = 62;
            this.dgvIsyeriEkle.RowTemplate.Height = 28;
            this.dgvIsyeriEkle.Size = new System.Drawing.Size(785, 724);
            this.dgvIsyeriEkle.TabIndex = 36;
            // 
            // txtIsyeriYetkiliIsmi
            // 
            this.txtIsyeriYetkiliIsmi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIsyeriYetkiliIsmi.Location = new System.Drawing.Point(287, 134);
            this.txtIsyeriYetkiliIsmi.Multiline = true;
            this.txtIsyeriYetkiliIsmi.Name = "txtIsyeriYetkiliIsmi";
            this.txtIsyeriYetkiliIsmi.Size = new System.Drawing.Size(197, 47);
            this.txtIsyeriYetkiliIsmi.TabIndex = 1;
            // 
            // txtIsyeriYetkiliSoyismi
            // 
            this.txtIsyeriYetkiliSoyismi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIsyeriYetkiliSoyismi.Location = new System.Drawing.Point(287, 224);
            this.txtIsyeriYetkiliSoyismi.Multiline = true;
            this.txtIsyeriYetkiliSoyismi.Name = "txtIsyeriYetkiliSoyismi";
            this.txtIsyeriYetkiliSoyismi.Size = new System.Drawing.Size(197, 47);
            this.txtIsyeriYetkiliSoyismi.TabIndex = 2;
            // 
            // lblIsyeriYetkiliİsmi
            // 
            this.lblIsyeriYetkiliİsmi.AutoSize = true;
            this.lblIsyeriYetkiliİsmi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIsyeriYetkiliİsmi.Location = new System.Drawing.Point(30, 139);
            this.lblIsyeriYetkiliİsmi.Name = "lblIsyeriYetkiliİsmi";
            this.lblIsyeriYetkiliİsmi.Size = new System.Drawing.Size(181, 22);
            this.lblIsyeriYetkiliİsmi.TabIndex = 24;
            this.lblIsyeriYetkiliİsmi.Text = "İşyeri Yetkilisi İsmi:";
            // 
            // lblIsyeriYetkiliSoyismi
            // 
            this.lblIsyeriYetkiliSoyismi.AutoSize = true;
            this.lblIsyeriYetkiliSoyismi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIsyeriYetkiliSoyismi.Location = new System.Drawing.Point(30, 229);
            this.lblIsyeriYetkiliSoyismi.Name = "lblIsyeriYetkiliSoyismi";
            this.lblIsyeriYetkiliSoyismi.Size = new System.Drawing.Size(215, 22);
            this.lblIsyeriYetkiliSoyismi.TabIndex = 25;
            this.lblIsyeriYetkiliSoyismi.Text = "İşyeri Yetkilisi Soyismi:";
            // 
            // txtIsyeriIsmi
            // 
            this.txtIsyeriIsmi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIsyeriIsmi.Location = new System.Drawing.Point(287, 45);
            this.txtIsyeriIsmi.Multiline = true;
            this.txtIsyeriIsmi.Name = "txtIsyeriIsmi";
            this.txtIsyeriIsmi.Size = new System.Drawing.Size(197, 47);
            this.txtIsyeriIsmi.TabIndex = 0;
            // 
            // lblIsyeriIsmi
            // 
            this.lblIsyeriIsmi.AutoSize = true;
            this.lblIsyeriIsmi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIsyeriIsmi.Location = new System.Drawing.Point(30, 50);
            this.lblIsyeriIsmi.Name = "lblIsyeriIsmi";
            this.lblIsyeriIsmi.Size = new System.Drawing.Size(105, 22);
            this.lblIsyeriIsmi.TabIndex = 28;
            this.lblIsyeriIsmi.Text = "İşyeri İsmi:";
            // 
            // txtIsyeriTuru
            // 
            this.txtIsyeriTuru.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIsyeriTuru.Location = new System.Drawing.Point(287, 311);
            this.txtIsyeriTuru.Multiline = true;
            this.txtIsyeriTuru.Name = "txtIsyeriTuru";
            this.txtIsyeriTuru.Size = new System.Drawing.Size(197, 47);
            this.txtIsyeriTuru.TabIndex = 3;
            // 
            // lblIsyeriTuru
            // 
            this.lblIsyeriTuru.AutoSize = true;
            this.lblIsyeriTuru.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIsyeriTuru.Location = new System.Drawing.Point(30, 316);
            this.lblIsyeriTuru.Name = "lblIsyeriTuru";
            this.lblIsyeriTuru.Size = new System.Drawing.Size(112, 22);
            this.lblIsyeriTuru.TabIndex = 30;
            this.lblIsyeriTuru.Text = "İşyeri Türü:";
            // 
            // mtbIsyeriTelNo
            // 
            this.mtbIsyeriTelNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtbIsyeriTelNo.Location = new System.Drawing.Point(287, 611);
            this.mtbIsyeriTelNo.Mask = "(999) 000-0000";
            this.mtbIsyeriTelNo.Name = "mtbIsyeriTelNo";
            this.mtbIsyeriTelNo.Size = new System.Drawing.Size(197, 30);
            this.mtbIsyeriTelNo.TabIndex = 5;
            // 
            // lblIsyeriAdres
            // 
            this.lblIsyeriAdres.AutoSize = true;
            this.lblIsyeriAdres.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIsyeriAdres.Location = new System.Drawing.Point(30, 409);
            this.lblIsyeriAdres.Name = "lblIsyeriAdres";
            this.lblIsyeriAdres.Size = new System.Drawing.Size(122, 22);
            this.lblIsyeriAdres.TabIndex = 32;
            this.lblIsyeriAdres.Text = "İşyeri Adres:";
            // 
            // lblIsyeriTelNo
            // 
            this.lblIsyeriTelNo.AutoSize = true;
            this.lblIsyeriTelNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIsyeriTelNo.Location = new System.Drawing.Point(30, 611);
            this.lblIsyeriTelNo.Name = "lblIsyeriTelNo";
            this.lblIsyeriTelNo.Size = new System.Drawing.Size(130, 22);
            this.lblIsyeriTelNo.TabIndex = 34;
            this.lblIsyeriTelNo.Text = "İşyeri Tel.No:";
            // 
            // txtIsyeriAdres
            // 
            this.txtIsyeriAdres.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIsyeriAdres.Location = new System.Drawing.Point(287, 404);
            this.txtIsyeriAdres.Multiline = true;
            this.txtIsyeriAdres.Name = "txtIsyeriAdres";
            this.txtIsyeriAdres.Size = new System.Drawing.Size(197, 155);
            this.txtIsyeriAdres.TabIndex = 4;
            // 
            // frmIsyeriEkle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1300, 822);
            this.Controls.Add(this.dgvIsyeriEkle);
            this.Controls.Add(this.mtbIsyeriTelNo);
            this.Controls.Add(this.lblIsyeriTelNo);
            this.Controls.Add(this.lblIsyeriAdres);
            this.Controls.Add(this.txtIsyeriAdres);
            this.Controls.Add(this.lblIsyeriTuru);
            this.Controls.Add(this.txtIsyeriTuru);
            this.Controls.Add(this.lblIsyeriIsmi);
            this.Controls.Add(this.txtIsyeriIsmi);
            this.Controls.Add(this.btnIsyeriEkle);
            this.Controls.Add(this.lblIsyeriYetkiliSoyismi);
            this.Controls.Add(this.lblIsyeriYetkiliİsmi);
            this.Controls.Add(this.txtIsyeriYetkiliSoyismi);
            this.Controls.Add(this.txtIsyeriYetkiliIsmi);
            this.Name = "frmIsyeriEkle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "İşyeri Ekleme Formu";
            ((System.ComponentModel.ISupportInitialize)(this.dgvIsyeriEkle)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnIsyeriEkle;
        private System.Windows.Forms.ImageList ilIsyeriEkle;
        private System.Windows.Forms.DataGridView dgvIsyeriEkle;
        private System.Windows.Forms.TextBox txtIsyeriYetkiliIsmi;
        private System.Windows.Forms.TextBox txtIsyeriYetkiliSoyismi;
        private System.Windows.Forms.Label lblIsyeriYetkiliİsmi;
        private System.Windows.Forms.Label lblIsyeriYetkiliSoyismi;
        private System.Windows.Forms.TextBox txtIsyeriIsmi;
        private System.Windows.Forms.Label lblIsyeriIsmi;
        private System.Windows.Forms.TextBox txtIsyeriTuru;
        private System.Windows.Forms.Label lblIsyeriTuru;
        private System.Windows.Forms.MaskedTextBox mtbIsyeriTelNo;
        private System.Windows.Forms.Label lblIsyeriAdres;
        private System.Windows.Forms.Label lblIsyeriTelNo;
        private System.Windows.Forms.TextBox txtIsyeriAdres;
    }
}