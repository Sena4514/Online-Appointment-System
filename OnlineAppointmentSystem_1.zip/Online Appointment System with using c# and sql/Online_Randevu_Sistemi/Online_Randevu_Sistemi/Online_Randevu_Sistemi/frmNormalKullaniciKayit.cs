﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Randevu_Sistemi
{
    public partial class frmNormalKullaniciKayit : Form
    {
        public frmNormalKullaniciKayit()
        {
            InitializeComponent();
        }

        KayitIslemleri Islemler = new KayitIslemleri();
        private void normalkullanicikayit(string normalkullaniciadi, string normalkullanicisifre, string normalkullaniciisim, string normalkullanicisoyisim, string normalkullaniciadres, string normalkullaniciemail, string normalkullanicitelno)
        {
            NormalKullaniciElemanlari elemanlar = new NormalKullaniciElemanlari()
            {
                nkullanici_kullanici_adi = normalkullaniciadi,
                nkullanici_sifre = normalkullanicisifre,
                nkullanici_isim = normalkullaniciisim,
                nkullanici_soyisim = normalkullanicisoyisim,
                nkullanici_adres = normalkullaniciadres,
                nkullanici_email = normalkullaniciemail,
                nkullanici_telNo = normalkullanicitelno
            };
            Islemler.NormalKullaniciKayit(elemanlar);
        }

        private void btnKullaniciKaydet_Click(object sender, EventArgs e)
        {
            try
            {
                normalkullanicikayit(txtKullaniciAdi.Text, txtSifre.Text, txtIsim.Text, txtSoyisim.Text, txtAdres.Text, txtEmail.Text, mtbTelNo.Text);
                MessageBox.Show("Onay ekranına yönlendiriliyorsunuz !!!");
                txtKullaniciAdi.Clear();
                txtSifre.Clear();
                txtIsim.Clear();
                txtSoyisim.Clear();
                txtAdres.Clear();
                txtEmail.Clear();
                mtbTelNo.Clear();

                frmOnayKodu frmonaykodu = new frmOnayKodu();
                this.Hide();
                frmonaykodu.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Islem Basarisiz!\nHata:" + ex.Message);
            }

        }
    }
}
