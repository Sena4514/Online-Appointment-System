﻿
namespace Online_Randevu_Sistemi
{
    partial class frmOnayKodu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbOnayKodu = new System.Windows.Forms.GroupBox();
            this.txtKodDogrulama = new System.Windows.Forms.TextBox();
            this.btnDogrula = new System.Windows.Forms.Button();
            this.lblKodDogrulama = new System.Windows.Forms.Label();
            this.lblKodUyariMetni = new System.Windows.Forms.Label();
            this.grbEmailTekrar = new System.Windows.Forms.GroupBox();
            this.txtEmailTekrar = new System.Windows.Forms.TextBox();
            this.btnGonder = new System.Windows.Forms.Button();
            this.lblEmailTekrar = new System.Windows.Forms.Label();
            this.lblEmailUyariMetni = new System.Windows.Forms.Label();
            this.grbOnayKodu.SuspendLayout();
            this.grbEmailTekrar.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbOnayKodu
            // 
            this.grbOnayKodu.Controls.Add(this.txtKodDogrulama);
            this.grbOnayKodu.Controls.Add(this.btnDogrula);
            this.grbOnayKodu.Controls.Add(this.lblKodDogrulama);
            this.grbOnayKodu.Location = new System.Drawing.Point(413, 50);
            this.grbOnayKodu.Name = "grbOnayKodu";
            this.grbOnayKodu.Size = new System.Drawing.Size(378, 186);
            this.grbOnayKodu.TabIndex = 16;
            this.grbOnayKodu.TabStop = false;
            this.grbOnayKodu.Text = "Onay Kodu";
            // 
            // txtKodDogrulama
            // 
            this.txtKodDogrulama.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKodDogrulama.Location = new System.Drawing.Point(63, 38);
            this.txtKodDogrulama.Multiline = true;
            this.txtKodDogrulama.Name = "txtKodDogrulama";
            this.txtKodDogrulama.Size = new System.Drawing.Size(263, 32);
            this.txtKodDogrulama.TabIndex = 9;
            // 
            // btnDogrula
            // 
            this.btnDogrula.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDogrula.Location = new System.Drawing.Point(63, 106);
            this.btnDogrula.Name = "btnDogrula";
            this.btnDogrula.Size = new System.Drawing.Size(169, 55);
            this.btnDogrula.TabIndex = 8;
            this.btnDogrula.Text = "Doğrula";
            this.btnDogrula.UseVisualStyleBackColor = true;
            this.btnDogrula.Click += new System.EventHandler(this.btnDogrula_Click);
            // 
            // lblKodDogrulama
            // 
            this.lblKodDogrulama.AutoSize = true;
            this.lblKodDogrulama.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKodDogrulama.Location = new System.Drawing.Point(6, 43);
            this.lblKodDogrulama.Name = "lblKodDogrulama";
            this.lblKodDogrulama.Size = new System.Drawing.Size(51, 22);
            this.lblKodDogrulama.TabIndex = 7;
            this.lblKodDogrulama.Text = "Kod:";
            // 
            // lblKodUyariMetni
            // 
            this.lblKodUyariMetni.AutoSize = true;
            this.lblKodUyariMetni.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKodUyariMetni.ForeColor = System.Drawing.Color.Red;
            this.lblKodUyariMetni.Location = new System.Drawing.Point(409, 25);
            this.lblKodUyariMetni.Name = "lblKodUyariMetni";
            this.lblKodUyariMetni.Size = new System.Drawing.Size(382, 20);
            this.lblKodUyariMetni.TabIndex = 17;
            this.lblKodUyariMetni.Text = "LÜTFEN E-MAİLİNİZE GELEN KODU GİRİNİZ";
            // 
            // grbEmailTekrar
            // 
            this.grbEmailTekrar.Controls.Add(this.txtEmailTekrar);
            this.grbEmailTekrar.Controls.Add(this.btnGonder);
            this.grbEmailTekrar.Controls.Add(this.lblEmailTekrar);
            this.grbEmailTekrar.Location = new System.Drawing.Point(12, 50);
            this.grbEmailTekrar.Name = "grbEmailTekrar";
            this.grbEmailTekrar.Size = new System.Drawing.Size(395, 186);
            this.grbEmailTekrar.TabIndex = 17;
            this.grbEmailTekrar.TabStop = false;
            this.grbEmailTekrar.Text = "Email Tekrar";
            // 
            // txtEmailTekrar
            // 
            this.txtEmailTekrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailTekrar.Location = new System.Drawing.Point(144, 38);
            this.txtEmailTekrar.Multiline = true;
            this.txtEmailTekrar.Name = "txtEmailTekrar";
            this.txtEmailTekrar.Size = new System.Drawing.Size(245, 32);
            this.txtEmailTekrar.TabIndex = 9;
            // 
            // btnGonder
            // 
            this.btnGonder.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGonder.Location = new System.Drawing.Point(150, 106);
            this.btnGonder.Name = "btnGonder";
            this.btnGonder.Size = new System.Drawing.Size(169, 55);
            this.btnGonder.TabIndex = 8;
            this.btnGonder.Text = "Gönder";
            this.btnGonder.UseVisualStyleBackColor = true;
            this.btnGonder.Click += new System.EventHandler(this.btnGonder_Click);
            // 
            // lblEmailTekrar
            // 
            this.lblEmailTekrar.AutoSize = true;
            this.lblEmailTekrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailTekrar.Location = new System.Drawing.Point(6, 43);
            this.lblEmailTekrar.Name = "lblEmailTekrar";
            this.lblEmailTekrar.Size = new System.Drawing.Size(138, 22);
            this.lblEmailTekrar.TabIndex = 7;
            this.lblEmailTekrar.Text = "Email(Tekrar):";
            // 
            // lblEmailUyariMetni
            // 
            this.lblEmailUyariMetni.AutoSize = true;
            this.lblEmailUyariMetni.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailUyariMetni.ForeColor = System.Drawing.Color.Red;
            this.lblEmailUyariMetni.Location = new System.Drawing.Point(8, 25);
            this.lblEmailUyariMetni.Name = "lblEmailUyariMetni";
            this.lblEmailUyariMetni.Size = new System.Drawing.Size(332, 20);
            this.lblEmailUyariMetni.TabIndex = 18;
            this.lblEmailUyariMetni.Text = "LÜTFEN E-MAİLİNİZİ TEKRAR GİRİNİZ";
            // 
            // frmOnayKodu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(803, 293);
            this.Controls.Add(this.lblEmailUyariMetni);
            this.Controls.Add(this.grbEmailTekrar);
            this.Controls.Add(this.lblKodUyariMetni);
            this.Controls.Add(this.grbOnayKodu);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmOnayKodu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Onay Kodu Formu";
            this.grbOnayKodu.ResumeLayout(false);
            this.grbOnayKodu.PerformLayout();
            this.grbEmailTekrar.ResumeLayout(false);
            this.grbEmailTekrar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grbOnayKodu;
        private System.Windows.Forms.TextBox txtKodDogrulama;
        private System.Windows.Forms.Button btnDogrula;
        private System.Windows.Forms.Label lblKodDogrulama;
        private System.Windows.Forms.Label lblKodUyariMetni;
        private System.Windows.Forms.GroupBox grbEmailTekrar;
        private System.Windows.Forms.TextBox txtEmailTekrar;
        private System.Windows.Forms.Button btnGonder;
        private System.Windows.Forms.Label lblEmailTekrar;
        private System.Windows.Forms.Label lblEmailUyariMetni;
    }
}