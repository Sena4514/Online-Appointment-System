﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;

namespace Online_Randevu_Sistemi
{
    class KayitIslemleri:sqlIslemleri
    {
        public void YetkiliKayit(YetkiliElemanlar elemanlar)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Insert Into yetkili(yetkili_kullanici_adi,yetkili_sifre,yetkili_isim,yetkili_soyisim,yetkili_adres,yetkili_email,yetkili_telNo,yetkili_dogumTarihi,yetkili_TcNo,yetkili_isyeri_adi) values ('" + (elemanlar.yetkili_kullanici_adi) + "','" + (elemanlar.yetkili_sifre) + "','" + (elemanlar.yetkili_isim) + "','" + (elemanlar.yetkili_soyisim) + "','" + (elemanlar.yetkili_adres) + "','" + (elemanlar.yetkili_email) + "','" + (elemanlar.yetkili_telNo) + "','" + (elemanlar.yetkili_dogumTarihi) + "','" + (elemanlar.yetkili_TcNo) + "','" + (elemanlar.yetkili_isyeri_adi) + "')", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void NormalKullaniciKayit(NormalKullaniciElemanlari elemanlar)
        {
            try
            {
                SqlConnection con = new SqlConnection(connStr);
                SqlCommand cmd = new SqlCommand("Insert Into normalkullanici(nkullanici_kullanici_adi,nkullanici_sifre,nkullanici_isim,nkullanici_soyisim,nkullanici_adres,nkullanici_email,nkullanici_telNo) values (@nkullanici_kullanici_adi,@nkullanici_sifre,@nkullanici_isim,@nkullanici_soyisim,@nkullanici_adres,@nkullanici_email,@nkullanici_telNo)", con);
                cmd.Parameters.AddWithValue("nkullanici_kullanici_adi", elemanlar.nkullanici_kullanici_adi);
                cmd.Parameters.AddWithValue("nkullanici_sifre", elemanlar.nkullanici_sifre);
                cmd.Parameters.AddWithValue("nkullanici_isim", elemanlar.nkullanici_isim);
                cmd.Parameters.AddWithValue("nkullanici_soyisim", elemanlar.nkullanici_soyisim);
                cmd.Parameters.AddWithValue("nkullanici_adres", elemanlar.nkullanici_adres);
                cmd.Parameters.AddWithValue("nkullanici_email", elemanlar.nkullanici_email);
                cmd.Parameters.AddWithValue("nkullanici_telNo", elemanlar.nkullanici_telNo);
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void EmailGonder(NormalKullaniciElemanlari elemanlar)
        {
            Random rnd = new Random();
            elemanlar.Onay_Kodu= rnd.Next(10000, 90000);

            MailMessage msj = new MailMessage();
            SmtpClient client = new SmtpClient();
            client.Credentials = new System.Net.NetworkCredential("senakocak4514@gmail.com", "aylasena");
            client.Port = 587;
            client.Host = "smtp.gmail.com";
            client.EnableSsl = true;
            msj.To.Add(elemanlar.nkullanici_email);
            msj.From = new MailAddress("senakocak4514@gmail.com", "aylasena");
            msj.Subject = "Guvenlik Kodu";
            msj.Body = elemanlar.Onay_Kodu.ToString();

            client.Send(msj);
        }
    }
}
