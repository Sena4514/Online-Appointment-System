﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace Online_Randevu_Sistemi
{
    class IsyeriIslemleri:sqlIslemleri
    {
        public void IsyerleriGoster(DataGridView dgvIsyerleri)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("Select isyeri_adi,isyeri_yetkili_isim,isyeri_yetkili_soyisim,isyeri_turu,isyeri_adres,isyeri_telNo From isyeri", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgvIsyerleri.DataSource = ds.Tables[0];
            con.Close();
        }
        public void IsyeriSil(IsyeriElemanları elemanlar)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Delete From isyeri Where isyeri_adi=@isyeri_adi", con);
            cmd.Parameters.AddWithValue("@isyeri_adi", elemanlar.isyeri_adi);
            cmd.ExecuteNonQuery(); 
            con.Close(); 
        }
        public void IsyeriEkleme(IsyeriElemanları isyeri)
        {
            try
            {
                SqlConnection con = new SqlConnection(connStr);
                SqlCommand cmd = new SqlCommand("Insert Into isyeri(isyeri_adi,isyeri_yetkili_isim,isyeri_yetkili_soyisim,isyeri_turu,isyeri_adres,isyeri_telNo) values (@isyeri_adi,@isyeri_yetkili_isim,@isyeri_yetkili_soyisim,@isyeri_turu,@isyeri_adres,@isyeri_telNo)", con);
                cmd.Parameters.AddWithValue("isyeri_adi", isyeri.isyeri_adi);
                cmd.Parameters.AddWithValue("isyeri_yetkili_isim", isyeri.isyeri_yetkili_isim);
                cmd.Parameters.AddWithValue("isyeri_yetkili_soyisim", isyeri.isyeri_yetkili_soyisim);
                cmd.Parameters.AddWithValue("isyeri_turu", isyeri.isyeri_turu);
                cmd.Parameters.AddWithValue("isyeri_adres", isyeri.isyeri_adres);
                cmd.Parameters.AddWithValue("isyeri_telNo", isyeri.isyeri_telNo);
                con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<IsyeriElemanları> Listele()
        {
            List<IsyeriElemanları> isyerleri = new List<IsyeriElemanları>();
            try
            {
                SqlConnection con = new SqlConnection(connStr);
                SqlCommand cmd = new SqlCommand("Select * From isyeri", con);
                con.Open();

                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            var isyeri = new IsyeriElemanları
                            {
                                isyeri_adi = reader.GetString(0),
                                isyeri_yetkili_isim = reader.GetString(1),
                                isyeri_yetkili_soyisim = reader.GetString(2),
                                isyeri_turu = reader.GetString(3),
                                isyeri_adres = reader.GetString(4),
                                isyeri_telNo = reader.GetString(5)
                            };
                            isyerleri.Add(isyeri);
                        }
                    }
                }
                return isyerleri;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void IsyeriGuncelle(IsyeriElemanları elemanlar,string GuncellenecekIsyeriIsmi)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand(" Update isyeri Set isyeri_yetkili_isim='" + elemanlar.isyeri_yetkili_isim + "',isyeri_yetkili_soyisim='" + elemanlar.isyeri_yetkili_soyisim + "',isyeri_turu='" + elemanlar.isyeri_turu + "',isyeri_adres='" + elemanlar.isyeri_adres + "',isyeri_telNo='" + elemanlar.isyeri_telNo + "' Where isyeri_adi='" + GuncellenecekIsyeriIsmi + "'", con);
            SqlCommand cmd2 = new SqlCommand(" Update yetkili Set yetkili_isim='" + elemanlar.isyeri_yetkili_isim + "', yetkili_soyisim='" + elemanlar.isyeri_yetkili_soyisim + "'", con);
            cmd.ExecuteNonQuery();
            cmd2.ExecuteNonQuery();
            con.Close();
        }
        public void IsyeriAra(DataGridView dgvIsyeri,IsyeriElemanları elemanlar)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select isyeri_adi,isyeri_yetkili_isim,isyeri_yetkili_soyisim,isyeri_turu,isyeri_adres,isyeri_telNo From isyeri Where isyeri_adi Like '%" + elemanlar.isyeri_adi + "%'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgvIsyeri.DataSource = ds.Tables[0];
            con.Close();
        }
        public void IsyeriTuruAra(DataGridView dgvIsyeri,IsyeriElemanları elemanlar)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select isyeri_adi,isyeri_yetkili_isim,isyeri_yetkili_soyisim,isyeri_turu,isyeri_adres,isyeri_telNo From isyeri Where isyeri_turu Like '%" + elemanlar.isyeri_turu + "%'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgvIsyeri.DataSource = ds.Tables[0];
        }
    }
}
