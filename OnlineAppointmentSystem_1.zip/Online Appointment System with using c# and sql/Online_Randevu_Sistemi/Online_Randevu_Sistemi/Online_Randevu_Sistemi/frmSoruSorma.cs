﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Randevu_Sistemi
{
    public partial class frmSoruSorma : Form
    {
        public frmSoruSorma()
        {
            InitializeComponent();
        }

        SoruCevap SoruCevap = new SoruCevap();
        private void frmSoruSorma_Shown(object sender, EventArgs e)
        {            
            txtSoruNo.Text = SoruCevap.SoruNoAtama().ToString();
        }

        private void btnSoruGonder_Click(object sender, EventArgs e)
        {
            try
            {
                SoruCevapElemanlar elemanlar = new SoruCevapElemanlar()
                {
                    Soru = txtSoru.Text,
                    Kullanici_isim = txtAd.Text,
                    Kullanici_Soyisim = txtSoyad.Text,
                    Soru_Baslik = txtSoruBaslik.Text,
                    Soru_No = Convert.ToInt32(txtSoruNo.Text)
                };

                SoruCevap.SoruKaydet(elemanlar);
                MessageBox.Show("Sorunuz Gönderilmiştir, Lütfen Soru numaranızı unutmayınız!!");
                txtSoru.Text = txtSoruBaslik.Text = txtAd.Text = txtSoruBaslik.Text = txtSoyad.Text = "";
            }
            catch(Exception ex)
            {
                MessageBox.Show("Hatalı giriş yaptınız!!!");
                throw ex;
            }
        }
    }
}
