﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Randevu_Sistemi
{
    public partial class frmRandevularım : Form
    {
        public frmRandevularım()
        {
            InitializeComponent();
        }

        RandevuIslemleri Islemler = new RandevuIslemleri();
        RandevuElemanlar elemanlar = new RandevuElemanlar();

        private void btnRandevuAra_Click(object sender, EventArgs e)
        {
            if(txtKullaniciAdi.Text=="")
            {
                elemanlar.Randevu_No = txtRandevuNo.Text;
                Islemler.NoRandevuAra(dgvRandevuGoruntule, elemanlar);
                txtRandevuNo.Clear();
            }
            if (txtRandevuNo.Text == "")
            {
                elemanlar.Kullanici_Adi = txtKullaniciAdi.Text;
                Islemler.AdRandevuAra(dgvRandevuGoruntule, elemanlar);
                txtKullaniciAdi.Clear();
            }
        }
    }
}
