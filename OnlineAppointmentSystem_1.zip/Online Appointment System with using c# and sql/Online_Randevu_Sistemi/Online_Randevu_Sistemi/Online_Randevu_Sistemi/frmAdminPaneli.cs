﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Randevu_Sistemi
{
    public partial class frmAdminPaneli : Form
    {
        public frmAdminPaneli()
        {
            InitializeComponent();
        }

        private void işyeriEkleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmIsyeriEkle frmisyeriekle = new frmIsyeriEkle();
            frmisyeriekle.MdiParent = this;
            frmisyeriekle.Show();
        }

        private void işyeriSilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmIsyeriSil frmisyerisil = new frmIsyeriSil();
            frmisyerisil.MdiParent = this;
            frmisyerisil.Show();
        }

        private void işyeriAraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmIsyeriAra frmisyeriara = new frmIsyeriAra();
            frmisyeriara.MdiParent = this;
            frmisyeriara.Show();
        }

        private void işyeriGüncelleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmIsyeriGuncelle frmisyeriguncelle = new frmIsyeriGuncelle();
            frmisyeriguncelle.MdiParent = this;
            frmisyeriguncelle.Show();
        }

        private void işyeriListelemeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmIsyeriListeleRapor frmisyerilistelerapor = new frmIsyeriListeleRapor();
            frmisyerilistelerapor.MdiParent = this;
            frmisyerilistelerapor.Show();
        }

        private void normalkullanıcıListelemeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmNormalKullaniciListelemeRapor frmnormalkullanicilistelemerapor = new frmNormalKullaniciListelemeRapor();
            frmnormalkullanicilistelemerapor.MdiParent = this;
            frmnormalkullanicilistelemerapor.Show();
        }
    }
}
