﻿
namespace Online_Randevu_Sistemi
{
    partial class frmNormalKullaniciIsyeriTuruArama
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAranacakIsyeriTuru = new System.Windows.Forms.Label();
            this.txtAranacakIsyeriTuru = new System.Windows.Forms.TextBox();
            this.btnIsyeriTuruAra = new System.Windows.Forms.Button();
            this.dgvIsyeriTuruAra = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvIsyeriTuruAra)).BeginInit();
            this.SuspendLayout();
            // 
            // lblAranacakIsyeriTuru
            // 
            this.lblAranacakIsyeriTuru.AutoSize = true;
            this.lblAranacakIsyeriTuru.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAranacakIsyeriTuru.Location = new System.Drawing.Point(19, 318);
            this.lblAranacakIsyeriTuru.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAranacakIsyeriTuru.Name = "lblAranacakIsyeriTuru";
            this.lblAranacakIsyeriTuru.Size = new System.Drawing.Size(164, 17);
            this.lblAranacakIsyeriTuru.TabIndex = 6;
            this.lblAranacakIsyeriTuru.Text = "Aranacak İşyeri Türü:";
            // 
            // txtAranacakIsyeriTuru
            // 
            this.txtAranacakIsyeriTuru.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAranacakIsyeriTuru.Location = new System.Drawing.Point(200, 312);
            this.txtAranacakIsyeriTuru.Margin = new System.Windows.Forms.Padding(2);
            this.txtAranacakIsyeriTuru.Multiline = true;
            this.txtAranacakIsyeriTuru.Name = "txtAranacakIsyeriTuru";
            this.txtAranacakIsyeriTuru.Size = new System.Drawing.Size(181, 32);
            this.txtAranacakIsyeriTuru.TabIndex = 4;
            // 
            // btnIsyeriTuruAra
            // 
            this.btnIsyeriTuruAra.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIsyeriTuruAra.Location = new System.Drawing.Point(593, 308);
            this.btnIsyeriTuruAra.Margin = new System.Windows.Forms.Padding(2);
            this.btnIsyeriTuruAra.Name = "btnIsyeriTuruAra";
            this.btnIsyeriTuruAra.Size = new System.Drawing.Size(157, 36);
            this.btnIsyeriTuruAra.TabIndex = 5;
            this.btnIsyeriTuruAra.Text = "Girilen İşyeri Türü Ara";
            this.btnIsyeriTuruAra.UseVisualStyleBackColor = true;
            this.btnIsyeriTuruAra.Click += new System.EventHandler(this.btnIsyeriTuruAra_Click);
            // 
            // dgvIsyeriTuruAra
            // 
            this.dgvIsyeriTuruAra.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvIsyeriTuruAra.Location = new System.Drawing.Point(2, 1);
            this.dgvIsyeriTuruAra.Margin = new System.Windows.Forms.Padding(2);
            this.dgvIsyeriTuruAra.Name = "dgvIsyeriTuruAra";
            this.dgvIsyeriTuruAra.RowHeadersWidth = 62;
            this.dgvIsyeriTuruAra.RowTemplate.Height = 28;
            this.dgvIsyeriTuruAra.Size = new System.Drawing.Size(760, 285);
            this.dgvIsyeriTuruAra.TabIndex = 7;
            // 
            // frmNormalKullaniciIsyeriTuruArama
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(764, 373);
            this.Controls.Add(this.dgvIsyeriTuruAra);
            this.Controls.Add(this.lblAranacakIsyeriTuru);
            this.Controls.Add(this.txtAranacakIsyeriTuru);
            this.Controls.Add(this.btnIsyeriTuruAra);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmNormalKullaniciIsyeriTuruArama";
            this.Text = "Normal Kullanıcı İşyeri Türü Arama";
            ((System.ComponentModel.ISupportInitialize)(this.dgvIsyeriTuruAra)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAranacakIsyeriTuru;
        private System.Windows.Forms.TextBox txtAranacakIsyeriTuru;
        private System.Windows.Forms.Button btnIsyeriTuruAra;
        private System.Windows.Forms.DataGridView dgvIsyeriTuruAra;
    }
}