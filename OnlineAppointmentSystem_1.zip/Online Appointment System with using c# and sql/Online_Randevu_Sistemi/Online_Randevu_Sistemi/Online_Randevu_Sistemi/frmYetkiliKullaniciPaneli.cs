﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Randevu_Sistemi
{
    public partial class frmYetkiliKullaniciPaneli : Form
    {
        public frmYetkiliKullaniciPaneli()
        {
            InitializeComponent();
        }

        private void soruCevapİşlemleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSoruGoruntule frmSorugoruntule = new frmSoruGoruntule();
            frmSorugoruntule.MdiParent = this;
            frmSorugoruntule.Show();
        }

        private void işyeriEkleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmIsyeriEkle frmIsyeriEkle = new frmIsyeriEkle();
            frmIsyeriEkle.MdiParent = this;
            frmIsyeriEkle.Show();
        }

        private void randevuGünleriAyarlaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmRandevuZamanAyarla frmrandevuZamanAyarla = new frmRandevuZamanAyarla();
            frmrandevuZamanAyarla.MdiParent = this;
            frmrandevuZamanAyarla.Show();
        }

        private void randevuOnaylamaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmRandevuOnaylama frmrandevuOnaylama = new frmRandevuOnaylama();
            frmrandevuOnaylama.MdiParent = this;
            frmrandevuOnaylama.Show();
        }
    }
}
