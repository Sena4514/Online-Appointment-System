﻿
namespace Online_Randevu_Sistemi
{
    partial class frmRandevuOnaylama
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblIsyeriAdi = new System.Windows.Forms.Label();
            this.txtIsyeriAdi = new System.Windows.Forms.TextBox();
            this.btnTakvimGoster = new System.Windows.Forms.Button();
            this.lblKullaniciAdi = new System.Windows.Forms.Label();
            this.txtKullaniciAdi = new System.Windows.Forms.TextBox();
            this.btnRandevuOnayla = new System.Windows.Forms.Button();
            this.dgvGunlerListesi = new System.Windows.Forms.DataGridView();
            this.comboOnay = new System.Windows.Forms.ComboBox();
            this.txtNkullaniciAdi = new System.Windows.Forms.TextBox();
            this.txtSectigiGun = new System.Windows.Forms.TextBox();
            this.txtSectigiSaat = new System.Windows.Forms.TextBox();
            this.txtRandevuNo = new System.Windows.Forms.TextBox();
            this.lblNkullaniciAdi = new System.Windows.Forms.Label();
            this.lblRandevuNo = new System.Windows.Forms.Label();
            this.lblSectigiGun = new System.Windows.Forms.Label();
            this.lblSectigiSaat = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGunlerListesi)).BeginInit();
            this.SuspendLayout();
            // 
            // lblIsyeriAdi
            // 
            this.lblIsyeriAdi.AutoSize = true;
            this.lblIsyeriAdi.Location = new System.Drawing.Point(439, 40);
            this.lblIsyeriAdi.Name = "lblIsyeriAdi";
            this.lblIsyeriAdi.Size = new System.Drawing.Size(91, 13);
            this.lblIsyeriAdi.TabIndex = 58;
            this.lblIsyeriAdi.Text = "İşyeri Adını Giriniz:";
            // 
            // txtIsyeriAdi
            // 
            this.txtIsyeriAdi.Location = new System.Drawing.Point(536, 37);
            this.txtIsyeriAdi.Name = "txtIsyeriAdi";
            this.txtIsyeriAdi.Size = new System.Drawing.Size(104, 20);
            this.txtIsyeriAdi.TabIndex = 56;
            // 
            // btnTakvimGoster
            // 
            this.btnTakvimGoster.Location = new System.Drawing.Point(536, 63);
            this.btnTakvimGoster.Name = "btnTakvimGoster";
            this.btnTakvimGoster.Size = new System.Drawing.Size(104, 42);
            this.btnTakvimGoster.TabIndex = 55;
            this.btnTakvimGoster.Text = "İşyeri Takvimini Göster";
            this.btnTakvimGoster.UseVisualStyleBackColor = true;
            this.btnTakvimGoster.Click += new System.EventHandler(this.btnTakvimGoster_Click);
            // 
            // lblKullaniciAdi
            // 
            this.lblKullaniciAdi.AutoSize = true;
            this.lblKullaniciAdi.Location = new System.Drawing.Point(417, 324);
            this.lblKullaniciAdi.Name = "lblKullaniciAdi";
            this.lblKullaniciAdi.Size = new System.Drawing.Size(113, 13);
            this.lblKullaniciAdi.TabIndex = 53;
            this.lblKullaniciAdi.Text = "Kullanıcı Adınızı Giriniz:";
            // 
            // txtKullaniciAdi
            // 
            this.txtKullaniciAdi.Location = new System.Drawing.Point(536, 321);
            this.txtKullaniciAdi.Name = "txtKullaniciAdi";
            this.txtKullaniciAdi.Size = new System.Drawing.Size(104, 20);
            this.txtKullaniciAdi.TabIndex = 52;
            // 
            // btnRandevuOnayla
            // 
            this.btnRandevuOnayla.Location = new System.Drawing.Point(536, 377);
            this.btnRandevuOnayla.Name = "btnRandevuOnayla";
            this.btnRandevuOnayla.Size = new System.Drawing.Size(104, 42);
            this.btnRandevuOnayla.TabIndex = 51;
            this.btnRandevuOnayla.Text = "Randuvaları Onayla";
            this.btnRandevuOnayla.UseVisualStyleBackColor = true;
            this.btnRandevuOnayla.Click += new System.EventHandler(this.btnRandevuOnayla_Click);
            // 
            // dgvGunlerListesi
            // 
            this.dgvGunlerListesi.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvGunlerListesi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGunlerListesi.Location = new System.Drawing.Point(12, 12);
            this.dgvGunlerListesi.Name = "dgvGunlerListesi";
            this.dgvGunlerListesi.Size = new System.Drawing.Size(399, 426);
            this.dgvGunlerListesi.TabIndex = 40;
            this.dgvGunlerListesi.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGunlerListesi_CellClick);
            // 
            // comboOnay
            // 
            this.comboOnay.FormattingEnabled = true;
            this.comboOnay.Items.AddRange(new object[] {
            "Onaylandı",
            "Reddedildi"});
            this.comboOnay.Location = new System.Drawing.Point(536, 350);
            this.comboOnay.Name = "comboOnay";
            this.comboOnay.Size = new System.Drawing.Size(104, 21);
            this.comboOnay.TabIndex = 66;
            // 
            // txtNkullaniciAdi
            // 
            this.txtNkullaniciAdi.Location = new System.Drawing.Point(536, 217);
            this.txtNkullaniciAdi.Name = "txtNkullaniciAdi";
            this.txtNkullaniciAdi.Size = new System.Drawing.Size(104, 20);
            this.txtNkullaniciAdi.TabIndex = 67;
            // 
            // txtSectigiGun
            // 
            this.txtSectigiGun.Location = new System.Drawing.Point(536, 243);
            this.txtSectigiGun.Name = "txtSectigiGun";
            this.txtSectigiGun.Size = new System.Drawing.Size(104, 20);
            this.txtSectigiGun.TabIndex = 68;
            // 
            // txtSectigiSaat
            // 
            this.txtSectigiSaat.Location = new System.Drawing.Point(536, 269);
            this.txtSectigiSaat.Name = "txtSectigiSaat";
            this.txtSectigiSaat.Size = new System.Drawing.Size(104, 20);
            this.txtSectigiSaat.TabIndex = 69;
            // 
            // txtRandevuNo
            // 
            this.txtRandevuNo.Location = new System.Drawing.Point(536, 295);
            this.txtRandevuNo.Name = "txtRandevuNo";
            this.txtRandevuNo.Size = new System.Drawing.Size(104, 20);
            this.txtRandevuNo.TabIndex = 70;
            // 
            // lblNkullaniciAdi
            // 
            this.lblNkullaniciAdi.AutoSize = true;
            this.lblNkullaniciAdi.Location = new System.Drawing.Point(463, 220);
            this.lblNkullaniciAdi.Name = "lblNkullaniciAdi";
            this.lblNkullaniciAdi.Size = new System.Drawing.Size(67, 13);
            this.lblNkullaniciAdi.TabIndex = 71;
            this.lblNkullaniciAdi.Text = "Kullanıcı Adı:";
            // 
            // lblRandevuNo
            // 
            this.lblRandevuNo.AutoSize = true;
            this.lblRandevuNo.Location = new System.Drawing.Point(429, 298);
            this.lblRandevuNo.Name = "lblRandevuNo";
            this.lblRandevuNo.Size = new System.Drawing.Size(101, 13);
            this.lblRandevuNo.TabIndex = 72;
            this.lblRandevuNo.Text = "Randevu Numarası:";
            // 
            // lblSectigiGun
            // 
            this.lblSectigiGun.AutoSize = true;
            this.lblSectigiGun.Location = new System.Drawing.Point(467, 246);
            this.lblSectigiGun.Name = "lblSectigiGun";
            this.lblSectigiGun.Size = new System.Drawing.Size(63, 13);
            this.lblSectigiGun.TabIndex = 72;
            this.lblSectigiGun.Text = "Seçtiği gün:";
            // 
            // lblSectigiSaat
            // 
            this.lblSectigiSaat.AutoSize = true;
            this.lblSectigiSaat.Location = new System.Drawing.Point(435, 272);
            this.lblSectigiSaat.Name = "lblSectigiSaat";
            this.lblSectigiSaat.Size = new System.Drawing.Size(95, 13);
            this.lblSectigiSaat.TabIndex = 73;
            this.lblSectigiSaat.Text = "Seçtiği saat aralığı:";
            // 
            // frmRandevuOnaylama
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblSectigiSaat);
            this.Controls.Add(this.lblSectigiGun);
            this.Controls.Add(this.lblRandevuNo);
            this.Controls.Add(this.lblNkullaniciAdi);
            this.Controls.Add(this.txtRandevuNo);
            this.Controls.Add(this.txtSectigiSaat);
            this.Controls.Add(this.txtSectigiGun);
            this.Controls.Add(this.txtNkullaniciAdi);
            this.Controls.Add(this.comboOnay);
            this.Controls.Add(this.lblIsyeriAdi);
            this.Controls.Add(this.txtIsyeriAdi);
            this.Controls.Add(this.btnTakvimGoster);
            this.Controls.Add(this.lblKullaniciAdi);
            this.Controls.Add(this.txtKullaniciAdi);
            this.Controls.Add(this.btnRandevuOnayla);
            this.Controls.Add(this.dgvGunlerListesi);
            this.Name = "frmRandevuOnaylama";
            this.Text = "Randevu Onaylama";
            ((System.ComponentModel.ISupportInitialize)(this.dgvGunlerListesi)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblIsyeriAdi;
        private System.Windows.Forms.TextBox txtIsyeriAdi;
        private System.Windows.Forms.Button btnTakvimGoster;
        private System.Windows.Forms.Label lblKullaniciAdi;
        private System.Windows.Forms.TextBox txtKullaniciAdi;
        private System.Windows.Forms.Button btnRandevuOnayla;
        private System.Windows.Forms.DataGridView dgvGunlerListesi;
        private System.Windows.Forms.ComboBox comboOnay;
        private System.Windows.Forms.TextBox txtNkullaniciAdi;
        private System.Windows.Forms.TextBox txtSectigiGun;
        private System.Windows.Forms.TextBox txtSectigiSaat;
        private System.Windows.Forms.TextBox txtRandevuNo;
        private System.Windows.Forms.Label lblNkullaniciAdi;
        private System.Windows.Forms.Label lblRandevuNo;
        private System.Windows.Forms.Label lblSectigiGun;
        private System.Windows.Forms.Label lblSectigiSaat;
    }
}