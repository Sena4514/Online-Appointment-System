﻿
namespace Online_Randevu_Sistemi
{
    partial class frmAdminPaneli
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.msAdminPaneli = new System.Windows.Forms.MenuStrip();
            this.işyeriİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.işyeriEkleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.işyeriSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.işyeriAraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.işyeriGüncelleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.raporlarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.işyeriRaporlarıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.işyeriListelemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kullanıcıRaporlarıToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.normalkullanıcıListelemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enFazlaRandevuTalebindeBulunanKullanıcılarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.msAdminPaneli.SuspendLayout();
            this.SuspendLayout();
            // 
            // msAdminPaneli
            // 
            this.msAdminPaneli.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.msAdminPaneli.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.msAdminPaneli.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.işyeriİşlemleriToolStripMenuItem,
            this.raporlarToolStripMenuItem});
            this.msAdminPaneli.Location = new System.Drawing.Point(0, 0);
            this.msAdminPaneli.Name = "msAdminPaneli";
            this.msAdminPaneli.Padding = new System.Windows.Forms.Padding(6, 2, 0, 8);
            this.msAdminPaneli.Size = new System.Drawing.Size(915, 39);
            this.msAdminPaneli.TabIndex = 7;
            this.msAdminPaneli.Text = "menuStrip1";
            // 
            // işyeriİşlemleriToolStripMenuItem
            // 
            this.işyeriİşlemleriToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.işyeriEkleToolStripMenuItem,
            this.işyeriSilToolStripMenuItem,
            this.işyeriAraToolStripMenuItem,
            this.işyeriGüncelleToolStripMenuItem});
            this.işyeriİşlemleriToolStripMenuItem.Name = "işyeriİşlemleriToolStripMenuItem";
            this.işyeriİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(139, 29);
            this.işyeriİşlemleriToolStripMenuItem.Text = "İşyeri İşlemleri";
            // 
            // işyeriEkleToolStripMenuItem
            // 
            this.işyeriEkleToolStripMenuItem.Name = "işyeriEkleToolStripMenuItem";
            this.işyeriEkleToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.işyeriEkleToolStripMenuItem.Text = "İşyeri Ekle";
            this.işyeriEkleToolStripMenuItem.Click += new System.EventHandler(this.işyeriEkleToolStripMenuItem_Click);
            // 
            // işyeriSilToolStripMenuItem
            // 
            this.işyeriSilToolStripMenuItem.Name = "işyeriSilToolStripMenuItem";
            this.işyeriSilToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.işyeriSilToolStripMenuItem.Text = "İşyeri Sil";
            this.işyeriSilToolStripMenuItem.Click += new System.EventHandler(this.işyeriSilToolStripMenuItem_Click);
            // 
            // işyeriAraToolStripMenuItem
            // 
            this.işyeriAraToolStripMenuItem.Name = "işyeriAraToolStripMenuItem";
            this.işyeriAraToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.işyeriAraToolStripMenuItem.Text = "İşyeri Ara";
            this.işyeriAraToolStripMenuItem.Click += new System.EventHandler(this.işyeriAraToolStripMenuItem_Click);
            // 
            // işyeriGüncelleToolStripMenuItem
            // 
            this.işyeriGüncelleToolStripMenuItem.Name = "işyeriGüncelleToolStripMenuItem";
            this.işyeriGüncelleToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.işyeriGüncelleToolStripMenuItem.Text = "İşyeri Güncelle";
            this.işyeriGüncelleToolStripMenuItem.Click += new System.EventHandler(this.işyeriGüncelleToolStripMenuItem_Click);
            // 
            // raporlarToolStripMenuItem
            // 
            this.raporlarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.işyeriRaporlarıToolStripMenuItem,
            this.kullanıcıRaporlarıToolStripMenuItem});
            this.raporlarToolStripMenuItem.Name = "raporlarToolStripMenuItem";
            this.raporlarToolStripMenuItem.Size = new System.Drawing.Size(95, 29);
            this.raporlarToolStripMenuItem.Text = "Raporlar";
            // 
            // işyeriRaporlarıToolStripMenuItem
            // 
            this.işyeriRaporlarıToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.işyeriListelemeToolStripMenuItem});
            this.işyeriRaporlarıToolStripMenuItem.Name = "işyeriRaporlarıToolStripMenuItem";
            this.işyeriRaporlarıToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.işyeriRaporlarıToolStripMenuItem.Text = "İşyeri Raporları";
            // 
            // işyeriListelemeToolStripMenuItem
            // 
            this.işyeriListelemeToolStripMenuItem.Name = "işyeriListelemeToolStripMenuItem";
            this.işyeriListelemeToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.işyeriListelemeToolStripMenuItem.Text = "İşyeri Listeleme";
            this.işyeriListelemeToolStripMenuItem.Click += new System.EventHandler(this.işyeriListelemeToolStripMenuItem_Click);
            // 
            // kullanıcıRaporlarıToolStripMenuItem
            // 
            this.kullanıcıRaporlarıToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.normalkullanıcıListelemeToolStripMenuItem,
            this.enFazlaRandevuTalebindeBulunanKullanıcılarToolStripMenuItem});
            this.kullanıcıRaporlarıToolStripMenuItem.Name = "kullanıcıRaporlarıToolStripMenuItem";
            this.kullanıcıRaporlarıToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.kullanıcıRaporlarıToolStripMenuItem.Text = "Kullanıcı Raporları";
            // 
            // normalkullanıcıListelemeToolStripMenuItem
            // 
            this.normalkullanıcıListelemeToolStripMenuItem.Name = "normalkullanıcıListelemeToolStripMenuItem";
            this.normalkullanıcıListelemeToolStripMenuItem.Size = new System.Drawing.Size(484, 34);
            this.normalkullanıcıListelemeToolStripMenuItem.Text = "Normal Kullanıcı Listeleme";
            this.normalkullanıcıListelemeToolStripMenuItem.Click += new System.EventHandler(this.normalkullanıcıListelemeToolStripMenuItem_Click);
            // 
            // enFazlaRandevuTalebindeBulunanKullanıcılarToolStripMenuItem
            // 
            this.enFazlaRandevuTalebindeBulunanKullanıcılarToolStripMenuItem.Name = "enFazlaRandevuTalebindeBulunanKullanıcılarToolStripMenuItem";
            this.enFazlaRandevuTalebindeBulunanKullanıcılarToolStripMenuItem.Size = new System.Drawing.Size(484, 34);
            this.enFazlaRandevuTalebindeBulunanKullanıcılarToolStripMenuItem.Text = "En Fazla Randevu Talebinde Bulunan Kullanıcılar";
            // 
            // frmAdminPaneli
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(915, 450);
            this.Controls.Add(this.msAdminPaneli);
            this.IsMdiContainer = true;
            this.Name = "frmAdminPaneli";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin Paneli";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.msAdminPaneli.ResumeLayout(false);
            this.msAdminPaneli.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip msAdminPaneli;
        private System.Windows.Forms.ToolStripMenuItem işyeriİşlemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem işyeriEkleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem işyeriSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem işyeriAraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem işyeriGüncelleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem raporlarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem işyeriRaporlarıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem işyeriListelemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kullanıcıRaporlarıToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem normalkullanıcıListelemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enFazlaRandevuTalebindeBulunanKullanıcılarToolStripMenuItem;
    }
}