﻿
namespace Online_Randevu_Sistemi
{
    partial class frmNormalKullaniciListelemeRapor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.onlineRandevuSistemiDataSet1 = new Online_Randevu_Sistemi.OnlineRandevuSistemiDataSet1();
            this.normalkullaniciBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.normalkullaniciTableAdapter = new Online_Randevu_Sistemi.OnlineRandevuSistemiDataSet1TableAdapters.normalkullaniciTableAdapter();
            this.dgvNormalKullaniciListelemeRapor = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.onlineRandevuSistemiDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.normalkullaniciBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNormalKullaniciListelemeRapor)).BeginInit();
            this.SuspendLayout();
            // 
            // onlineRandevuSistemiDataSet1
            // 
            this.onlineRandevuSistemiDataSet1.DataSetName = "OnlineRandevuSistemiDataSet1";
            this.onlineRandevuSistemiDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // normalkullaniciBindingSource
            // 
            this.normalkullaniciBindingSource.DataMember = "normalkullanici";
            this.normalkullaniciBindingSource.DataSource = this.onlineRandevuSistemiDataSet1;
            // 
            // normalkullaniciTableAdapter
            // 
            this.normalkullaniciTableAdapter.ClearBeforeFill = true;
            // 
            // dgvNormalKullaniciListelemeRapor
            // 
            this.dgvNormalKullaniciListelemeRapor.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvNormalKullaniciListelemeRapor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNormalKullaniciListelemeRapor.Location = new System.Drawing.Point(2, 0);
            this.dgvNormalKullaniciListelemeRapor.Name = "dgvNormalKullaniciListelemeRapor";
            this.dgvNormalKullaniciListelemeRapor.RowHeadersWidth = 62;
            this.dgvNormalKullaniciListelemeRapor.RowTemplate.Height = 28;
            this.dgvNormalKullaniciListelemeRapor.Size = new System.Drawing.Size(1200, 571);
            this.dgvNormalKullaniciListelemeRapor.TabIndex = 0;
            // 
            // frmNormalKullaniciListelemeRapor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1201, 571);
            this.Controls.Add(this.dgvNormalKullaniciListelemeRapor);
            this.Name = "frmNormalKullaniciListelemeRapor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Rapor-Normal Kullanıcı Listeleme";
            this.Load += new System.EventHandler(this.frmNormalKullaniciListelemeRapor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.onlineRandevuSistemiDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.normalkullaniciBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNormalKullaniciListelemeRapor)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private OnlineRandevuSistemiDataSet1 onlineRandevuSistemiDataSet1;
        private System.Windows.Forms.BindingSource normalkullaniciBindingSource;
        private OnlineRandevuSistemiDataSet1TableAdapters.normalkullaniciTableAdapter normalkullaniciTableAdapter;
        private System.Windows.Forms.DataGridView dgvNormalKullaniciListelemeRapor;
    }
}