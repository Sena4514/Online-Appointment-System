﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Online_Randevu_Sistemi
{
    class SoruCevapElemanlar
    {
        public int Soru_No { get; set; }
        public string Kullanici_isim { get; set; }
        public string Kullanici_Soyisim { get; set; }
        public string Soru_Baslik { get; set; }
        public string Soru { get; set; }
        public string Yetkili_adi { get; set; }
        public string Cevap { get; set; }
        public int Secili_Alan { get; set; }
    }
}
