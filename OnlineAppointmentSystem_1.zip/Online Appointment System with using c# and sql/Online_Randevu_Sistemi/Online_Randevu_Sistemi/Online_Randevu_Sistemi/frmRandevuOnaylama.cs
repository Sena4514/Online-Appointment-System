﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Randevu_Sistemi
{
    public partial class frmRandevuOnaylama : Form
    {
        public frmRandevuOnaylama()
        {
            InitializeComponent();
        }

        RandevuIslemleri Islemler = new RandevuIslemleri();
        RandevuElemanlar elemanlar = new RandevuElemanlar();
        private void btnTakvimGoster_Click(object sender, EventArgs e)
        {
            elemanlar.Isyeri_Adi = txtIsyeriAdi.Text;
            Islemler.RandevuTakvimGoster(dgvGunlerListesi, elemanlar);
        }

        private void dgvGunlerListesi_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            elemanlar.Secili_Alan= dgvGunlerListesi.SelectedCells[0].RowIndex;
            elemanlar.Randevu_No= dgvGunlerListesi.Rows[elemanlar.Secili_Alan].Cells[0].Value.ToString();
            elemanlar.Isyeri_Adi= dgvGunlerListesi.Rows[elemanlar.Secili_Alan].Cells[1].Value.ToString();
            elemanlar.Kullanici_Adi = dgvGunlerListesi.Rows[elemanlar.Secili_Alan].Cells[2].Value.ToString();
            elemanlar.Randevu_Gun = dgvGunlerListesi.Rows[elemanlar.Secili_Alan].Cells[3].Value.ToString();
            elemanlar.Randevu_Saat= dgvGunlerListesi.Rows[elemanlar.Secili_Alan].Cells[4].Value.ToString();
            elemanlar.Randevu_Onay_Durumu = dgvGunlerListesi.Rows[elemanlar.Secili_Alan].Cells[5].Value.ToString();

            txtNkullaniciAdi.Text = elemanlar.Kullanici_Adi;
            txtRandevuNo.Text = elemanlar.Randevu_No;
            txtSectigiGun.Text = elemanlar.Randevu_Gun;
            txtSectigiSaat.Text = elemanlar.Randevu_Saat;
        }
        private void btnRandevuOnayla_Click(object sender, EventArgs e)
        {
            elemanlar.Yetkili_Adi = txtKullaniciAdi.Text;
            elemanlar.Randevu_Onay_Durumu = comboOnay.Text;
            Islemler.TalepOnayla(elemanlar);
            Islemler.RandevuTakvimGoster(dgvGunlerListesi, elemanlar);

            MessageBox.Show("Randevu İşlemi tamamlanmıştır!!");
            txtKullaniciAdi.Text = txtIsyeriAdi.Text = txtNkullaniciAdi.Text = txtRandevuNo.Text = txtSectigiGun.Text = txtSectigiSaat.Text = "";
        }    
    }
}
