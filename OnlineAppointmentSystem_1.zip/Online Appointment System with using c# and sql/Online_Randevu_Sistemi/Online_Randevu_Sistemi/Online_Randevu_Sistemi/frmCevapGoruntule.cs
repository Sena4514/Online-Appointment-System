﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Randevu_Sistemi
{
    public partial class frmCevapGoruntule : Form
    {
        public frmCevapGoruntule()
        {
            InitializeComponent();
        }

        SoruCevap SoruCevap = new SoruCevap();
        SoruCevapElemanlar elemanlar = new SoruCevapElemanlar();

        private void btnCevapSorgula_Click(object sender, EventArgs e)
        {
            elemanlar.Soru_No = Convert.ToInt32(txtSoruNo);
            SoruCevap.CevapSorgula(elemanlar, dgvCevapGoruntule);
        }

        private void btnAra_Click(object sender, EventArgs e)
        {
            try
            {
                elemanlar.Kullanici_isim = txtKullaniciAdi.Text;
                SoruCevap.CevapAra(elemanlar, dgvCevapGoruntule);
            }
            catch (Exception)
            {
                MessageBox.Show("Hatalı Giriş Yaptınız!!");
            }
        }

        private void dgvCevapGoruntule_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            elemanlar.Secili_Alan = dgvCevapGoruntule.SelectedCells[0].RowIndex;
            elemanlar.Cevap = dgvCevapGoruntule.Rows[elemanlar.Secili_Alan].Cells[4].Value.ToString();

            txtCevap.Text = elemanlar.Cevap;
        }
    }
}
