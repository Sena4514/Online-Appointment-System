﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Randevu_Sistemi
{
    public partial class frmIsyeriGuncelle : Form
    {
        public frmIsyeriGuncelle()
        {
            InitializeComponent();
        }

        IsyeriIslemleri Islemler = new IsyeriIslemleri();
        IsyeriElemanları elemanlar = new IsyeriElemanları();

        private void btnIsyerleriGoruntule_Click(object sender, EventArgs e)
        {
            Islemler.IsyerleriGoster(dgvIsyeriGuncelle);
        }

        private void dgvIsyeriGuncelle_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            elemanlar.Secili_Alan = dgvIsyeriGuncelle.SelectedCells[0].RowIndex;
            elemanlar.isyeri_adi = dgvIsyeriGuncelle.Rows[elemanlar.Secili_Alan].Cells[0].Value.ToString();
            elemanlar.isyeri_yetkili_isim = dgvIsyeriGuncelle.Rows[elemanlar.Secili_Alan].Cells[1].Value.ToString();
            elemanlar.isyeri_yetkili_soyisim = dgvIsyeriGuncelle.Rows[elemanlar.Secili_Alan].Cells[2].Value.ToString();
            elemanlar.isyeri_turu = dgvIsyeriGuncelle.Rows[elemanlar.Secili_Alan].Cells[3].Value.ToString();
            elemanlar.isyeri_adres = dgvIsyeriGuncelle.Rows[elemanlar.Secili_Alan].Cells[4].Value.ToString();
            elemanlar.isyeri_telNo = dgvIsyeriGuncelle.Rows[elemanlar.Secili_Alan].Cells[5].Value.ToString();

            txtGuncellenecekIsyeriIsmi.Text = elemanlar.isyeri_adi;
            txtIsyeriYetkiliIsmi.Text = elemanlar.isyeri_yetkili_isim;
            txtIsyeriYetkiliSoyismi.Text = elemanlar.isyeri_yetkili_soyisim;
            txtIsyeriTuru.Text = elemanlar.isyeri_turu;
            txtIsyeriAdres.Text = elemanlar.isyeri_adres;
            mtbIsyeriTelNo.Text = elemanlar.isyeri_telNo;
        }

        private void btnIsyeriGuncelle_Click(object sender, EventArgs e)
        {
            Islemler.IsyeriGuncelle(elemanlar, txtGuncellenecekIsyeriIsmi.Text);
            Islemler.IsyerleriGoster(dgvIsyeriGuncelle);
        }

    }
}
