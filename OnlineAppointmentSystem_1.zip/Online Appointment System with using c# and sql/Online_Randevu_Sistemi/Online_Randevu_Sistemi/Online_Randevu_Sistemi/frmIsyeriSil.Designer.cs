﻿
namespace Online_Randevu_Sistemi
{
    partial class frmIsyeriSil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmIsyeriSil));
            this.btnIsyeriSil = new System.Windows.Forms.Button();
            this.ilIsyeriSil = new System.Windows.Forms.ImageList(this.components);
            this.lblSilinecekIsyeriIsmi = new System.Windows.Forms.Label();
            this.txtSilinecekIsyeriIsmi = new System.Windows.Forms.TextBox();
            this.dgvIsyeriSil = new System.Windows.Forms.DataGridView();
            this.btnIsyerleriGoruntule = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvIsyeriSil)).BeginInit();
            this.SuspendLayout();
            // 
            // btnIsyeriSil
            // 
            this.btnIsyeriSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIsyeriSil.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnIsyeriSil.ImageIndex = 0;
            this.btnIsyeriSil.ImageList = this.ilIsyeriSil;
            this.btnIsyeriSil.Location = new System.Drawing.Point(235, 302);
            this.btnIsyeriSil.Name = "btnIsyeriSil";
            this.btnIsyeriSil.Size = new System.Drawing.Size(197, 67);
            this.btnIsyeriSil.TabIndex = 1;
            this.btnIsyeriSil.Text = "İşyeri Sil";
            this.btnIsyeriSil.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnIsyeriSil.UseVisualStyleBackColor = true;
            this.btnIsyeriSil.Click += new System.EventHandler(this.btnIsyeriSil_Click);
            // 
            // ilIsyeriSil
            // 
            this.ilIsyeriSil.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ilIsyeriSil.ImageStream")));
            this.ilIsyeriSil.TransparentColor = System.Drawing.Color.Transparent;
            this.ilIsyeriSil.Images.SetKeyName(0, "delete.jpg");
            // 
            // lblSilinecekIsyeriIsmi
            // 
            this.lblSilinecekIsyeriIsmi.AutoSize = true;
            this.lblSilinecekIsyeriIsmi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSilinecekIsyeriIsmi.Location = new System.Drawing.Point(12, 68);
            this.lblSilinecekIsyeriIsmi.Name = "lblSilinecekIsyeriIsmi";
            this.lblSilinecekIsyeriIsmi.Size = new System.Drawing.Size(192, 22);
            this.lblSilinecekIsyeriIsmi.TabIndex = 30;
            this.lblSilinecekIsyeriIsmi.Text = "Silinecek İşyeri İsmi:";
            // 
            // txtSilinecekIsyeriIsmi
            // 
            this.txtSilinecekIsyeriIsmi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSilinecekIsyeriIsmi.Location = new System.Drawing.Point(235, 68);
            this.txtSilinecekIsyeriIsmi.Multiline = true;
            this.txtSilinecekIsyeriIsmi.Name = "txtSilinecekIsyeriIsmi";
            this.txtSilinecekIsyeriIsmi.Size = new System.Drawing.Size(197, 47);
            this.txtSilinecekIsyeriIsmi.TabIndex = 0;
            // 
            // dgvIsyeriSil
            // 
            this.dgvIsyeriSil.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvIsyeriSil.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvIsyeriSil.Location = new System.Drawing.Point(446, 13);
            this.dgvIsyeriSil.Name = "dgvIsyeriSil";
            this.dgvIsyeriSil.RowHeadersWidth = 62;
            this.dgvIsyeriSil.RowTemplate.Height = 28;
            this.dgvIsyeriSil.Size = new System.Drawing.Size(916, 724);
            this.dgvIsyeriSil.TabIndex = 37;
            // 
            // btnIsyerleriGoruntule
            // 
            this.btnIsyerleriGoruntule.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIsyerleriGoruntule.Location = new System.Drawing.Point(235, 188);
            this.btnIsyerleriGoruntule.Name = "btnIsyerleriGoruntule";
            this.btnIsyerleriGoruntule.Size = new System.Drawing.Size(197, 91);
            this.btnIsyerleriGoruntule.TabIndex = 38;
            this.btnIsyerleriGoruntule.Text = "Mevcut İşyerlerini Göster";
            this.btnIsyerleriGoruntule.UseVisualStyleBackColor = true;
            this.btnIsyerleriGoruntule.Click += new System.EventHandler(this.btnIsyerleriGoruntule_Click);
            // 
            // frmIsyeriSil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1374, 749);
            this.Controls.Add(this.btnIsyerleriGoruntule);
            this.Controls.Add(this.dgvIsyeriSil);
            this.Controls.Add(this.lblSilinecekIsyeriIsmi);
            this.Controls.Add(this.txtSilinecekIsyeriIsmi);
            this.Controls.Add(this.btnIsyeriSil);
            this.Name = "frmIsyeriSil";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "İşyeri Silme Formu";
            ((System.ComponentModel.ISupportInitialize)(this.dgvIsyeriSil)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnIsyeriSil;
        private System.Windows.Forms.ImageList ilIsyeriSil;
        private System.Windows.Forms.Label lblSilinecekIsyeriIsmi;
        private System.Windows.Forms.TextBox txtSilinecekIsyeriIsmi;
        private System.Windows.Forms.DataGridView dgvIsyeriSil;
        private System.Windows.Forms.Button btnIsyerleriGoruntule;
    }
}