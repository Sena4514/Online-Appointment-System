﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Online_Randevu_Sistemi
{
    class RandevuElemanlar
    {
        public string Randevu_No{ get; set; }
        public string Kullanici_Adi { get; set; }
        public string Yetkili_Adi { get; set; }
        public string Isyeri_Adi { get; set; }
        public string Randevu_Gun { get; set; }
        public string Randevu_Saat { get; set; }
        public string Randevu_Onay_Durumu { get; set; }
        public string sekizDokuz { get; set; }
        public string dokuzOn { get; set; }
        public string onOnbir { get; set; }
        public string onbirOniki { get; set; }
        public string onucOndort { get; set; }
        public string ondortOnbes { get; set; }
        public string onbesOnalti { get; set; }
        public string onaltiOnyedi { get; set; }
        public int Secili_Alan { get; set; }
    }
}
