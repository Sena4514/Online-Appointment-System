﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Online_Randevu_Sistemi
{
    public partial class frmYetkiliKayit : Form
    {
        public frmYetkiliKayit()
        {
            InitializeComponent();
        }

        KayitIslemleri Islemler = new KayitIslemleri();
        

        private void btnYetkiliKaydet_Click(object sender, EventArgs e)
        {
            try
            {
                YetkiliElemanlar elemanlar = new YetkiliElemanlar()
                {
                    yetkili_isim = txtisim.Text,
                    yetkili_soyisim = txtsoyisim.Text,
                    yetkili_kullanici_adi = txtkullaniciAdi.Text,
                    yetkili_sifre = txtsifre.Text,
                    yetkili_email = txtemail.Text,
                    yetkili_adres = txtadres.Text,
                    yetkili_dogumTarihi = mtbDogumTarihi.Text,
                    yetkili_isyeri_adi = txtIsyeriAdi.Text,
                    yetkili_TcNo = mtbTcKimlikNo.Text,
                    yetkili_telNo=mtbtelNo.Text
                };
                Islemler.YetkiliKayit(elemanlar);
                MessageBox.Show("Yetkili Kayit Islemi Basarili");
                frmGirisEkrani frmgirisekrani = new frmGirisEkrani();
                this.Hide();
                frmgirisekrani.Show();
            }
            catch(Exception)
            {
                MessageBox.Show("Hatalı ve ya eksik bilgi doldurdunuz!!");
            }
        }
    }
}
