﻿
namespace Online_Randevu_Sistemi
{
    partial class frmCevapGoruntule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.onlineRandevuSistemiDataSet = new Online_Randevu_Sistemi.OnlineRandevuSistemiDataSet();
            this.onlineRandevuSistemiDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.isyeriBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.isyeriTableAdapter = new Online_Randevu_Sistemi.OnlineRandevuSistemiDataSetTableAdapters.isyeriTableAdapter();
            this.txtCevap = new System.Windows.Forms.TextBox();
            this.txtSoruNo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCevapSorgula = new System.Windows.Forms.Button();
            this.txtKullaniciAdi = new System.Windows.Forms.TextBox();
            this.lblKullaniciAdi = new System.Windows.Forms.Label();
            this.dgvCevapGoruntule = new System.Windows.Forms.DataGridView();
            this.btnAra = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.onlineRandevuSistemiDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.onlineRandevuSistemiDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.isyeriBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCevapGoruntule)).BeginInit();
            this.SuspendLayout();
            // 
            // onlineRandevuSistemiDataSet
            // 
            this.onlineRandevuSistemiDataSet.DataSetName = "OnlineRandevuSistemiDataSet";
            this.onlineRandevuSistemiDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // onlineRandevuSistemiDataSetBindingSource
            // 
            this.onlineRandevuSistemiDataSetBindingSource.DataSource = this.onlineRandevuSistemiDataSet;
            this.onlineRandevuSistemiDataSetBindingSource.Position = 0;
            // 
            // isyeriBindingSource
            // 
            this.isyeriBindingSource.DataMember = "isyeri";
            this.isyeriBindingSource.DataSource = this.onlineRandevuSistemiDataSetBindingSource;
            // 
            // isyeriTableAdapter
            // 
            this.isyeriTableAdapter.ClearBeforeFill = true;
            // 
            // txtCevap
            // 
            this.txtCevap.Enabled = false;
            this.txtCevap.Location = new System.Drawing.Point(12, 131);
            this.txtCevap.Multiline = true;
            this.txtCevap.Name = "txtCevap";
            this.txtCevap.Size = new System.Drawing.Size(355, 307);
            this.txtCevap.TabIndex = 0;
            // 
            // txtSoruNo
            // 
            this.txtSoruNo.Location = new System.Drawing.Point(153, 34);
            this.txtSoruNo.Name = "txtSoruNo";
            this.txtSoruNo.Size = new System.Drawing.Size(100, 20);
            this.txtSoruNo.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Soru Numaranıızı giriniz:";
            // 
            // btnCevapSorgula
            // 
            this.btnCevapSorgula.Location = new System.Drawing.Point(167, 70);
            this.btnCevapSorgula.Name = "btnCevapSorgula";
            this.btnCevapSorgula.Size = new System.Drawing.Size(75, 41);
            this.btnCevapSorgula.TabIndex = 3;
            this.btnCevapSorgula.Text = "Sorgula";
            this.btnCevapSorgula.UseVisualStyleBackColor = true;
            this.btnCevapSorgula.Click += new System.EventHandler(this.btnCevapSorgula_Click);
            // 
            // txtKullaniciAdi
            // 
            this.txtKullaniciAdi.Location = new System.Drawing.Point(559, 34);
            this.txtKullaniciAdi.Name = "txtKullaniciAdi";
            this.txtKullaniciAdi.Size = new System.Drawing.Size(100, 20);
            this.txtKullaniciAdi.TabIndex = 4;
            // 
            // lblKullaniciAdi
            // 
            this.lblKullaniciAdi.AutoSize = true;
            this.lblKullaniciAdi.Location = new System.Drawing.Point(484, 37);
            this.lblKullaniciAdi.Name = "lblKullaniciAdi";
            this.lblKullaniciAdi.Size = new System.Drawing.Size(69, 13);
            this.lblKullaniciAdi.TabIndex = 5;
            this.lblKullaniciAdi.Text = "Adınızı giriniz:";
            // 
            // dgvCevapGoruntule
            // 
            this.dgvCevapGoruntule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCevapGoruntule.Location = new System.Drawing.Point(381, 131);
            this.dgvCevapGoruntule.Name = "dgvCevapGoruntule";
            this.dgvCevapGoruntule.Size = new System.Drawing.Size(407, 307);
            this.dgvCevapGoruntule.TabIndex = 6;
            this.dgvCevapGoruntule.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCevapGoruntule_CellClick);
            // 
            // btnAra
            // 
            this.btnAra.Location = new System.Drawing.Point(572, 70);
            this.btnAra.Name = "btnAra";
            this.btnAra.Size = new System.Drawing.Size(75, 41);
            this.btnAra.TabIndex = 7;
            this.btnAra.Text = "Ara";
            this.btnAra.UseVisualStyleBackColor = true;
            this.btnAra.Click += new System.EventHandler(this.btnAra_Click);
            // 
            // frmCevapGoruntule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnAra);
            this.Controls.Add(this.dgvCevapGoruntule);
            this.Controls.Add(this.lblKullaniciAdi);
            this.Controls.Add(this.txtKullaniciAdi);
            this.Controls.Add(this.btnCevapSorgula);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtSoruNo);
            this.Controls.Add(this.txtCevap);
            this.Name = "frmCevapGoruntule";
            this.Text = "Cevap Görüntüle";
            ((System.ComponentModel.ISupportInitialize)(this.onlineRandevuSistemiDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.onlineRandevuSistemiDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.isyeriBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCevapGoruntule)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.BindingSource onlineRandevuSistemiDataSetBindingSource;
        private OnlineRandevuSistemiDataSet onlineRandevuSistemiDataSet;
        private System.Windows.Forms.BindingSource isyeriBindingSource;
        private OnlineRandevuSistemiDataSetTableAdapters.isyeriTableAdapter isyeriTableAdapter;
        private System.Windows.Forms.TextBox txtCevap;
        private System.Windows.Forms.TextBox txtSoruNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCevapSorgula;
        private System.Windows.Forms.TextBox txtKullaniciAdi;
        private System.Windows.Forms.Label lblKullaniciAdi;
        private System.Windows.Forms.DataGridView dgvCevapGoruntule;
        private System.Windows.Forms.Button btnAra;
    }
}