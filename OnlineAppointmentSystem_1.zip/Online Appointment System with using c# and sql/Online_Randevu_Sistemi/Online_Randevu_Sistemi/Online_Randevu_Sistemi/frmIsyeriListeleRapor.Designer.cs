﻿
namespace Online_Randevu_Sistemi
{
    partial class frmIsyeriListeleRapor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.isyeriBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.onlineRandevuSistemiDataSet = new Online_Randevu_Sistemi.OnlineRandevuSistemiDataSet();
            this.isyeriTableAdapter = new Online_Randevu_Sistemi.OnlineRandevuSistemiDataSetTableAdapters.isyeriTableAdapter();
            this.dgvMevcutIsyeriListeleRapor = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.isyeriBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.onlineRandevuSistemiDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMevcutIsyeriListeleRapor)).BeginInit();
            this.SuspendLayout();
            // 
            // isyeriBindingSource
            // 
            this.isyeriBindingSource.DataMember = "isyeri";
            this.isyeriBindingSource.DataSource = this.onlineRandevuSistemiDataSet;
            // 
            // onlineRandevuSistemiDataSet
            // 
            this.onlineRandevuSistemiDataSet.DataSetName = "OnlineRandevuSistemiDataSet";
            this.onlineRandevuSistemiDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // isyeriTableAdapter
            // 
            this.isyeriTableAdapter.ClearBeforeFill = true;
            // 
            // dgvMevcutIsyeriListeleRapor
            // 
            this.dgvMevcutIsyeriListeleRapor.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvMevcutIsyeriListeleRapor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMevcutIsyeriListeleRapor.Location = new System.Drawing.Point(1, 1);
            this.dgvMevcutIsyeriListeleRapor.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dgvMevcutIsyeriListeleRapor.Name = "dgvMevcutIsyeriListeleRapor";
            this.dgvMevcutIsyeriListeleRapor.RowHeadersWidth = 62;
            this.dgvMevcutIsyeriListeleRapor.RowTemplate.Height = 28;
            this.dgvMevcutIsyeriListeleRapor.Size = new System.Drawing.Size(780, 376);
            this.dgvMevcutIsyeriListeleRapor.TabIndex = 0;
            // 
            // frmIsyeriListeleRapor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(780, 376);
            this.Controls.Add(this.dgvMevcutIsyeriListeleRapor);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmIsyeriListeleRapor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Rapor-Mevcut İşyerlerini Listeleme";
            this.Load += new System.EventHandler(this.frmIsyeriListeleRapor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.isyeriBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.onlineRandevuSistemiDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMevcutIsyeriListeleRapor)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private OnlineRandevuSistemiDataSet onlineRandevuSistemiDataSet;
        private System.Windows.Forms.BindingSource isyeriBindingSource;
        private OnlineRandevuSistemiDataSetTableAdapters.isyeriTableAdapter isyeriTableAdapter;
        private System.Windows.Forms.DataGridView dgvMevcutIsyeriListeleRapor;
    }
}