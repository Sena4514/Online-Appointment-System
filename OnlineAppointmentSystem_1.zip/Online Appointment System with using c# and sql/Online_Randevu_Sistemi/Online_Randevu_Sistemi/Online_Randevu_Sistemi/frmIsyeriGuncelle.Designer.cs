﻿
namespace Online_Randevu_Sistemi
{
    partial class frmIsyeriGuncelle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmIsyeriGuncelle));
            this.btnIsyeriGuncelle = new System.Windows.Forms.Button();
            this.ilIsyeriGuncelle = new System.Windows.Forms.ImageList(this.components);
            this.dgvIsyeriGuncelle = new System.Windows.Forms.DataGridView();
            this.mtbIsyeriTelNo = new System.Windows.Forms.MaskedTextBox();
            this.lblIsyeriTelNo = new System.Windows.Forms.Label();
            this.lblIsyeriAdres = new System.Windows.Forms.Label();
            this.txtIsyeriAdres = new System.Windows.Forms.TextBox();
            this.lblIsyeriTuru = new System.Windows.Forms.Label();
            this.txtIsyeriTuru = new System.Windows.Forms.TextBox();
            this.lblGuncellenecekIsyeriIsmi = new System.Windows.Forms.Label();
            this.txtGuncellenecekIsyeriIsmi = new System.Windows.Forms.TextBox();
            this.lblIsyeriYetkiliSoyismi = new System.Windows.Forms.Label();
            this.lblIsyeriYetkiliİsmi = new System.Windows.Forms.Label();
            this.txtIsyeriYetkiliSoyismi = new System.Windows.Forms.TextBox();
            this.txtIsyeriYetkiliIsmi = new System.Windows.Forms.TextBox();
            this.btnIsyerleriGoruntule = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvIsyeriGuncelle)).BeginInit();
            this.SuspendLayout();
            // 
            // btnIsyeriGuncelle
            // 
            this.btnIsyeriGuncelle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIsyeriGuncelle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnIsyeriGuncelle.ImageIndex = 0;
            this.btnIsyeriGuncelle.ImageList = this.ilIsyeriGuncelle;
            this.btnIsyeriGuncelle.Location = new System.Drawing.Point(183, 450);
            this.btnIsyeriGuncelle.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnIsyeriGuncelle.Name = "btnIsyeriGuncelle";
            this.btnIsyeriGuncelle.Size = new System.Drawing.Size(173, 60);
            this.btnIsyeriGuncelle.TabIndex = 7;
            this.btnIsyeriGuncelle.Text = "İşyeri Güncelle";
            this.btnIsyeriGuncelle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnIsyeriGuncelle.UseVisualStyleBackColor = true;
            this.btnIsyeriGuncelle.Click += new System.EventHandler(this.btnIsyeriGuncelle_Click);
            // 
            // ilIsyeriGuncelle
            // 
            this.ilIsyeriGuncelle.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ilIsyeriGuncelle.ImageStream")));
            this.ilIsyeriGuncelle.TransparentColor = System.Drawing.Color.Transparent;
            this.ilIsyeriGuncelle.Images.SetKeyName(0, "update.jfif");
            // 
            // dgvIsyeriGuncelle
            // 
            this.dgvIsyeriGuncelle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvIsyeriGuncelle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvIsyeriGuncelle.Location = new System.Drawing.Point(378, 7);
            this.dgvIsyeriGuncelle.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dgvIsyeriGuncelle.Name = "dgvIsyeriGuncelle";
            this.dgvIsyeriGuncelle.RowHeadersWidth = 62;
            this.dgvIsyeriGuncelle.RowTemplate.Height = 28;
            this.dgvIsyeriGuncelle.Size = new System.Drawing.Size(547, 503);
            this.dgvIsyeriGuncelle.TabIndex = 21;
            this.dgvIsyeriGuncelle.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvIsyeriGuncelle_CellClick);
            // 
            // mtbIsyeriTelNo
            // 
            this.mtbIsyeriTelNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtbIsyeriTelNo.Location = new System.Drawing.Point(225, 392);
            this.mtbIsyeriTelNo.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.mtbIsyeriTelNo.Mask = "(999) 000-0000";
            this.mtbIsyeriTelNo.Name = "mtbIsyeriTelNo";
            this.mtbIsyeriTelNo.Size = new System.Drawing.Size(133, 23);
            this.mtbIsyeriTelNo.TabIndex = 5;
            // 
            // lblIsyeriTelNo
            // 
            this.lblIsyeriTelNo.AutoSize = true;
            this.lblIsyeriTelNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIsyeriTelNo.Location = new System.Drawing.Point(18, 392);
            this.lblIsyeriTelNo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblIsyeriTelNo.Name = "lblIsyeriTelNo";
            this.lblIsyeriTelNo.Size = new System.Drawing.Size(91, 15);
            this.lblIsyeriTelNo.TabIndex = 46;
            this.lblIsyeriTelNo.Text = "İşyeri Tel.No:";
            // 
            // lblIsyeriAdres
            // 
            this.lblIsyeriAdres.AutoSize = true;
            this.lblIsyeriAdres.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIsyeriAdres.Location = new System.Drawing.Point(18, 261);
            this.lblIsyeriAdres.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblIsyeriAdres.Name = "lblIsyeriAdres";
            this.lblIsyeriAdres.Size = new System.Drawing.Size(85, 15);
            this.lblIsyeriAdres.TabIndex = 45;
            this.lblIsyeriAdres.Text = "İşyeri Adres:";
            // 
            // txtIsyeriAdres
            // 
            this.txtIsyeriAdres.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIsyeriAdres.Location = new System.Drawing.Point(225, 257);
            this.txtIsyeriAdres.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtIsyeriAdres.Multiline = true;
            this.txtIsyeriAdres.Name = "txtIsyeriAdres";
            this.txtIsyeriAdres.Size = new System.Drawing.Size(133, 102);
            this.txtIsyeriAdres.TabIndex = 4;
            // 
            // lblIsyeriTuru
            // 
            this.lblIsyeriTuru.AutoSize = true;
            this.lblIsyeriTuru.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIsyeriTuru.Location = new System.Drawing.Point(18, 200);
            this.lblIsyeriTuru.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblIsyeriTuru.Name = "lblIsyeriTuru";
            this.lblIsyeriTuru.Size = new System.Drawing.Size(78, 15);
            this.lblIsyeriTuru.TabIndex = 44;
            this.lblIsyeriTuru.Text = "İşyeri Türü:";
            // 
            // txtIsyeriTuru
            // 
            this.txtIsyeriTuru.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIsyeriTuru.Location = new System.Drawing.Point(225, 200);
            this.txtIsyeriTuru.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtIsyeriTuru.Multiline = true;
            this.txtIsyeriTuru.Name = "txtIsyeriTuru";
            this.txtIsyeriTuru.Size = new System.Drawing.Size(133, 32);
            this.txtIsyeriTuru.TabIndex = 3;
            // 
            // lblGuncellenecekIsyeriIsmi
            // 
            this.lblGuncellenecekIsyeriIsmi.AutoSize = true;
            this.lblGuncellenecekIsyeriIsmi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGuncellenecekIsyeriIsmi.Location = new System.Drawing.Point(18, 27);
            this.lblGuncellenecekIsyeriIsmi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblGuncellenecekIsyeriIsmi.Name = "lblGuncellenecekIsyeriIsmi";
            this.lblGuncellenecekIsyeriIsmi.Size = new System.Drawing.Size(175, 15);
            this.lblGuncellenecekIsyeriIsmi.TabIndex = 43;
            this.lblGuncellenecekIsyeriIsmi.Text = "Güncellenecek İşyeri İsmi:";
            // 
            // txtGuncellenecekIsyeriIsmi
            // 
            this.txtGuncellenecekIsyeriIsmi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGuncellenecekIsyeriIsmi.Location = new System.Drawing.Point(225, 27);
            this.txtGuncellenecekIsyeriIsmi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtGuncellenecekIsyeriIsmi.Multiline = true;
            this.txtGuncellenecekIsyeriIsmi.Name = "txtGuncellenecekIsyeriIsmi";
            this.txtGuncellenecekIsyeriIsmi.Size = new System.Drawing.Size(133, 32);
            this.txtGuncellenecekIsyeriIsmi.TabIndex = 0;
            // 
            // lblIsyeriYetkiliSoyismi
            // 
            this.lblIsyeriYetkiliSoyismi.AutoSize = true;
            this.lblIsyeriYetkiliSoyismi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIsyeriYetkiliSoyismi.Location = new System.Drawing.Point(18, 144);
            this.lblIsyeriYetkiliSoyismi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblIsyeriYetkiliSoyismi.Name = "lblIsyeriYetkiliSoyismi";
            this.lblIsyeriYetkiliSoyismi.Size = new System.Drawing.Size(153, 15);
            this.lblIsyeriYetkiliSoyismi.TabIndex = 42;
            this.lblIsyeriYetkiliSoyismi.Text = "İşyeri Yetkilisi Soyismi:";
            // 
            // lblIsyeriYetkiliİsmi
            // 
            this.lblIsyeriYetkiliİsmi.AutoSize = true;
            this.lblIsyeriYetkiliİsmi.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIsyeriYetkiliİsmi.Location = new System.Drawing.Point(18, 85);
            this.lblIsyeriYetkiliİsmi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblIsyeriYetkiliİsmi.Name = "lblIsyeriYetkiliİsmi";
            this.lblIsyeriYetkiliİsmi.Size = new System.Drawing.Size(130, 15);
            this.lblIsyeriYetkiliİsmi.TabIndex = 41;
            this.lblIsyeriYetkiliİsmi.Text = "İşyeri Yetkilisi İsmi:";
            // 
            // txtIsyeriYetkiliSoyismi
            // 
            this.txtIsyeriYetkiliSoyismi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIsyeriYetkiliSoyismi.Location = new System.Drawing.Point(225, 144);
            this.txtIsyeriYetkiliSoyismi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtIsyeriYetkiliSoyismi.Multiline = true;
            this.txtIsyeriYetkiliSoyismi.Name = "txtIsyeriYetkiliSoyismi";
            this.txtIsyeriYetkiliSoyismi.Size = new System.Drawing.Size(133, 32);
            this.txtIsyeriYetkiliSoyismi.TabIndex = 2;
            // 
            // txtIsyeriYetkiliIsmi
            // 
            this.txtIsyeriYetkiliIsmi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIsyeriYetkiliIsmi.Location = new System.Drawing.Point(225, 85);
            this.txtIsyeriYetkiliIsmi.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtIsyeriYetkiliIsmi.Multiline = true;
            this.txtIsyeriYetkiliIsmi.Name = "txtIsyeriYetkiliIsmi";
            this.txtIsyeriYetkiliIsmi.Size = new System.Drawing.Size(133, 32);
            this.txtIsyeriYetkiliIsmi.TabIndex = 1;
            // 
            // btnIsyerleriGoruntule
            // 
            this.btnIsyerleriGoruntule.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIsyerleriGoruntule.Location = new System.Drawing.Point(30, 450);
            this.btnIsyerleriGoruntule.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnIsyerleriGoruntule.Name = "btnIsyerleriGoruntule";
            this.btnIsyerleriGoruntule.Size = new System.Drawing.Size(131, 60);
            this.btnIsyerleriGoruntule.TabIndex = 6;
            this.btnIsyerleriGoruntule.Text = "Mevcut İşyerlerini Göster";
            this.btnIsyerleriGoruntule.UseVisualStyleBackColor = true;
            this.btnIsyerleriGoruntule.Click += new System.EventHandler(this.btnIsyerleriGoruntule_Click);
            // 
            // frmIsyeriGuncelle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(925, 525);
            this.Controls.Add(this.btnIsyerleriGoruntule);
            this.Controls.Add(this.mtbIsyeriTelNo);
            this.Controls.Add(this.lblIsyeriTelNo);
            this.Controls.Add(this.lblIsyeriAdres);
            this.Controls.Add(this.txtIsyeriAdres);
            this.Controls.Add(this.lblIsyeriTuru);
            this.Controls.Add(this.txtIsyeriTuru);
            this.Controls.Add(this.lblGuncellenecekIsyeriIsmi);
            this.Controls.Add(this.txtGuncellenecekIsyeriIsmi);
            this.Controls.Add(this.lblIsyeriYetkiliSoyismi);
            this.Controls.Add(this.lblIsyeriYetkiliİsmi);
            this.Controls.Add(this.txtIsyeriYetkiliSoyismi);
            this.Controls.Add(this.txtIsyeriYetkiliIsmi);
            this.Controls.Add(this.dgvIsyeriGuncelle);
            this.Controls.Add(this.btnIsyeriGuncelle);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmIsyeriGuncelle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "İşyeri Güncelleme Formu";
            ((System.ComponentModel.ISupportInitialize)(this.dgvIsyeriGuncelle)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnIsyeriGuncelle;
        private System.Windows.Forms.ImageList ilIsyeriGuncelle;
        private System.Windows.Forms.DataGridView dgvIsyeriGuncelle;
        private System.Windows.Forms.MaskedTextBox mtbIsyeriTelNo;
        private System.Windows.Forms.Label lblIsyeriTelNo;
        private System.Windows.Forms.Label lblIsyeriAdres;
        private System.Windows.Forms.TextBox txtIsyeriAdres;
        private System.Windows.Forms.Label lblIsyeriTuru;
        private System.Windows.Forms.TextBox txtIsyeriTuru;
        private System.Windows.Forms.Label lblGuncellenecekIsyeriIsmi;
        private System.Windows.Forms.TextBox txtGuncellenecekIsyeriIsmi;
        private System.Windows.Forms.Label lblIsyeriYetkiliSoyismi;
        private System.Windows.Forms.Label lblIsyeriYetkiliİsmi;
        private System.Windows.Forms.TextBox txtIsyeriYetkiliSoyismi;
        private System.Windows.Forms.TextBox txtIsyeriYetkiliIsmi;
        private System.Windows.Forms.Button btnIsyerleriGoruntule;
    }
}