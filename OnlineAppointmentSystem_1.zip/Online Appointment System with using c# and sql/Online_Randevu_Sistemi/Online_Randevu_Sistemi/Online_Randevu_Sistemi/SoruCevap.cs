﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace Online_Randevu_Sistemi
{
    class SoruCevap : sqlIslemleri
    {
        int SoruNo;
        
        public int SoruNoAtama()
        {
            Random rnd = new Random();
            SoruNo = rnd.Next(10000, 99999);
            return SoruNo;
        }
        public void SoruKaydet(SoruCevapElemanlar elemanlar)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Insert Into soruCevap(soru_no ,soru_nkullanici_kullanici_adi ,soru_nkullanici_kullanici_soyad ,soru_basligi ,soru) values ('" + (elemanlar.Soru_No) + "','" + (elemanlar.Kullanici_isim) + "','" + (elemanlar.Kullanici_Soyisim) + "','" + (elemanlar.Soru_Baslik) + "','" + (elemanlar.Soru) + "')", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void SorulariListele(DataGridView dgvListe)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("Select soru_no,soru_basligi,soru_nkullanici_kullanici_adi,soru_nkullanici_kullanici_soyad,soru,soru_yetkili_kullanici_adi,soru_cevap From soruCevap", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgvListe.DataSource = ds.Tables[0];
            con.Close();
        }
        public void YanitGonder(SoruCevapElemanlar elemanlar)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Update soruCevap Set soru_yetkili_kullanici_adi='" + elemanlar.Yetkili_adi + "', soru_cevap='" + elemanlar.Cevap+ "' Where soru_no='" + elemanlar.Soru_No + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public void CevapSorgula(SoruCevapElemanlar elemanlar, DataGridView dgvListe)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select soru_no,soru_basligi,soru,soru_yetkili_kullanici_adi,soru_cevap From soruCevap Where soru_no='"+ elemanlar.Soru_No+"'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgvListe.DataSource = ds.Tables[0];
            con.Close();
        }
        public void CevapAra(SoruCevapElemanlar elemanlar, DataGridView dgvListe)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select soru_no,soru_basligi,soru,soru_yetkili_kullanici_adi,soru_cevap From soruCevap Where soru_nkullanici_kullanici_adi Like '%" + elemanlar.Kullanici_isim + "%'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgvListe.DataSource = ds.Tables[0];
            con.Close();
        }
    }
}
