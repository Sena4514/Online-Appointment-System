﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Online_Randevu_Sistemi
{
    public class NormalKullanici
    {
        public string nkullanici_kullanici_adi { get; set; }
        public string nkullanici_sifre { get; set; }
        public string nkullanici_isim { get; set; }
        public string nkullanici_soyisim { get; set; }
        public string nkullanici_adres { get; set; }
        public string nkullanici_email { get; set; }
        public string nkullanici_telNo { get; set; }
    }
}
