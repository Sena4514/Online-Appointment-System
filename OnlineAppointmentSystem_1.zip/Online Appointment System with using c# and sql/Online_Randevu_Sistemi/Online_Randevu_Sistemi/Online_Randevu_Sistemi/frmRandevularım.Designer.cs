﻿
namespace Online_Randevu_Sistemi
{
    partial class frmRandevularım
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtKullaniciAdi = new System.Windows.Forms.TextBox();
            this.txtRandevuNo = new System.Windows.Forms.TextBox();
            this.btnRandevuAra = new System.Windows.Forms.Button();
            this.lblKullaniciAdi = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvRandevuGoruntule = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRandevuGoruntule)).BeginInit();
            this.SuspendLayout();
            // 
            // txtKullaniciAdi
            // 
            this.txtKullaniciAdi.Location = new System.Drawing.Point(211, 21);
            this.txtKullaniciAdi.Name = "txtKullaniciAdi";
            this.txtKullaniciAdi.Size = new System.Drawing.Size(100, 20);
            this.txtKullaniciAdi.TabIndex = 0;
            // 
            // txtRandevuNo
            // 
            this.txtRandevuNo.Location = new System.Drawing.Point(492, 21);
            this.txtRandevuNo.Name = "txtRandevuNo";
            this.txtRandevuNo.Size = new System.Drawing.Size(100, 20);
            this.txtRandevuNo.TabIndex = 1;
            // 
            // btnRandevuAra
            // 
            this.btnRandevuAra.Location = new System.Drawing.Point(320, 67);
            this.btnRandevuAra.Name = "btnRandevuAra";
            this.btnRandevuAra.Size = new System.Drawing.Size(166, 23);
            this.btnRandevuAra.TabIndex = 2;
            this.btnRandevuAra.Text = "Randevuları Ara";
            this.btnRandevuAra.UseVisualStyleBackColor = true;
            this.btnRandevuAra.Click += new System.EventHandler(this.btnRandevuAra_Click);
            // 
            // lblKullaniciAdi
            // 
            this.lblKullaniciAdi.AutoSize = true;
            this.lblKullaniciAdi.Location = new System.Drawing.Point(94, 24);
            this.lblKullaniciAdi.Name = "lblKullaniciAdi";
            this.lblKullaniciAdi.Size = new System.Drawing.Size(111, 13);
            this.lblKullaniciAdi.TabIndex = 3;
            this.lblKullaniciAdi.Text = "Kullanıcı Adınzı Giriniz:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(317, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "ya da Randevu Numaranızı Giriniz:";
            // 
            // dgvRandevuGoruntule
            // 
            this.dgvRandevuGoruntule.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvRandevuGoruntule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRandevuGoruntule.Location = new System.Drawing.Point(12, 125);
            this.dgvRandevuGoruntule.Name = "dgvRandevuGoruntule";
            this.dgvRandevuGoruntule.Size = new System.Drawing.Size(776, 313);
            this.dgvRandevuGoruntule.TabIndex = 5;
            // 
            // frmRandevularım
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dgvRandevuGoruntule);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblKullaniciAdi);
            this.Controls.Add(this.btnRandevuAra);
            this.Controls.Add(this.txtRandevuNo);
            this.Controls.Add(this.txtKullaniciAdi);
            this.Name = "frmRandevularım";
            this.Text = "Randevularım";
            ((System.ComponentModel.ISupportInitialize)(this.dgvRandevuGoruntule)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtKullaniciAdi;
        private System.Windows.Forms.TextBox txtRandevuNo;
        private System.Windows.Forms.Button btnRandevuAra;
        private System.Windows.Forms.Label lblKullaniciAdi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvRandevuGoruntule;
    }
}