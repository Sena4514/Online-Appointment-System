﻿
namespace Online_Randevu_Sistemi
{
    partial class frmKayitSecenegi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmKayitSecenegi));
            this.btnIsyeriYetkiliKayit = new System.Windows.Forms.Button();
            this.btnNormalKullaniciKayit = new System.Windows.Forms.Button();
            this.pbIsyeriYetkiliKayit = new System.Windows.Forms.PictureBox();
            this.pbNormalKullaniciKayit = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbIsyeriYetkiliKayit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbNormalKullaniciKayit)).BeginInit();
            this.SuspendLayout();
            // 
            // btnIsyeriYetkiliKayit
            // 
            this.btnIsyeriYetkiliKayit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIsyeriYetkiliKayit.Location = new System.Drawing.Point(234, 166);
            this.btnIsyeriYetkiliKayit.Name = "btnIsyeriYetkiliKayit";
            this.btnIsyeriYetkiliKayit.Size = new System.Drawing.Size(236, 85);
            this.btnIsyeriYetkiliKayit.TabIndex = 1;
            this.btnIsyeriYetkiliKayit.Text = "İşyeri Yetkili Kayıt";
            this.btnIsyeriYetkiliKayit.UseVisualStyleBackColor = true;
            this.btnIsyeriYetkiliKayit.Click += new System.EventHandler(this.btnIsyeriYetkiliKayit_Click);
            // 
            // btnNormalKullaniciKayit
            // 
            this.btnNormalKullaniciKayit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNormalKullaniciKayit.Location = new System.Drawing.Point(234, 37);
            this.btnNormalKullaniciKayit.Name = "btnNormalKullaniciKayit";
            this.btnNormalKullaniciKayit.Size = new System.Drawing.Size(236, 85);
            this.btnNormalKullaniciKayit.TabIndex = 0;
            this.btnNormalKullaniciKayit.Text = "Normal Kullanıcı Kayıt";
            this.btnNormalKullaniciKayit.UseVisualStyleBackColor = true;
            this.btnNormalKullaniciKayit.Click += new System.EventHandler(this.btnNormalKullaniciKayit_Click);
            // 
            // pbIsyeriYetkiliKayit
            // 
            this.pbIsyeriYetkiliKayit.Image = ((System.Drawing.Image)(resources.GetObject("pbIsyeriYetkiliKayit.Image")));
            this.pbIsyeriYetkiliKayit.Location = new System.Drawing.Point(87, 166);
            this.pbIsyeriYetkiliKayit.Name = "pbIsyeriYetkiliKayit";
            this.pbIsyeriYetkiliKayit.Size = new System.Drawing.Size(121, 85);
            this.pbIsyeriYetkiliKayit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbIsyeriYetkiliKayit.TabIndex = 4;
            this.pbIsyeriYetkiliKayit.TabStop = false;
            // 
            // pbNormalKullaniciKayit
            // 
            this.pbNormalKullaniciKayit.Image = ((System.Drawing.Image)(resources.GetObject("pbNormalKullaniciKayit.Image")));
            this.pbNormalKullaniciKayit.Location = new System.Drawing.Point(87, 37);
            this.pbNormalKullaniciKayit.Name = "pbNormalKullaniciKayit";
            this.pbNormalKullaniciKayit.Size = new System.Drawing.Size(121, 85);
            this.pbNormalKullaniciKayit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbNormalKullaniciKayit.TabIndex = 5;
            this.pbNormalKullaniciKayit.TabStop = false;
            // 
            // frmKayitSecenegi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(553, 285);
            this.Controls.Add(this.pbNormalKullaniciKayit);
            this.Controls.Add(this.pbIsyeriYetkiliKayit);
            this.Controls.Add(this.btnIsyeriYetkiliKayit);
            this.Controls.Add(this.btnNormalKullaniciKayit);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmKayitSecenegi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kayit Turu Secenekleri";
            ((System.ComponentModel.ISupportInitialize)(this.pbIsyeriYetkiliKayit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbNormalKullaniciKayit)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnIsyeriYetkiliKayit;
        private System.Windows.Forms.Button btnNormalKullaniciKayit;
        private System.Windows.Forms.PictureBox pbIsyeriYetkiliKayit;
        private System.Windows.Forms.PictureBox pbNormalKullaniciKayit;
    }
}