﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
namespace Online_Randevu_Sistemi
{
    class NormalKullaniciIslemleri:sqlIslemleri
    {
        public void Raporla(DataGridView dgvKullanicilar)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("Select nkullanici_kullanici_adi,nkullanici_kullaniciadi,nkullanici_isim,nkullanici_soyisim,nkullanici_adres,nkullanici_email,nkullanici_telNo From normalkullanici", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgvKullanicilar.DataSource = ds.Tables[0];
            con.Close();
        }
    }
}
