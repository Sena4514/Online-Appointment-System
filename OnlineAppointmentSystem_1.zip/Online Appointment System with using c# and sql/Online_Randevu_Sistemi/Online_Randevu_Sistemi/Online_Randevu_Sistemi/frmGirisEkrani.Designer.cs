﻿
namespace Online_Randevu_Sistemi
{
    partial class frmGirisEkrani
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGirisEkrani));
            this.btnKayitOl = new System.Windows.Forms.Button();
            this.btnGirisYap = new System.Windows.Forms.Button();
            this.txtSifre = new System.Windows.Forms.TextBox();
            this.txtKullaniciAdi = new System.Windows.Forms.TextBox();
            this.lblSifre = new System.Windows.Forms.Label();
            this.lblKullaniciAdi = new System.Windows.Forms.Label();
            this.lblGirisEkrani = new System.Windows.Forms.Label();
            this.pbGirisEkrani = new System.Windows.Forms.PictureBox();
            this.pbKullaniciAdi = new System.Windows.Forms.PictureBox();
            this.pbSifre = new System.Windows.Forms.PictureBox();
            this.pnlKullaniciAdi = new System.Windows.Forms.Panel();
            this.pnlSifre = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pbGirisEkrani)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbKullaniciAdi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSifre)).BeginInit();
            this.SuspendLayout();
            // 
            // btnKayitOl
            // 
            this.btnKayitOl.BackColor = System.Drawing.Color.MediumTurquoise;
            this.btnKayitOl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKayitOl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKayitOl.Location = new System.Drawing.Point(323, 373);
            this.btnKayitOl.Name = "btnKayitOl";
            this.btnKayitOl.Size = new System.Drawing.Size(155, 61);
            this.btnKayitOl.TabIndex = 3;
            this.btnKayitOl.Text = "KAYIT OL";
            this.btnKayitOl.UseVisualStyleBackColor = false;
            this.btnKayitOl.Click += new System.EventHandler(this.btnKayitOl_Click);
            this.btnKayitOl.MouseLeave += new System.EventHandler(this.btnKayitOl_MouseLeave);
            this.btnKayitOl.MouseHover += new System.EventHandler(this.btnKayitOl_MouseHover);
            // 
            // btnGirisYap
            // 
            this.btnGirisYap.BackColor = System.Drawing.Color.MediumTurquoise;
            this.btnGirisYap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGirisYap.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGirisYap.Location = new System.Drawing.Point(323, 289);
            this.btnGirisYap.Name = "btnGirisYap";
            this.btnGirisYap.Size = new System.Drawing.Size(155, 61);
            this.btnGirisYap.TabIndex = 2;
            this.btnGirisYap.Text = "GİRİŞ YAP";
            this.btnGirisYap.UseVisualStyleBackColor = false;
            this.btnGirisYap.Click += new System.EventHandler(this.btnGirisYap_Click);
            this.btnGirisYap.MouseLeave += new System.EventHandler(this.btnGirisYap_MouseLeave);
            this.btnGirisYap.MouseHover += new System.EventHandler(this.btnGirisYap_MouseHover);
            // 
            // txtSifre
            // 
            this.txtSifre.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSifre.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSifre.Location = new System.Drawing.Point(293, 217);
            this.txtSifre.Multiline = true;
            this.txtSifre.Name = "txtSifre";
            this.txtSifre.PasswordChar = '*';
            this.txtSifre.Size = new System.Drawing.Size(267, 38);
            this.txtSifre.TabIndex = 1;
            // 
            // txtKullaniciAdi
            // 
            this.txtKullaniciAdi.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtKullaniciAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKullaniciAdi.Location = new System.Drawing.Point(293, 156);
            this.txtKullaniciAdi.Multiline = true;
            this.txtKullaniciAdi.Name = "txtKullaniciAdi";
            this.txtKullaniciAdi.Size = new System.Drawing.Size(267, 41);
            this.txtKullaniciAdi.TabIndex = 0;
            // 
            // lblSifre
            // 
            this.lblSifre.AutoSize = true;
            this.lblSifre.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSifre.Location = new System.Drawing.Point(128, 217);
            this.lblSifre.Name = "lblSifre";
            this.lblSifre.Size = new System.Drawing.Size(105, 32);
            this.lblSifre.TabIndex = 15;
            this.lblSifre.Text = "ŞİFRE:";
            // 
            // lblKullaniciAdi
            // 
            this.lblKullaniciAdi.AutoSize = true;
            this.lblKullaniciAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKullaniciAdi.Location = new System.Drawing.Point(14, 162);
            this.lblKullaniciAdi.Name = "lblKullaniciAdi";
            this.lblKullaniciAdi.Size = new System.Drawing.Size(220, 32);
            this.lblKullaniciAdi.TabIndex = 14;
            this.lblKullaniciAdi.Text = "KULLANICI ADI:";
            // 
            // lblGirisEkrani
            // 
            this.lblGirisEkrani.AutoSize = true;
            this.lblGirisEkrani.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGirisEkrani.Location = new System.Drawing.Point(247, 35);
            this.lblGirisEkrani.Name = "lblGirisEkrani";
            this.lblGirisEkrani.Size = new System.Drawing.Size(317, 52);
            this.lblGirisEkrani.TabIndex = 13;
            this.lblGirisEkrani.Text = "GİRİŞ EKRANI";
            // 
            // pbGirisEkrani
            // 
            this.pbGirisEkrani.Image = ((System.Drawing.Image)(resources.GetObject("pbGirisEkrani.Image")));
            this.pbGirisEkrani.Location = new System.Drawing.Point(56, 22);
            this.pbGirisEkrani.Name = "pbGirisEkrani";
            this.pbGirisEkrani.Size = new System.Drawing.Size(154, 114);
            this.pbGirisEkrani.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbGirisEkrani.TabIndex = 20;
            this.pbGirisEkrani.TabStop = false;
            // 
            // pbKullaniciAdi
            // 
            this.pbKullaniciAdi.Image = ((System.Drawing.Image)(resources.GetObject("pbKullaniciAdi.Image")));
            this.pbKullaniciAdi.Location = new System.Drawing.Point(240, 156);
            this.pbKullaniciAdi.Name = "pbKullaniciAdi";
            this.pbKullaniciAdi.Size = new System.Drawing.Size(51, 41);
            this.pbKullaniciAdi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbKullaniciAdi.TabIndex = 21;
            this.pbKullaniciAdi.TabStop = false;
            // 
            // pbSifre
            // 
            this.pbSifre.Image = ((System.Drawing.Image)(resources.GetObject("pbSifre.Image")));
            this.pbSifre.Location = new System.Drawing.Point(240, 217);
            this.pbSifre.Name = "pbSifre";
            this.pbSifre.Size = new System.Drawing.Size(51, 38);
            this.pbSifre.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSifre.TabIndex = 22;
            this.pbSifre.TabStop = false;
            // 
            // pnlKullaniciAdi
            // 
            this.pnlKullaniciAdi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlKullaniciAdi.Location = new System.Drawing.Point(240, 196);
            this.pnlKullaniciAdi.Name = "pnlKullaniciAdi";
            this.pnlKullaniciAdi.Size = new System.Drawing.Size(320, 1);
            this.pnlKullaniciAdi.TabIndex = 23;
            // 
            // pnlSifre
            // 
            this.pnlSifre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSifre.Location = new System.Drawing.Point(244, 254);
            this.pnlSifre.Name = "pnlSifre";
            this.pnlSifre.Size = new System.Drawing.Size(316, 1);
            this.pnlSifre.TabIndex = 24;
            // 
            // frmGirisEkrani
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 450);
            this.Controls.Add(this.pnlSifre);
            this.Controls.Add(this.pnlKullaniciAdi);
            this.Controls.Add(this.pbSifre);
            this.Controls.Add(this.pbKullaniciAdi);
            this.Controls.Add(this.pbGirisEkrani);
            this.Controls.Add(this.btnKayitOl);
            this.Controls.Add(this.btnGirisYap);
            this.Controls.Add(this.txtSifre);
            this.Controls.Add(this.txtKullaniciAdi);
            this.Controls.Add(this.lblSifre);
            this.Controls.Add(this.lblKullaniciAdi);
            this.Controls.Add(this.lblGirisEkrani);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmGirisEkrani";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Giris Ekrani";
            ((System.ComponentModel.ISupportInitialize)(this.pbGirisEkrani)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbKullaniciAdi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSifre)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnKayitOl;
        private System.Windows.Forms.Button btnGirisYap;
        private System.Windows.Forms.TextBox txtSifre;
        private System.Windows.Forms.TextBox txtKullaniciAdi;
        private System.Windows.Forms.Label lblSifre;
        private System.Windows.Forms.Label lblKullaniciAdi;
        private System.Windows.Forms.Label lblGirisEkrani;
        private System.Windows.Forms.PictureBox pbGirisEkrani;
        private System.Windows.Forms.PictureBox pbKullaniciAdi;
        private System.Windows.Forms.PictureBox pbSifre;
        private System.Windows.Forms.Panel pnlKullaniciAdi;
        private System.Windows.Forms.Panel pnlSifre;
    }
}